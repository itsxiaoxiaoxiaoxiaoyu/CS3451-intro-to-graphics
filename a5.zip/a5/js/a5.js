///<reference path='./typings/tsd.d.ts'/>
///<reference path="./localTypings/webglutils.d.ts"/>
//get start by stuff not in shaders
//
/*
 * Portions of this code are
 * Copyright 2015, Blair MacIntyre.
 *
 * Portions of this code taken from http://webglfundamentals.org, at https://github.com/greggman/webgl-fundamentals
 * and are subject to the following license.  In particular, from
 *    http://webglfundamentals.org/webgl/webgl-less-code-more-fun.html
 *    http://webglfundamentals.org/webgl/resources/primitives.js
 *
 * Those portions Copyright 2014, Gregg Tavares.
 * All rights reserved.
 */
define(["require", "exports", './loader'], function (require, exports, loader) {
    ////////////////////////////////////////////////////////////////////////////////////////////
    // stats module by mrdoob (https://github.com/mrdoob/stats.js) to show the performance 
    ////////////////////////////////////////////////////////////////////////////////////////////
    // utilities
    var rand = function (min, max) {
        if (max === undefined) {
            max = min;
            min = 0;
        }
        return min + Math.random() * (max - min);
    };
    var randInt = function (range) {
        return Math.floor(Math.random() * range);
    };
    ////////////////////////////////////////////////////////////////////////////////////////////
    // get some of our canvas elements that we need
    var canvas = document.getElementById("webgl");
    ////////////////////////////////////////////////////////////////////////////////////////////
    // some simple interaction using the mouse.
    // we are going to get small motion offsets of the mouse, and use these to rotate the object
    //
    // our offset() function from assignment 0, to give us a good mouse position in the canvas 
    function offset(e) {
        e = e || window.event;
        var target = e.target || e.srcElement, rect = target.getBoundingClientRect(), offsetX = e.clientX - rect.left, offsetY = e.clientY - rect.top;
        return vec2.fromValues(offsetX, offsetY);
    }
    var mouseDown = undefined;
    var pressFromKeyboard = undefined;
    // the amount the mouse has moved // angle offset corresponding to mouse movement
    // start things off with a down press
    canvas.onmousedown = function (ev) {
        mouseDown = offset(ev);
    };
    // stop things with a mouse release
    // if we're moving and the mouse is down        
    document.onkeypress = function (ev) {
        pressFromKeyboard = ev.keyCode;
        if (ev.keyCode == 32) {
            ev.preventDefault();
        }
        var effect = new Howl({
            urls: ['sounds/typing.mp3']
        }).play();
    };
    document.onkeydown = function (ev) {
        pressFromKeyboard = ev.keyCode;
        if (ev.keyCode == 8) {
            ev.preventDefault();
        }
    };
    // stop things if you move out of the window
    ////////////////////////////////////////////////////////////////////////////////////////////
    // start things off by calling initWebGL
    initWebGL();
    function initWebGL() {
        // get the rendering context for webGL
        var gl = getWebGLContext(canvas);
        if (!gl) {
            return; // no webgl!  Bye bye
        }
        // turn on backface culling and zbuffering
        //gl.enable(gl.CULL_FACE);
        gl.enable(gl.DEPTH_TEST);
        // attempt to download and set up our GLSL shaders.  When they download, processed to the next step
        // of our program, the "main" routing
        // 
        // YOU SHOULD MODIFY THIS TO DOWNLOAD ALL YOUR SHADERS and set up all four SHADER PROGRAMS,
        // THEN PASS AN ARRAY OF PROGRAMS TO main().  You'll have to do other things in main to deal
        // with multiple shaders and switch between them
        loader.loadFiles(['shaders/a3-shader.vert', 'shaders/a3-shader.frag',
            'shaders/shaders-line.vert', 'shaders/shaders-line.frag'], function (shaderText) {
            // var program = createProgramFromSources(gl, [shaderText[0], shaderText[1]]);
            main(gl, shaderText);
        }, function (url) {
            alert('Shader failed to download "' + url + '"');
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////
    // webGL is set up, and our Shader program has been created.  Finish setting up our webGL application       
    function main(gl, shaderText) {
        var textures = [];
        var letters = [];
        for (var ii = 0; ii < 26; ii++) {
            var curr = new Image();
            textures.push(curr);
            curr.onload = function () {
                letters[ii].src = this.src;
            };
            curr.src = "letters/" + "myletter" + ii.toString() + ".jpg";
        }
        // images.push(image2);
        // use the webgl-utils library to create setters for all the uniforms and attributes in our shaders.
        // It enumerates all of the uniforms and attributes in the program, and creates utility functions to 
        // allow "setUniforms" and "setAttributes" (below) to set the shader variables from a javascript object. 
        // The objects have a key for each uniform or attribute, and a value containing the parameters for the
        // setter function
        // var program = createProgramFromSources(gl, [shaderText[effectI], shaderText[effectI + 1]]);
        // var uniformSetters = createUniformSetters(gl, program);
        // var attribSetters  = createAttributeSetters(gl, program);
        // an indexed quad
        var arrays = {
            position: { numComponents: 3, data: [], },
            texcoord: { numComponents: 2, data: [], },
            normal: { numComponents: 3, data: [], },
            indices: { numComponents: 3, data: [], },
        };
        var center = vec4.fromValues(70 * scaleFactor, 0, 0, 0);
        var scaleFactor = 10;
        var lineArrays = { position: { numComponents: 3, data: [0, 1, 0, 0, -1, 0] },
            indices: { numComponents: 1, data: [0, 1] } };
        // console.log(newPosition);
        var n = 2;
        for (var ii = 0; ii < n; ii++) {
            for (var jj = 0; jj < n; jj++) {
                arrays.position.data.push.apply(arrays.position.data, [jj * (10 / (n - 1)), ii * (10 / (n - 1)), 0]);
                arrays.normal.data.push.apply(arrays.normal.data, [0, 0, -1]);
                arrays.texcoord.data.push(jj * 1 / (n - 1), ii * (1 / (n - 1)));
                if (ii != n - 1 && jj != n - 1) {
                    arrays.indices.data.push(jj + ii * n, jj + ii * n + 1, jj + (ii + 1) * n);
                    arrays.indices.data.push(jj + ii * n + 1, jj + (ii + 1) * n, jj + (ii + 1) * n + 1);
                }
            }
        }
        for (var ii = 0; ii < arrays.texcoord.data.length / 2; ii++) {
            var tempt = arrays.texcoord.data[ii];
            arrays.texcoord.data[ii] = arrays.texcoord.data[arrays.texcoord.data.length - ii - 1];
            arrays.texcoord.data[arrays.texcoord.data.length - ii - 1] = tempt;
        }
        for (var ii = 0; ii < arrays.texcoord.data.length; ii += 2) {
            var tempt = arrays.texcoord.data[ii];
            arrays.texcoord.data[ii] = arrays.texcoord.data[ii + 1];
            arrays.texcoord.data[ii + 1] = tempt;
        }
        var bufferInfo = createBufferInfoFromArrays(gl, arrays);
        var bufferInfo0 = createBufferInfoFromArrays(gl, lineArrays);
        function degToRad(d) {
            return d * Math.PI / 180;
        }
        var cameraAngleRadians = degToRad(0);
        var fieldOfViewRadians = degToRad(60);
        var cameraHeight = 50;
        var uniformsThatAreTheSameForAllObjects = {
            u_lightWorldPos: [0, 0, -100],
            u_viewInverse: mat4.create(),
            u_lightColor: [1, 1, 1, 1],
            u_ambient: [0.1, 0.1, 0.1, 0.1],
        };
        var uniformsThatAreComputedForEachObject = {
            u_worldViewProjection: mat4.create(),
            u_world: mat4.create(),
            u_worldInverseTranspose: mat4.create(),
        };
        // var texture = .... create a texture of some form
        var baseColor = rand(240);
        var objectState = {
            materialUniforms: {
                u_colorMult: chroma.hsv(rand(baseColor, baseColor + 120), 0.5, 1).gl(),
                u_colorOfLetter: chroma.hsv(rand(baseColor, baseColor + 120), 0.5, 1).gl(),
                //u_diffuse:               texture,
                u_specular: [1, 1, 1, 1],
                u_shininess: 450,
                u_specularFactor: 0.75,
                u_disToCenter: undefined,
                u_verticalPos: undefined
            }
        };
        // some variables we'll reuse below
        var projectionMatrix = mat4.create();
        var viewMatrix = mat4.create();
        var rotationMatrix = mat4.create();
        var matrix = mat4.create(); // a scratch matrix
        var invMatrix = mat4.create();
        var axisVector = vec3.create();
        var capacity = 14;
        var spacing = 0;
        requestAnimationFrame(drawScene);
        // Draw the scene.
        function drawScene(time) {
            time *= 0.001;
            var program = createProgramFromSources(gl, [shaderText[0], shaderText[1]]);
            var lineProgram = createProgramFromSources(gl, [shaderText[2], shaderText[3]]);
            var uniformSetters = createUniformSetters(gl, program);
            var attribSetters = createAttributeSetters(gl, program);
            // measure time taken for the little stats meter
            // if the window changed size, reset the WebGL canvas size to match.  The displayed size of the canvas
            // (determined by window size, layout, and your CSS) is separate from the size of the WebGL render buffers, 
            // which you can control by setting canvas.width and canvas.height
            resizeCanvasToDisplaySize(canvas);
            // Set the viewport to match the canvas
            gl.viewport(0, 0, canvas.width, canvas.height);
            // Clear the canvas AND the depth buffer.
            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            // Compute the projection matrix
            var aspect = canvas.clientWidth / canvas.clientHeight;
            mat4.perspective(projectionMatrix, fieldOfViewRadians, aspect, 1, 2000);
            // Compute the camera's matrix using look at.
            var cameraPosition = [0, 0, -200];
            var target = [0, 0, 0];
            var up = [0, 1, 0];
            var cameraMatrix = mat4.lookAt(uniformsThatAreTheSameForAllObjects.u_viewInverse, cameraPosition, target, up);
            // Make a view matrix from the camera matrix.
            mat4.invert(viewMatrix, cameraMatrix);
            // tell WebGL to use our shader program (will need to change this)
            gl.useProgram(program);
            setBuffersAndAttributes(gl, attribSetters, bufferInfo);
            // Set the uniforms that are the same for all objects.  Unlike the attributes, each uniform setter
            // is different, depending on the type of the uniform variable.  Look in webgl-util.js for the
            // implementation of  setUniforms to see the details for specific types       
            setUniforms(uniformSetters, uniformsThatAreTheSameForAllObjects);
            // Compute the view matrix and corresponding other matrices for rendering.
            // first make a copy of our rotationMatrix
            mat4.copy(matrix, rotationMatrix);
            var curr = {
                letter: undefined,
                rotateZ: mat4.create(),
                rotateX: mat4.create(),
                isSpinning: false,
                spinningSpeed: 0.0,
                height: 0.0,
                u_colorMult: chroma.hsv(rand(baseColor - 100, baseColor + 100), 0.5, 0.5).gl(),
                texture: undefined,
                angle: 0.0,
                positionX: undefined,
                time: 0.0,
                spinningAngle: 0.0
            };
            var texture;
            if (pressFromKeyboard != undefined) {
                curr.letter = pressFromKeyboard;
                curr.height = rand(-80, 0);
                if (pressFromKeyboard == 8) {
                    letters.pop();
                    pressFromKeyboard = undefined;
                }
                else {
                    if (pressFromKeyboard == 13) {
                        letters = [];
                        pressFromKeyboard = undefined;
                    }
                    else {
                        if (pressFromKeyboard >= 65 && pressFromKeyboard <= 122) {
                            if (pressFromKeyboard >= 91 && pressFromKeyboard <= 122) {
                                pressFromKeyboard = pressFromKeyboard - 32;
                            }
                            curr.angle = degToRad(rand(-20, 20));
                            var axis = vec3.transformMat4(axisVector, vec3.fromValues(0, 0, 1), mat4.create());
                            var currHeight = curr.height;
                            mat4.rotate(curr.rotateZ, mat4.create(), curr.angle, axis);
                            curr.texture = textures[pressFromKeyboard - 65];
                        }
                        if (letters.length > capacity) {
                            letters.shift();
                        }
                        letters.push(curr);
                        pressFromKeyboard = undefined;
                    }
                }
            }
            var scaleForLetters = scaleFactor * 0.3;
            spacing = 140 / capacity * 0.2;
            for (var i = 0; i < letters.length; i++) {
                if (letters[i].letter != 32) {
                    mat4.copy(matrix, rotationMatrix);
                    matrix = mat4.create();
                    if (letters[i].isSpinning) {
                        if (letters[i].time >= 0 && letters[i].spinningSpeed >= 1.0) {
                            if (Math.abs(letters[i].spinningAngle) < 360.0) {
                                var rotateY = vec3.transformMat4(axisVector, vec3.fromValues(0, 1, 0), mat4.create());
                                letters[i].spinningAngle = letters[i].spinningSpeed + letters[i].spinningAngle;
                                mat4.rotate(matrix, matrix, degToRad(letters[i].spinningAngle), rotateY);
                            }
                            else {
                                letters[i].spinningSpeed = letters[i].spinningSpeed / 2.0;
                                letters[i].time--;
                                letters[i].spinningAngle = 0.0;
                            }
                        }
                        else {
                            letters[i].isSpnning = false;
                            letters[i].time = 0.0;
                            letters[i].spinningSpeed = 0.0;
                            matrix = mat4.create();
                            letters[i].spinningSpeed = 0.0;
                        }
                    }
                    mat4.copy(letters[i].rotateX, matrix);
                    mat4.multiply(matrix, letters[i].rotateX, letters[i].rotateZ);
                    mat4.scale(matrix, matrix, [scaleForLetters, scaleForLetters, scaleForLetters]);
                    mat4.copy(uniformsThatAreComputedForEachObject.u_world, matrix);
                    mat4.multiply(matrix, viewMatrix, uniformsThatAreComputedForEachObject.u_world);
                    mat4.multiply(uniformsThatAreComputedForEachObject.u_worldViewProjection, projectionMatrix, matrix);
                    mat4.transpose(uniformsThatAreComputedForEachObject.u_worldInverseTranspose, mat4.invert(matrix, uniformsThatAreComputedForEachObject.u_world));
                    setUniforms(uniformSetters, uniformsThatAreComputedForEachObject);
                    objectState.materialUniforms.u_colorMult = letters[i].u_colorMult;
                    objectState.materialUniforms.u_verticalPos = vec4.fromValues(0, letters[i].height, 0, 0);
                    letters[i].positionX = scaleFactor * (i * spacing - spacing * 0.5 * (letters.length - 1)) / 200;
                    objectState.materialUniforms.u_disToCenter = vec4.fromValues(scaleFactor * (i * spacing - spacing * 0.5 * (letters.length - 1)), 0, 0, 0);
                    setUniforms(uniformSetters, objectState.materialUniforms);
                    texture = gl.createTexture();
                    gl.bindTexture(gl.TEXTURE_2D, texture);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
                    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, letters[i].texture);
                    gl.drawElements(gl.TRIANGLES, bufferInfo.numElements, gl.UNSIGNED_SHORT, 0);
                }
            }
            if (mouseDown != undefined) {
                if (canvas != undefined) {
                    if (gl != undefined) {
                        var mousePosition = 0.0;
                        var currDist = Infinity;
                        var currID = undefined;
                        mousePosition = mouseDown[0] - 717;
                        mousePosition = mousePosition / 717;
                        for (var i = 0; i < letters.length; i++) {
                            if (Math.abs(mousePosition - letters[i].positionX) < currDist) {
                                currID = i;
                                currDist = Math.abs(mousePosition - letters[i].positionX);
                            }
                        }
                        if (letters[currID].isSpinning == false) {
                            letters[currID].isSpinning = true;
                            letters[currID].time = currDist * 360;
                            letters[currID].spinningSpeed = letters[currID].time * 10.0;
                            var soundEffect = new Howl({
                                urls: ['sounds/spin.mp3']
                            }).play();
                        }
                    }
                }
                mouseDown = undefined;
            }
            gl.useProgram(lineProgram);
            uniformSetters = createUniformSetters(gl, lineProgram);
            attribSetters = createAttributeSetters(gl, lineProgram);
            var uniformsOfLines = {
                u_worldViewProjection: mat4.create(),
                u_colorMult: [0, 0, 0, 1],
                u_horizontalPos: vec4.create(),
                u_height: 0.0
            };
            for (var i = 0; i < letters.length; i++) {
                if (letters[i].letter != 32) {
                    var horizontalPos = scaleFactor * (i * spacing - spacing * 0.5 * (letters.length - 1)) / 200;
                    uniformsOfLines.u_colorMult = letters[i].u_colorMult;
                    uniformsOfLines.u_horizontalPos = vec4.fromValues(horizontalPos, 0, 0, 0);
                    uniformsOfLines.u_height = letters[i].height / 200;
                    setBuffersAndAttributes(gl, attribSetters, bufferInfo0);
                    setUniforms(uniformSetters, uniformsOfLines);
                    gl.lineWidth(2.0);
                    gl.drawElements(gl.LINES, 2, gl.UNSIGNED_SHORT, 0);
                }
            }
            requestAnimationFrame(drawScene);
        }
    }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImE1LnRzIl0sIm5hbWVzIjpbIm9mZnNldCIsImluaXRXZWJHTCIsIm1haW4iLCJtYWluLmRlZ1RvUmFkIiwibWFpbi5kcmF3U2NlbmUiXSwibWFwcGluZ3MiOiJBQUFBLHlDQUF5QztBQUN6QyxxREFBcUQ7QUFDckQsbUNBQW1DO0FBQ25DLEVBQUU7QUFDRjs7Ozs7Ozs7Ozs7R0FXRzs7SUFJSCw0RkFBNEY7SUFDNUYsdUZBQXVGO0lBRXZGLDRGQUE0RjtJQUM1RixZQUFZO0lBQ1osSUFBSSxJQUFJLEdBQUcsVUFBUyxHQUFXLEVBQUUsR0FBWTtRQUMzQyxFQUFFLENBQUMsQ0FBQyxHQUFHLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztZQUN0QixHQUFHLEdBQUcsR0FBRyxDQUFDO1lBQ1YsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNWLENBQUM7UUFDRCxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUMzQyxDQUFDLENBQUM7SUFFRixJQUFJLE9BQU8sR0FBRyxVQUFTLEtBQUs7UUFDMUIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUMsQ0FBQztJQUVGLDRGQUE0RjtJQUM1RiwrQ0FBK0M7SUFDL0MsSUFBSSxNQUFNLEdBQXNCLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUM7SUFFakUsNEZBQTRGO0lBQzVGLDJDQUEyQztJQUMzQyw0RkFBNEY7SUFDNUYsRUFBRTtJQUNGLDJGQUEyRjtJQUMzRixnQkFBZ0IsQ0FBYTtRQUN6QkEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsSUFBaUJBLE1BQU1BLENBQUNBLEtBQUtBLENBQUNBO1FBRW5DQSxJQUFJQSxNQUFNQSxHQUFhQSxDQUFDQSxDQUFDQSxNQUFNQSxJQUFJQSxDQUFDQSxDQUFDQSxVQUFVQSxFQUMzQ0EsSUFBSUEsR0FBR0EsTUFBTUEsQ0FBQ0EscUJBQXFCQSxFQUFFQSxFQUNyQ0EsT0FBT0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsR0FBR0EsSUFBSUEsQ0FBQ0EsSUFBSUEsRUFDL0JBLE9BQU9BLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLEdBQUdBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBO1FBRW5DQSxNQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxFQUFFQSxPQUFPQSxDQUFDQSxDQUFDQTtJQUM3Q0EsQ0FBQ0E7SUFDRCxJQUFJLFNBQVMsR0FBRyxTQUFTLENBQUM7SUFDMUIsSUFBSSxpQkFBaUIsR0FBRyxTQUFTLENBQUM7SUFDbEMsaUZBQWlGO0lBRWpGLHFDQUFxQztJQUNyQyxNQUFNLENBQUMsV0FBVyxHQUFHLFVBQUMsRUFBYztRQUNsQyxTQUFTLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3pCLENBQUMsQ0FBQTtJQUVELG1DQUFtQztJQUVuQyxnREFBZ0Q7SUFDaEQsUUFBUSxDQUFDLFVBQVUsR0FBRyxVQUFDLEVBQWdCO1FBQ3JDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUM7UUFDL0IsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3JCLEVBQUUsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixDQUFDO1FBQ0QsSUFBSSxNQUFNLEdBQUcsSUFBSSxJQUFJLENBQUM7WUFDcEIsSUFBSSxFQUFFLENBQUMsbUJBQW1CLENBQUM7U0FDNUIsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ1osQ0FBQyxDQUFBO0lBQ0QsUUFBUSxDQUFDLFNBQVMsR0FBRyxVQUFDLEVBQWlCO1FBQ3JDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUM7UUFDL0IsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BCLEVBQUUsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixDQUFDO0lBQ0gsQ0FBQyxDQUFBO0lBQ0QsNENBQTRDO0lBRTVDLDRGQUE0RjtJQUM1Rix3Q0FBd0M7SUFDeEMsU0FBUyxFQUFFLENBQUM7SUFFWjtRQUNFQyxzQ0FBc0NBO1FBQ3RDQSxJQUFJQSxFQUFFQSxHQUEwQkEsZUFBZUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7UUFDeERBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQ1JBLE1BQU1BLENBQUNBLENBQUVBLHFCQUFxQkE7UUFDaENBLENBQUNBO1FBRURBLDBDQUEwQ0E7UUFDMUNBLDBCQUEwQkE7UUFDMUJBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBO1FBRXpCQSxtR0FBbUdBO1FBQ25HQSxxQ0FBcUNBO1FBQ3JDQSxHQUFHQTtRQUNIQSwyRkFBMkZBO1FBQzNGQSw0RkFBNEZBO1FBQzVGQSxnREFBZ0RBO1FBQ2hEQSxNQUFNQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQSx3QkFBd0JBLEVBQUVBLHdCQUF3QkE7WUFDbEVBLDJCQUEyQkEsRUFBRUEsMkJBQTJCQSxDQUFDQSxFQUFDQSxVQUFVQSxVQUFVQTtZQUM5RSw4RUFBOEU7WUFDOUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUN2QixDQUFDLEVBQUVBLFVBQVVBLEdBQUdBO1lBQ1osS0FBSyxDQUFDLDZCQUE2QixHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNyRCxDQUFDLENBQUNBLENBQUNBO0lBQ0xBLENBQUNBO0lBRUQsNEZBQTRGO0lBQzVGLDRHQUE0RztJQUM1RyxjQUFjLEVBQXlCLEVBQUUsVUFBVTtRQUNqREMsSUFBSUEsUUFBUUEsR0FBR0EsRUFBRUEsQ0FBQ0E7UUFDbEJBLElBQUlBLE9BQU9BLEdBQUdBLEVBQUVBLENBQUNBO1FBQ2pCQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxHQUFHQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQTtZQUMvQkEsSUFBSUEsSUFBSUEsR0FBR0EsSUFBSUEsS0FBS0EsRUFBRUEsQ0FBQ0E7WUFDdkJBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLENBQUNBO1lBQ3BCQSxJQUFJQSxDQUFDQSxNQUFNQSxHQUFHQTtnQkFDWixPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDN0IsQ0FBQyxDQUFBQTtZQUNEQSxJQUFJQSxDQUFDQSxHQUFHQSxHQUFHQSxVQUFVQSxHQUFHQSxVQUFVQSxHQUFHQSxFQUFFQSxDQUFDQSxRQUFRQSxFQUFFQSxHQUFHQSxNQUFNQSxDQUFDQTtRQUM5REEsQ0FBQ0E7UUFDREEsdUJBQXVCQTtRQUN2QkEsb0dBQW9HQTtRQUNwR0EscUdBQXFHQTtRQUNyR0EseUdBQXlHQTtRQUN6R0Esc0dBQXNHQTtRQUN0R0Esa0JBQWtCQTtRQUNsQkEsOEZBQThGQTtRQUM5RkEsMERBQTBEQTtRQUMxREEsNERBQTREQTtRQUU1REEsa0JBQWtCQTtRQUNsQkEsSUFBSUEsTUFBTUEsR0FBR0E7WUFDVkEsUUFBUUEsRUFBRUEsRUFBRUEsYUFBYUEsRUFBRUEsQ0FBQ0EsRUFBRUEsSUFBSUEsRUFBRUEsRUFBRUEsR0FBR0E7WUFDekNBLFFBQVFBLEVBQUVBLEVBQUVBLGFBQWFBLEVBQUVBLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLEVBQUVBLEdBQUdBO1lBQ3pDQSxNQUFNQSxFQUFJQSxFQUFFQSxhQUFhQSxFQUFFQSxDQUFDQSxFQUFFQSxJQUFJQSxFQUFFQSxFQUFFQSxHQUFHQTtZQUN6Q0EsT0FBT0EsRUFBR0EsRUFBRUEsYUFBYUEsRUFBRUEsQ0FBQ0EsRUFBRUEsSUFBSUEsRUFBRUEsRUFBRUEsR0FBR0E7U0FDM0NBLENBQUNBO1FBQ0ZBLElBQUlBLE1BQU1BLEdBQUdBLElBQUlBLENBQUNBLFVBQVVBLENBQUNBLEVBQUVBLEdBQUdBLFdBQVdBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1FBQ3hEQSxJQUFJQSxXQUFXQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUNyQkEsSUFBSUEsVUFBVUEsR0FBR0EsRUFBQ0EsUUFBUUEsRUFBRUEsRUFBRUEsYUFBYUEsRUFBRUEsQ0FBQ0EsRUFBRUEsSUFBSUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBQ0E7WUFDNURBLE9BQU9BLEVBQUVBLEVBQUNBLGFBQWFBLEVBQUVBLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUNBLEVBQUNBLENBQUNBO1FBQ3pEQSw0QkFBNEJBO1FBQzVCQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtRQUNWQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQTtZQUN6QkEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBRUEsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0E7Z0JBQzlCQSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxFQUFFQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDckdBLE1BQU1BLENBQUNBLE1BQU1BLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLEtBQUtBLENBQUNBLE1BQU1BLENBQUNBLE1BQU1BLENBQUNBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUM5REEsTUFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQy9EQSxFQUFFQSxDQUFDQSxDQUFFQSxFQUFFQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxFQUFFQSxJQUFJQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDcENBLE1BQU1BLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUNBLENBQUNBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEdBQUdBLENBQUNBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBO29CQUN4RUEsTUFBTUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsR0FBR0EsQ0FBQ0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsR0FBR0EsQ0FBQ0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ2xGQSxDQUFDQTtZQUNQQSxDQUFDQTtRQUNIQSxDQUFDQTtRQUVEQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxHQUFHQSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxNQUFNQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQTtZQUM1REEsSUFBSUEsS0FBS0EsR0FBR0EsTUFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7WUFDckNBLE1BQU1BLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLE1BQU1BLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBO1lBQ3RGQSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxNQUFNQSxHQUFHQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxLQUFLQSxDQUFDQTtRQUNyRUEsQ0FBQ0E7UUFDREEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBRUEsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsR0FBR0EsTUFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsRUFBRUEsSUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0E7WUFDekRBLElBQUlBLEtBQUtBLEdBQUdBLE1BQU1BLENBQUNBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO1lBQ3ZDQSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxNQUFNQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUN4REEsTUFBTUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsS0FBS0EsQ0FBQ0E7UUFDckNBLENBQUNBO1FBR0RBLElBQUlBLFVBQVVBLEdBQUdBLDBCQUEwQkEsQ0FBQ0EsRUFBRUEsRUFBRUEsTUFBTUEsQ0FBQ0EsQ0FBQ0E7UUFDeERBLElBQUlBLFdBQVdBLEdBQUdBLDBCQUEwQkEsQ0FBQ0EsRUFBRUEsRUFBRUEsVUFBVUEsQ0FBQ0EsQ0FBQ0E7UUFDN0RBLGtCQUFrQkEsQ0FBQ0E7WUFDakJDLE1BQU1BLENBQUNBLENBQUNBLEdBQUdBLElBQUlBLENBQUNBLEVBQUVBLEdBQUdBLEdBQUdBLENBQUNBO1FBQzNCQSxDQUFDQTtRQUVERCxJQUFJQSxrQkFBa0JBLEdBQUdBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ3JDQSxJQUFJQSxrQkFBa0JBLEdBQUdBLFFBQVFBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO1FBQ3RDQSxJQUFJQSxZQUFZQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUV0QkEsSUFBSUEsbUNBQW1DQSxHQUFHQTtZQUN4Q0EsZUFBZUEsRUFBVUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7WUFDckNBLGFBQWFBLEVBQVlBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBO1lBQ3RDQSxZQUFZQSxFQUFhQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtZQUNyQ0EsU0FBU0EsRUFBZ0JBLENBQUNBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBO1NBQzlDQSxDQUFDQTtRQUVGQSxJQUFJQSxvQ0FBb0NBLEdBQUdBO1lBQ3pDQSxxQkFBcUJBLEVBQUlBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBO1lBQ3RDQSxPQUFPQSxFQUFrQkEsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUE7WUFDdENBLHVCQUF1QkEsRUFBRUEsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUE7U0FDdkNBLENBQUNBO1FBR0ZBLG1EQUFtREE7UUFFbkRBLElBQUlBLFNBQVNBLEdBQUdBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO1FBQzFCQSxJQUFJQSxXQUFXQSxHQUFHQTtZQUNkQSxnQkFBZ0JBLEVBQUVBO2dCQUNoQkEsV0FBV0EsRUFBY0EsTUFBTUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsU0FBU0EsRUFBRUEsU0FBU0EsR0FBR0EsR0FBR0EsQ0FBQ0EsRUFBRUEsR0FBR0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsRUFBRUE7Z0JBQ2xGQSxlQUFlQSxFQUFVQSxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxTQUFTQSxFQUFFQSxTQUFTQSxHQUFHQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxFQUFFQTtnQkFDbEZBLG1DQUFtQ0E7Z0JBQ25DQSxVQUFVQSxFQUFlQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtnQkFDckNBLFdBQVdBLEVBQWNBLEdBQUdBO2dCQUM1QkEsZ0JBQWdCQSxFQUFTQSxJQUFJQTtnQkFDN0JBLGFBQWFBLEVBQWVBLFNBQVNBO2dCQUNyQ0EsYUFBYUEsRUFBYUEsU0FBU0E7YUFDcENBO1NBQ0pBLENBQUNBO1FBRUZBLG1DQUFtQ0E7UUFDbkNBLElBQUlBLGdCQUFnQkEsR0FBR0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0E7UUFDckNBLElBQUlBLFVBQVVBLEdBQUdBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBO1FBQy9CQSxJQUFJQSxjQUFjQSxHQUFHQSxJQUFJQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQTtRQUNuQ0EsSUFBSUEsTUFBTUEsR0FBR0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0EsQ0FBRUEsbUJBQW1CQTtRQUNoREEsSUFBSUEsU0FBU0EsR0FBR0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0E7UUFDOUJBLElBQUlBLFVBQVVBLEdBQUdBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBO1FBRy9CQSxJQUFJQSxRQUFRQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUNsQkEsSUFBSUEsT0FBT0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7UUFFaEJBLHFCQUFxQkEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsQ0FBQ0E7UUFFakNBLGtCQUFrQkE7UUFDbEJBLG1CQUFtQkEsSUFBWUE7WUFDN0JFLElBQUlBLElBQUlBLEtBQUtBLENBQUNBO1lBRWZBLElBQUlBLE9BQU9BLEdBQUdBLHdCQUF3QkEsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDM0VBLElBQUlBLFdBQVdBLEdBQUdBLHdCQUF3QkEsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsVUFBVUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDL0VBLElBQUlBLGNBQWNBLEdBQUdBLG9CQUFvQkEsQ0FBQ0EsRUFBRUEsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0E7WUFDdkRBLElBQUlBLGFBQWFBLEdBQUlBLHNCQUFzQkEsQ0FBQ0EsRUFBRUEsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0E7WUFFeERBLGdEQUFnREE7WUFFaERBLHNHQUFzR0E7WUFDdEdBLDRHQUE0R0E7WUFDNUdBLGtFQUFrRUE7WUFDbEVBLHlCQUF5QkEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7WUFFbENBLHVDQUF1Q0E7WUFDdkNBLEVBQUVBLENBQUNBLFFBQVFBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLE1BQU1BLENBQUNBLEtBQUtBLEVBQUVBLE1BQU1BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBO1lBQy9DQSx5Q0FBeUNBO1lBQ3pDQSxFQUFFQSxDQUFDQSxLQUFLQSxDQUFDQSxFQUFFQSxDQUFDQSxnQkFBZ0JBLEdBQUdBLEVBQUVBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7WUFFcERBLGdDQUFnQ0E7WUFDaENBLElBQUlBLE1BQU1BLEdBQUdBLE1BQU1BLENBQUNBLFdBQVdBLEdBQUdBLE1BQU1BLENBQUNBLFlBQVlBLENBQUNBO1lBQ3REQSxJQUFJQSxDQUFDQSxXQUFXQSxDQUFDQSxnQkFBZ0JBLEVBQUNBLGtCQUFrQkEsRUFBRUEsTUFBTUEsRUFBRUEsQ0FBQ0EsRUFBRUEsSUFBSUEsQ0FBQ0EsQ0FBQ0E7WUFFdkVBLDZDQUE2Q0E7WUFDN0NBLElBQUlBLGNBQWNBLEdBQUdBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBO1lBQ2xDQSxJQUFJQSxNQUFNQSxHQUFHQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUN2QkEsSUFBSUEsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDbkJBLElBQUlBLFlBQVlBLEdBQUdBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLG1DQUFtQ0EsQ0FBQ0EsYUFBYUEsRUFBRUEsY0FBY0EsRUFBRUEsTUFBTUEsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0E7WUFFOUdBLDZDQUE2Q0E7WUFDN0NBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLFVBQVVBLEVBQUVBLFlBQVlBLENBQUNBLENBQUNBO1lBRXRDQSxrRUFBa0VBO1lBQ2xFQSxFQUFFQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtZQUN2QkEsdUJBQXVCQSxDQUFDQSxFQUFFQSxFQUFFQSxhQUFhQSxFQUFFQSxVQUFVQSxDQUFDQSxDQUFDQTtZQUV2REEsa0dBQWtHQTtZQUNsR0EsOEZBQThGQTtZQUM5RkEsOEVBQThFQTtZQUM5RUEsV0FBV0EsQ0FBQ0EsY0FBY0EsRUFBRUEsbUNBQW1DQSxDQUFDQSxDQUFDQTtZQUNqRUEsMEVBQTBFQTtZQUUxRUEsMENBQTBDQTtZQUMxQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsY0FBY0EsQ0FBQ0EsQ0FBQ0E7WUFDcENBLElBQUlBLElBQUlBLEdBQUdBO2dCQUNMQSxNQUFNQSxFQUFFQSxTQUFTQTtnQkFDakJBLE9BQU9BLEVBQUdBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBO2dCQUN2QkEsT0FBT0EsRUFBR0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUE7Z0JBQ3ZCQSxVQUFVQSxFQUFFQSxLQUFLQTtnQkFDakJBLGFBQWFBLEVBQUVBLEdBQUdBO2dCQUNsQkEsTUFBTUEsRUFBRUEsR0FBR0E7Z0JBQ1hBLFdBQVdBLEVBQUVBLE1BQU1BLENBQUNBLEdBQUdBLENBQUNBLElBQUlBLENBQUNBLFNBQVNBLEdBQUdBLEdBQUdBLEVBQUVBLFNBQVNBLEdBQUdBLEdBQUdBLENBQUNBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLEVBQUVBLEVBQUVBO2dCQUM5RUEsT0FBT0EsRUFBRUEsU0FBU0E7Z0JBQ2xCQSxLQUFLQSxFQUFFQSxHQUFHQTtnQkFDVkEsU0FBU0EsRUFBRUEsU0FBU0E7Z0JBQ3BCQSxJQUFJQSxFQUFFQSxHQUFHQTtnQkFDVEEsYUFBYUEsRUFBRUEsR0FBR0E7YUFDbkJBLENBQUFBO1lBQ0xBLElBQUlBLE9BQU9BLENBQUNBO1lBQ1ZBLEVBQUVBLENBQUNBLENBQUNBLGlCQUFpQkEsSUFBSUEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ25DQSxJQUFJQSxDQUFDQSxNQUFNQSxHQUFHQSxpQkFBaUJBLENBQUNBO2dCQUNoQ0EsSUFBSUEsQ0FBQ0EsTUFBTUEsR0FBR0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQzNCQSxFQUFFQSxDQUFDQSxDQUFDQSxpQkFBaUJBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUMzQkEsT0FBT0EsQ0FBQ0EsR0FBR0EsRUFBRUEsQ0FBQ0E7b0JBQ2RBLGlCQUFpQkEsR0FBR0EsU0FBU0EsQ0FBQ0E7Z0JBQ2hDQSxDQUFDQTtnQkFBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7b0JBQ05BLEVBQUVBLENBQUNBLENBQUNBLGlCQUFpQkEsSUFBSUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7d0JBQzVCQSxPQUFPQSxHQUFHQSxFQUFFQSxDQUFDQTt3QkFDYkEsaUJBQWlCQSxHQUFHQSxTQUFTQSxDQUFDQTtvQkFDaENBLENBQUNBO29CQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTt3QkFDTkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxJQUFJQSxFQUFFQSxJQUFJQSxpQkFBaUJBLElBQUlBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBOzRCQUN4REEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsaUJBQWlCQSxJQUFJQSxFQUFFQSxJQUFJQSxpQkFBaUJBLElBQUlBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBO2dDQUN4REEsaUJBQWlCQSxHQUFHQSxpQkFBaUJBLEdBQUdBLEVBQUVBLENBQUNBOzRCQUM3Q0EsQ0FBQ0E7NEJBQ0RBLElBQUlBLENBQUNBLEtBQUtBLEdBQUdBLFFBQVFBLENBQUNBLElBQUlBLENBQUNBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBOzRCQUNyQ0EsSUFBSUEsSUFBSUEsR0FBR0EsSUFBSUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsVUFBVUEsRUFBRUEsSUFBSUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0EsQ0FBQ0E7NEJBQ25GQSxJQUFJQSxVQUFVQSxHQUFHQSxJQUFJQSxDQUFDQSxNQUFNQSxDQUFDQTs0QkFDN0JBLElBQUlBLENBQUNBLE1BQU1BLENBQUNBLElBQUlBLENBQUNBLE9BQU9BLEVBQUVBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBLEVBQUVBLElBQUlBLENBQUNBLEtBQUtBLEVBQUVBLElBQUlBLENBQUNBLENBQUNBOzRCQUMzREEsSUFBSUEsQ0FBQ0EsT0FBT0EsR0FBR0EsUUFBUUEsQ0FBQ0EsaUJBQWlCQSxHQUFHQSxFQUFFQSxDQUFDQSxDQUFDQTt3QkFDbERBLENBQUNBO3dCQUNMQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxNQUFNQSxHQUFHQSxRQUFRQSxDQUFDQSxDQUFDQSxDQUFDQTs0QkFDOUJBLE9BQU9BLENBQUNBLEtBQUtBLEVBQUVBLENBQUNBO3dCQUNkQSxDQUFDQTt3QkFDREEsT0FBT0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7d0JBQ25CQSxpQkFBaUJBLEdBQUdBLFNBQVNBLENBQUNBO29CQUNoQ0EsQ0FBQ0E7Z0JBQ0hBLENBQUNBO1lBQ0hBLENBQUNBO1lBQ0RBLElBQUlBLGVBQWVBLEdBQUdBLFdBQVdBLEdBQUdBLEdBQUdBLENBQUNBO1lBRXhDQSxPQUFPQSxHQUFHQSxHQUFHQSxHQUFHQSxRQUFRQSxHQUFHQSxHQUFHQSxDQUFDQTtZQUMvQkEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsR0FBR0EsT0FBT0EsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0E7Z0JBQzFDQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxNQUFNQSxJQUFJQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDNUJBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBLGNBQWNBLENBQUNBLENBQUNBO29CQUNsQ0EsTUFBTUEsR0FBR0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0E7b0JBQ3ZCQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDMUJBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLElBQUlBLElBQUlBLENBQUNBLElBQUlBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGFBQWFBLElBQUlBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBOzRCQUM1REEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsR0FBR0EsS0FBS0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0NBQy9DQSxJQUFJQSxPQUFPQSxHQUFHQSxJQUFJQSxDQUFDQSxhQUFhQSxDQUFDQSxVQUFVQSxFQUFFQSxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxJQUFJQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxDQUFDQTtnQ0FDdEZBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGFBQWFBLEdBQUdBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGFBQWFBLEdBQUdBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGFBQWFBLENBQUNBO2dDQUMvRUEsSUFBSUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsTUFBTUEsRUFBRUEsTUFBTUEsRUFBRUEsUUFBUUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsYUFBYUEsQ0FBQ0EsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0E7NEJBQzNFQSxDQUFDQTs0QkFBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0NBQ05BLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGFBQWFBLEdBQUdBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLGFBQWFBLEdBQUdBLEdBQUdBLENBQUNBO2dDQUMxREEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsRUFBRUEsQ0FBQ0E7Z0NBQ2xCQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxhQUFhQSxHQUFHQSxHQUFHQSxDQUFDQTs0QkFDakNBLENBQUNBO3dCQUNIQSxDQUFDQTt3QkFBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7NEJBQ05BLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFNBQVNBLEdBQUdBLEtBQUtBLENBQUNBOzRCQUM3QkEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsSUFBSUEsR0FBR0EsR0FBR0EsQ0FBQ0E7NEJBQ3RCQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxhQUFhQSxHQUFHQSxHQUFHQSxDQUFDQTs0QkFDL0JBLE1BQU1BLEdBQUdBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBOzRCQUN2QkEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsYUFBYUEsR0FBR0EsR0FBR0EsQ0FBQ0E7d0JBQ2pDQSxDQUFDQTtvQkFDSEEsQ0FBQ0E7b0JBQ0RBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLE9BQU9BLEVBQUVBLE1BQU1BLENBQUNBLENBQUNBO29CQUN0Q0EsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsTUFBTUEsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7b0JBQzlEQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxNQUFNQSxFQUFFQSxNQUFNQSxFQUFFQSxDQUFDQSxlQUFlQSxFQUFFQSxlQUFlQSxFQUFFQSxlQUFlQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDaEZBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLG9DQUFvQ0EsQ0FBQ0EsT0FBT0EsRUFBRUEsTUFBTUEsQ0FBQ0EsQ0FBQ0E7b0JBQ2hFQSxJQUFJQSxDQUFDQSxRQUFRQSxDQUFDQSxNQUFNQSxFQUFFQSxVQUFVQSxFQUFFQSxvQ0FBb0NBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO29CQUNoRkEsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0Esb0NBQW9DQSxDQUFDQSxxQkFBcUJBLEVBQUVBLGdCQUFnQkEsRUFBRUEsTUFBTUEsQ0FBQ0EsQ0FBQ0E7b0JBQ3BHQSxJQUFJQSxDQUFDQSxTQUFTQSxDQUFDQSxvQ0FBb0NBLENBQUNBLHVCQUF1QkEsRUFBRUEsSUFBSUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsTUFBTUEsRUFBRUEsb0NBQW9DQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDaEpBLFdBQVdBLENBQUNBLGNBQWNBLEVBQUVBLG9DQUFvQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ2xFQSxXQUFXQSxDQUFDQSxnQkFBZ0JBLENBQUNBLFdBQVdBLEdBQUdBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFdBQVdBLENBQUNBO29CQUN4RUEsV0FBV0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxhQUFhQSxHQUFHQSxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxFQUFFQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDbkZBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFNBQVNBLEdBQUdBLFdBQVdBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLE9BQU9BLEdBQUdBLE9BQU9BLEdBQUdBLEdBQUdBLEdBQUdBLENBQUNBLE9BQU9BLENBQUNBLE1BQU1BLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLEdBQUdBLENBQUNBO29CQUNoR0EsV0FBV0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxhQUFhQSxHQUFHQSxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxXQUFXQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxPQUFPQSxHQUFHQSxPQUFPQSxHQUFHQSxHQUFHQSxHQUFHQSxDQUFDQSxPQUFPQSxDQUFDQSxNQUFNQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtvQkFDMUlBLFdBQVdBLENBQUNBLGNBQWNBLEVBQUVBLFdBQVdBLENBQUNBLGdCQUFnQkEsQ0FBQ0EsQ0FBQ0E7b0JBQzFEQSxPQUFPQSxHQUFHQSxFQUFFQSxDQUFDQSxhQUFhQSxFQUFFQSxDQUFDQTtvQkFDN0JBLEVBQUVBLENBQUNBLFdBQVdBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLEVBQUVBLE9BQU9BLENBQUNBLENBQUNBO29CQUN2Q0EsRUFBRUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsVUFBVUEsRUFBRUEsRUFBRUEsQ0FBQ0EsY0FBY0EsRUFBRUEsRUFBRUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7b0JBQ3JFQSxFQUFFQSxDQUFDQSxhQUFhQSxDQUFDQSxFQUFFQSxDQUFDQSxVQUFVQSxFQUFFQSxFQUFFQSxDQUFDQSxjQUFjQSxFQUFFQSxFQUFFQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtvQkFDckVBLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLEVBQUVBLEVBQUVBLENBQUNBLGtCQUFrQkEsRUFBRUEsRUFBRUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7b0JBQ25FQSxFQUFFQSxDQUFDQSxhQUFhQSxDQUFDQSxFQUFFQSxDQUFDQSxVQUFVQSxFQUFFQSxFQUFFQSxDQUFDQSxrQkFBa0JBLEVBQUVBLEVBQUVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO29CQUNuRUEsRUFBRUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsVUFBVUEsRUFBRUEsQ0FBQ0EsRUFBRUEsRUFBRUEsQ0FBQ0EsSUFBSUEsRUFBRUEsRUFBRUEsQ0FBQ0EsSUFBSUEsRUFBRUEsRUFBRUEsQ0FBQ0EsYUFBYUEsRUFBRUEsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3hGQSxFQUFFQSxDQUFDQSxZQUFZQSxDQUFDQSxFQUFFQSxDQUFDQSxTQUFTQSxFQUFFQSxVQUFVQSxDQUFDQSxXQUFXQSxFQUFFQSxFQUFFQSxDQUFDQSxjQUFjQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDOUVBLENBQUNBO1lBQ0RBLENBQUNBO1lBQ0RBLEVBQUVBLENBQUNBLENBQUNBLFNBQVNBLElBQUlBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBO2dCQUMzQkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsTUFBTUEsSUFBSUEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQ3hCQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxJQUFJQSxTQUFTQSxDQUFDQSxDQUFDQSxDQUFDQTt3QkFDeEJBLElBQUlBLGFBQWFBLEdBQUdBLEdBQUdBLENBQUNBO3dCQUNwQkEsSUFBSUEsUUFBUUEsR0FBR0EsUUFBUUEsQ0FBQ0E7d0JBQ3hCQSxJQUFJQSxNQUFNQSxHQUFHQSxTQUFTQSxDQUFDQTt3QkFFdkJBLGFBQWFBLEdBQUdBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLEdBQUdBLENBQUNBO3dCQUNuQ0EsYUFBYUEsR0FBR0EsYUFBYUEsR0FBQ0EsR0FBR0EsQ0FBQ0E7d0JBQ2xDQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxPQUFPQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxDQUFDQTs0QkFDeENBLEVBQUVBLENBQUNBLENBQUNBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLGFBQWFBLEdBQUdBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFNBQVNBLENBQUNBLEdBQUdBLFFBQVFBLENBQUNBLENBQUFBLENBQUNBO2dDQUM3REEsTUFBTUEsR0FBR0EsQ0FBQ0EsQ0FBQ0E7Z0NBQ1hBLFFBQVFBLEdBQUdBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLGFBQWFBLEdBQUdBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBOzRCQUM1REEsQ0FBQ0E7d0JBQ0hBLENBQUNBO3dCQUNEQSxFQUFFQSxDQUFDQSxDQUFDQSxPQUFPQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxVQUFVQSxJQUFJQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQTs0QkFDNUNBLE9BQU9BLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLFVBQVVBLEdBQUdBLElBQUlBLENBQUNBOzRCQUNsQ0EsT0FBT0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0EsSUFBSUEsR0FBR0EsUUFBUUEsR0FBR0EsR0FBR0EsQ0FBQ0E7NEJBQ3RDQSxPQUFPQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxhQUFhQSxHQUFHQSxPQUFPQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxJQUFJQSxHQUFHQSxJQUFJQSxDQUFDQTs0QkFDNURBLElBQUlBLFdBQVdBLEdBQUdBLElBQUlBLElBQUlBLENBQUNBO2dDQUN6QkEsSUFBSUEsRUFBRUEsQ0FBQ0EsaUJBQWlCQSxDQUFDQTs2QkFDMUJBLENBQUNBLENBQUNBLElBQUlBLEVBQUVBLENBQUNBO3dCQUNSQSxDQUFDQTtvQkFDSEEsQ0FBQ0E7Z0JBQ0hBLENBQUNBO2dCQUNEQSxTQUFTQSxHQUFHQSxTQUFTQSxDQUFDQTtZQUN4QkEsQ0FBQ0E7WUFDREEsRUFBRUEsQ0FBQ0EsVUFBVUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsQ0FBQ0E7WUFDM0JBLGNBQWNBLEdBQUdBLG9CQUFvQkEsQ0FBQ0EsRUFBRUEsRUFBRUEsV0FBV0EsQ0FBQ0EsQ0FBQ0E7WUFDdkRBLGFBQWFBLEdBQUdBLHNCQUFzQkEsQ0FBQ0EsRUFBRUEsRUFBRUEsV0FBV0EsQ0FBQ0EsQ0FBQ0E7WUFDeERBLElBQUlBLGVBQWVBLEdBQUdBO2dCQUNwQkEscUJBQXFCQSxFQUFHQSxJQUFJQSxDQUFDQSxNQUFNQSxFQUFFQTtnQkFDckNBLFdBQVdBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO2dCQUN6QkEsZUFBZUEsRUFBRUEsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUE7Z0JBQzlCQSxRQUFRQSxFQUFFQSxHQUFHQTthQUNkQSxDQUFBQTtZQUNEQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxDQUFDQSxHQUFHQSxPQUFPQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxFQUFFQSxFQUFFQSxDQUFDQTtnQkFDMUNBLEVBQUVBLENBQUNBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBLENBQUNBLENBQUNBLE1BQU1BLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO29CQUM1QkEsSUFBSUEsYUFBYUEsR0FBR0EsV0FBV0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsT0FBT0EsR0FBR0EsT0FBT0EsR0FBR0EsR0FBR0EsR0FBR0EsQ0FBQ0EsT0FBT0EsQ0FBQ0EsTUFBTUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsR0FBR0EsQ0FBQ0E7b0JBQzdGQSxlQUFlQSxDQUFDQSxXQUFXQSxHQUFHQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxXQUFXQSxDQUFDQTtvQkFDckRBLGVBQWVBLENBQUNBLGVBQWVBLEdBQUdBLElBQUlBLENBQUNBLFVBQVVBLENBQUNBLGFBQWFBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO29CQUMxRUEsZUFBZUEsQ0FBQ0EsUUFBUUEsR0FBR0EsT0FBT0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsTUFBTUEsR0FBR0EsR0FBR0EsQ0FBQ0E7b0JBQ25EQSx1QkFBdUJBLENBQUNBLEVBQUVBLEVBQUVBLGFBQWFBLEVBQUVBLFdBQVdBLENBQUNBLENBQUNBO29CQUN4REEsV0FBV0EsQ0FBQ0EsY0FBY0EsRUFBRUEsZUFBZUEsQ0FBQ0EsQ0FBQ0E7b0JBQzdDQSxFQUFFQSxDQUFDQSxTQUFTQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQTtvQkFDbEJBLEVBQUVBLENBQUNBLFlBQVlBLENBQUNBLEVBQUVBLENBQUNBLEtBQUtBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLENBQUNBLGNBQWNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO2dCQUNyREEsQ0FBQ0E7WUFDREEsQ0FBQ0E7WUFFREEscUJBQXFCQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQTtRQUNuQ0EsQ0FBQ0E7SUFDSEYsQ0FBQ0EiLCJmaWxlIjoiYTUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLy88cmVmZXJlbmNlIHBhdGg9Jy4vdHlwaW5ncy90c2QuZC50cycvPlxuLy8vPHJlZmVyZW5jZSBwYXRoPVwiLi9sb2NhbFR5cGluZ3Mvd2ViZ2x1dGlscy5kLnRzXCIvPlxuLy9nZXQgc3RhcnQgYnkgc3R1ZmYgbm90IGluIHNoYWRlcnNcbi8vXG4vKlxuICogUG9ydGlvbnMgb2YgdGhpcyBjb2RlIGFyZVxuICogQ29weXJpZ2h0IDIwMTUsIEJsYWlyIE1hY0ludHlyZS5cbiAqIFxuICogUG9ydGlvbnMgb2YgdGhpcyBjb2RlIHRha2VuIGZyb20gaHR0cDovL3dlYmdsZnVuZGFtZW50YWxzLm9yZywgYXQgaHR0cHM6Ly9naXRodWIuY29tL2dyZWdnbWFuL3dlYmdsLWZ1bmRhbWVudGFsc1xuICogYW5kIGFyZSBzdWJqZWN0IHRvIHRoZSBmb2xsb3dpbmcgbGljZW5zZS4gIEluIHBhcnRpY3VsYXIsIGZyb20gXG4gKiAgICBodHRwOi8vd2ViZ2xmdW5kYW1lbnRhbHMub3JnL3dlYmdsL3dlYmdsLWxlc3MtY29kZS1tb3JlLWZ1bi5odG1sXG4gKiAgICBodHRwOi8vd2ViZ2xmdW5kYW1lbnRhbHMub3JnL3dlYmdsL3Jlc291cmNlcy9wcmltaXRpdmVzLmpzXG4gKiBcbiAqIFRob3NlIHBvcnRpb25zIENvcHlyaWdodCAyMDE0LCBHcmVnZyBUYXZhcmVzLlxuICogQWxsIHJpZ2h0cyByZXNlcnZlZC5cbiAqL1xuXG5pbXBvcnQgbG9hZGVyID0gcmVxdWlyZSgnLi9sb2FkZXInKTtcblxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIHN0YXRzIG1vZHVsZSBieSBtcmRvb2IgKGh0dHBzOi8vZ2l0aHViLmNvbS9tcmRvb2Ivc3RhdHMuanMpIHRvIHNob3cgdGhlIHBlcmZvcm1hbmNlIFxuXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gdXRpbGl0aWVzXG52YXIgcmFuZCA9IGZ1bmN0aW9uKG1pbjogbnVtYmVyLCBtYXg/OiBudW1iZXIpIHtcbiAgaWYgKG1heCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgbWF4ID0gbWluO1xuICAgIG1pbiA9IDA7XG4gIH1cbiAgcmV0dXJuIG1pbiArIE1hdGgucmFuZG9tKCkgKiAobWF4IC0gbWluKTtcbn07XG5cbnZhciByYW5kSW50ID0gZnVuY3Rpb24ocmFuZ2UpIHtcbiAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIHJhbmdlKTtcbn07XG5cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBnZXQgc29tZSBvZiBvdXIgY2FudmFzIGVsZW1lbnRzIHRoYXQgd2UgbmVlZFxudmFyIGNhbnZhcyA9IDxIVE1MQ2FudmFzRWxlbWVudD5kb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIndlYmdsXCIpOyAgXG5cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBzb21lIHNpbXBsZSBpbnRlcmFjdGlvbiB1c2luZyB0aGUgbW91c2UuXG4vLyB3ZSBhcmUgZ29pbmcgdG8gZ2V0IHNtYWxsIG1vdGlvbiBvZmZzZXRzIG9mIHRoZSBtb3VzZSwgYW5kIHVzZSB0aGVzZSB0byByb3RhdGUgdGhlIG9iamVjdFxuLy9cbi8vIG91ciBvZmZzZXQoKSBmdW5jdGlvbiBmcm9tIGFzc2lnbm1lbnQgMCwgdG8gZ2l2ZSB1cyBhIGdvb2QgbW91c2UgcG9zaXRpb24gaW4gdGhlIGNhbnZhcyBcbmZ1bmN0aW9uIG9mZnNldChlOiBNb3VzZUV2ZW50KTogR0xNLklBcnJheSB7XG4gICAgZSA9IGUgfHwgPE1vdXNlRXZlbnQ+IHdpbmRvdy5ldmVudDtcblxuICAgIHZhciB0YXJnZXQgPSA8RWxlbWVudD4gZS50YXJnZXQgfHwgZS5zcmNFbGVtZW50LFxuICAgICAgICByZWN0ID0gdGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgICBvZmZzZXRYID0gZS5jbGllbnRYIC0gcmVjdC5sZWZ0LFxuICAgICAgICBvZmZzZXRZID0gZS5jbGllbnRZIC0gcmVjdC50b3A7XG5cbiAgICByZXR1cm4gdmVjMi5mcm9tVmFsdWVzKG9mZnNldFgsIG9mZnNldFkpO1xufVxudmFyIG1vdXNlRG93biA9IHVuZGVmaW5lZDtcbnZhciBwcmVzc0Zyb21LZXlib2FyZCA9IHVuZGVmaW5lZDtcbi8vIHRoZSBhbW91bnQgdGhlIG1vdXNlIGhhcyBtb3ZlZCAvLyBhbmdsZSBvZmZzZXQgY29ycmVzcG9uZGluZyB0byBtb3VzZSBtb3ZlbWVudFxuXG4vLyBzdGFydCB0aGluZ3Mgb2ZmIHdpdGggYSBkb3duIHByZXNzXG5jYW52YXMub25tb3VzZWRvd24gPSAoZXY6IE1vdXNlRXZlbnQpID0+IHtcbiAgbW91c2VEb3duID0gb2Zmc2V0KGV2KTtcbn1cblxuLy8gc3RvcCB0aGluZ3Mgd2l0aCBhIG1vdXNlIHJlbGVhc2VcblxuLy8gaWYgd2UncmUgbW92aW5nIGFuZCB0aGUgbW91c2UgaXMgZG93biAgICAgICAgXG5kb2N1bWVudC5vbmtleXByZXNzID0gKGV2OktleWJvYXJkRXZlbnQpID0+IHtcbiAgcHJlc3NGcm9tS2V5Ym9hcmQgPSBldi5rZXlDb2RlO1xuICBpZiAoZXYua2V5Q29kZSA9PSAzMikge1xuICAgIGV2LnByZXZlbnREZWZhdWx0KCk7XG4gIH1cbiAgdmFyIGVmZmVjdCA9IG5ldyBIb3dsKHtcbiAgICB1cmxzOiBbJ3NvdW5kcy90eXBpbmcubXAzJ11cbiAgfSkucGxheSgpO1xufVxuZG9jdW1lbnQub25rZXlkb3duID0gKGV2OiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gIHByZXNzRnJvbUtleWJvYXJkID0gZXYua2V5Q29kZTtcbiAgaWYgKGV2LmtleUNvZGUgPT0gOCkge1xuICAgIGV2LnByZXZlbnREZWZhdWx0KCk7XG4gIH1cbn1cbi8vIHN0b3AgdGhpbmdzIGlmIHlvdSBtb3ZlIG91dCBvZiB0aGUgd2luZG93XG5cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBzdGFydCB0aGluZ3Mgb2ZmIGJ5IGNhbGxpbmcgaW5pdFdlYkdMXG5pbml0V2ViR0woKTtcblxuZnVuY3Rpb24gaW5pdFdlYkdMKCkge1xuICAvLyBnZXQgdGhlIHJlbmRlcmluZyBjb250ZXh0IGZvciB3ZWJHTFxuICB2YXIgZ2w6IFdlYkdMUmVuZGVyaW5nQ29udGV4dCA9IGdldFdlYkdMQ29udGV4dChjYW52YXMpO1xuICBpZiAoIWdsKSB7XG4gICAgcmV0dXJuOyAgLy8gbm8gd2ViZ2whICBCeWUgYnllXG4gIH1cblxuICAvLyB0dXJuIG9uIGJhY2tmYWNlIGN1bGxpbmcgYW5kIHpidWZmZXJpbmdcbiAgLy9nbC5lbmFibGUoZ2wuQ1VMTF9GQUNFKTtcbiAgZ2wuZW5hYmxlKGdsLkRFUFRIX1RFU1QpO1xuXG4gIC8vIGF0dGVtcHQgdG8gZG93bmxvYWQgYW5kIHNldCB1cCBvdXIgR0xTTCBzaGFkZXJzLiAgV2hlbiB0aGV5IGRvd25sb2FkLCBwcm9jZXNzZWQgdG8gdGhlIG5leHQgc3RlcFxuICAvLyBvZiBvdXIgcHJvZ3JhbSwgdGhlIFwibWFpblwiIHJvdXRpbmdcbiAgLy8gXG4gIC8vIFlPVSBTSE9VTEQgTU9ESUZZIFRISVMgVE8gRE9XTkxPQUQgQUxMIFlPVVIgU0hBREVSUyBhbmQgc2V0IHVwIGFsbCBmb3VyIFNIQURFUiBQUk9HUkFNUyxcbiAgLy8gVEhFTiBQQVNTIEFOIEFSUkFZIE9GIFBST0dSQU1TIFRPIG1haW4oKS4gIFlvdSdsbCBoYXZlIHRvIGRvIG90aGVyIHRoaW5ncyBpbiBtYWluIHRvIGRlYWxcbiAgLy8gd2l0aCBtdWx0aXBsZSBzaGFkZXJzIGFuZCBzd2l0Y2ggYmV0d2VlbiB0aGVtXG4gIGxvYWRlci5sb2FkRmlsZXMoWydzaGFkZXJzL2EzLXNoYWRlci52ZXJ0JywgJ3NoYWRlcnMvYTMtc2hhZGVyLmZyYWcnLFxuICAgICdzaGFkZXJzL3NoYWRlcnMtbGluZS52ZXJ0JywgJ3NoYWRlcnMvc2hhZGVycy1saW5lLmZyYWcnXSxmdW5jdGlvbiAoc2hhZGVyVGV4dCkge1xuICAgIC8vIHZhciBwcm9ncmFtID0gY3JlYXRlUHJvZ3JhbUZyb21Tb3VyY2VzKGdsLCBbc2hhZGVyVGV4dFswXSwgc2hhZGVyVGV4dFsxXV0pO1xuICAgIG1haW4oZ2wsIHNoYWRlclRleHQpO1xuICB9LCBmdW5jdGlvbiAodXJsKSB7XG4gICAgICBhbGVydCgnU2hhZGVyIGZhaWxlZCB0byBkb3dubG9hZCBcIicgKyB1cmwgKyAnXCInKTtcbiAgfSk7XG59XG5cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyB3ZWJHTCBpcyBzZXQgdXAsIGFuZCBvdXIgU2hhZGVyIHByb2dyYW0gaGFzIGJlZW4gY3JlYXRlZC4gIEZpbmlzaCBzZXR0aW5nIHVwIG91ciB3ZWJHTCBhcHBsaWNhdGlvbiAgICAgICBcbmZ1bmN0aW9uIG1haW4oZ2w6IFdlYkdMUmVuZGVyaW5nQ29udGV4dCwgc2hhZGVyVGV4dCkge1xuICB2YXIgdGV4dHVyZXMgPSBbXTtcbiAgdmFyIGxldHRlcnMgPSBbXTtcbiAgZm9yICh2YXIgaWkgPSAwOyBpaSA8IDI2OyBpaSsrKSB7XG4gICAgdmFyIGN1cnIgPSBuZXcgSW1hZ2UoKTtcbiAgICB0ZXh0dXJlcy5wdXNoKGN1cnIpO1xuICAgIGN1cnIub25sb2FkID0gZnVuY3Rpb24oKSB7XG4gICAgICBsZXR0ZXJzW2lpXS5zcmMgPSB0aGlzLnNyYztcbiAgICB9XG4gICAgY3Vyci5zcmMgPSBcImxldHRlcnMvXCIgKyBcIm15bGV0dGVyXCIgKyBpaS50b1N0cmluZygpICsgXCIuanBnXCI7XG4gIH1cbiAgLy8gaW1hZ2VzLnB1c2goaW1hZ2UyKTtcbiAgLy8gdXNlIHRoZSB3ZWJnbC11dGlscyBsaWJyYXJ5IHRvIGNyZWF0ZSBzZXR0ZXJzIGZvciBhbGwgdGhlIHVuaWZvcm1zIGFuZCBhdHRyaWJ1dGVzIGluIG91ciBzaGFkZXJzLlxuICAvLyBJdCBlbnVtZXJhdGVzIGFsbCBvZiB0aGUgdW5pZm9ybXMgYW5kIGF0dHJpYnV0ZXMgaW4gdGhlIHByb2dyYW0sIGFuZCBjcmVhdGVzIHV0aWxpdHkgZnVuY3Rpb25zIHRvIFxuICAvLyBhbGxvdyBcInNldFVuaWZvcm1zXCIgYW5kIFwic2V0QXR0cmlidXRlc1wiIChiZWxvdykgdG8gc2V0IHRoZSBzaGFkZXIgdmFyaWFibGVzIGZyb20gYSBqYXZhc2NyaXB0IG9iamVjdC4gXG4gIC8vIFRoZSBvYmplY3RzIGhhdmUgYSBrZXkgZm9yIGVhY2ggdW5pZm9ybSBvciBhdHRyaWJ1dGUsIGFuZCBhIHZhbHVlIGNvbnRhaW5pbmcgdGhlIHBhcmFtZXRlcnMgZm9yIHRoZVxuICAvLyBzZXR0ZXIgZnVuY3Rpb25cbiAgLy8gdmFyIHByb2dyYW0gPSBjcmVhdGVQcm9ncmFtRnJvbVNvdXJjZXMoZ2wsIFtzaGFkZXJUZXh0W2VmZmVjdEldLCBzaGFkZXJUZXh0W2VmZmVjdEkgKyAxXV0pO1xuICAvLyB2YXIgdW5pZm9ybVNldHRlcnMgPSBjcmVhdGVVbmlmb3JtU2V0dGVycyhnbCwgcHJvZ3JhbSk7XG4gIC8vIHZhciBhdHRyaWJTZXR0ZXJzICA9IGNyZWF0ZUF0dHJpYnV0ZVNldHRlcnMoZ2wsIHByb2dyYW0pO1xuXG4gIC8vIGFuIGluZGV4ZWQgcXVhZFxuICB2YXIgYXJyYXlzID0ge1xuICAgICBwb3NpdGlvbjogeyBudW1Db21wb25lbnRzOiAzLCBkYXRhOiBbXSwgfSxcbiAgICAgdGV4Y29vcmQ6IHsgbnVtQ29tcG9uZW50czogMiwgZGF0YTogW10sIH0sXG4gICAgIG5vcm1hbDogICB7IG51bUNvbXBvbmVudHM6IDMsIGRhdGE6IFtdLCB9LFxuICAgICBpbmRpY2VzOiAgeyBudW1Db21wb25lbnRzOiAzLCBkYXRhOiBbXSwgfSxcbiAgfTtcbiAgdmFyIGNlbnRlciA9IHZlYzQuZnJvbVZhbHVlcyg3MCAqIHNjYWxlRmFjdG9yLCAwLCAwLCAwKTtcbiAgdmFyIHNjYWxlRmFjdG9yID0gMTA7XG4gIHZhciBsaW5lQXJyYXlzID0ge3Bvc2l0aW9uOiB7IG51bUNvbXBvbmVudHM6IDMsIGRhdGE6IFswLCAxLCAwLCAwLCAtMSwgMF19LFxuICAgICAgICAgICAgICAgIGluZGljZXM6IHtudW1Db21wb25lbnRzOiAxLCBkYXRhOiBbMCwgMV19fTtcbiAgLy8gY29uc29sZS5sb2cobmV3UG9zaXRpb24pO1xuICB2YXIgbiA9IDI7XG4gIGZvciAodmFyIGlpID0gMDsgaWkgPCBuO2lpKyspIHtcbiAgICAgICAgZm9yICh2YXIgamogPSAwOyBqaiA8IG47IGpqKyspIHtcbiAgICAgICAgICBhcnJheXMucG9zaXRpb24uZGF0YS5wdXNoLmFwcGx5KGFycmF5cy5wb3NpdGlvbi5kYXRhLCBbamogKiAoMTAgLyAobiAtIDEpKSwgaWkgKiAoMTAgLyAobiAtIDEpKSwgMF0pO1xuICAgICAgICAgIGFycmF5cy5ub3JtYWwuZGF0YS5wdXNoLmFwcGx5KGFycmF5cy5ub3JtYWwuZGF0YSwgWzAsIDAsIC0xXSk7XG4gICAgICAgICAgYXJyYXlzLnRleGNvb3JkLmRhdGEucHVzaChqaiAqIDEgLyAobiAtMSksIGlpICogKDEgLyAobiAtIDEpKSk7XG4gICAgICAgICAgaWYgKCBpaSAhPSBuIC0gMSAmJiBqaiAhPSBuIC0gMSkge1xuICAgICAgICBhcnJheXMuaW5kaWNlcy5kYXRhLnB1c2goamogKyBpaSAqIG4sIGpqICsgaWkqbiArIDEsIGpqICsgKGlpICsgMSkgKiBuKTtcbiAgICAgICAgYXJyYXlzLmluZGljZXMuZGF0YS5wdXNoKGpqICsgaWkgKiBuICsgMSwgamogKyAoaWkgKyAxKSAqIG4sIGpqICsgKGlpICsgMSkgKiBuICsgMSk7XG4gICAgICAgICAgfSBcbiAgICB9XG4gIH1cblxuICBmb3IgKHZhciBpaSA9IDA7IGlpIDwgYXJyYXlzLnRleGNvb3JkLmRhdGEubGVuZ3RoIC8gMjsgaWkrKykge1xuICAgIHZhciB0ZW1wdCA9IGFycmF5cy50ZXhjb29yZC5kYXRhW2lpXTtcbiAgICBhcnJheXMudGV4Y29vcmQuZGF0YVtpaV0gPSBhcnJheXMudGV4Y29vcmQuZGF0YVthcnJheXMudGV4Y29vcmQuZGF0YS5sZW5ndGggLSBpaSAtIDFdO1xuICAgIGFycmF5cy50ZXhjb29yZC5kYXRhW2FycmF5cy50ZXhjb29yZC5kYXRhLmxlbmd0aCAtIGlpIC0gMV0gPSB0ZW1wdDtcbiAgfVxuICBmb3IgKHZhciBpaSA9IDA7IGlpIDwgYXJyYXlzLnRleGNvb3JkLmRhdGEubGVuZ3RoOyBpaSs9Mikge1xuICAgIHZhciB0ZW1wdCA9IGFycmF5cy50ZXhjb29yZC5kYXRhW2lpXTtcbiAgYXJyYXlzLnRleGNvb3JkLmRhdGFbaWldID0gYXJyYXlzLnRleGNvb3JkLmRhdGFbaWkgKyAxXTtcbiAgYXJyYXlzLnRleGNvb3JkLmRhdGFbaWkgKyAxXSA9IHRlbXB0O1xuICB9XG5cblxuICB2YXIgYnVmZmVySW5mbyA9IGNyZWF0ZUJ1ZmZlckluZm9Gcm9tQXJyYXlzKGdsLCBhcnJheXMpO1xuICB2YXIgYnVmZmVySW5mbzAgPSBjcmVhdGVCdWZmZXJJbmZvRnJvbUFycmF5cyhnbCwgbGluZUFycmF5cyk7XG4gIGZ1bmN0aW9uIGRlZ1RvUmFkKGQpIHtcbiAgICByZXR1cm4gZCAqIE1hdGguUEkgLyAxODA7XG4gIH1cblxuICB2YXIgY2FtZXJhQW5nbGVSYWRpYW5zID0gZGVnVG9SYWQoMCk7XG4gIHZhciBmaWVsZE9mVmlld1JhZGlhbnMgPSBkZWdUb1JhZCg2MCk7XG4gIHZhciBjYW1lcmFIZWlnaHQgPSA1MDtcblxuICB2YXIgdW5pZm9ybXNUaGF0QXJlVGhlU2FtZUZvckFsbE9iamVjdHMgPSB7XG4gICAgdV9saWdodFdvcmxkUG9zOiAgICAgICAgIFswLCAwLCAtMTAwXSxcbiAgICB1X3ZpZXdJbnZlcnNlOiAgICAgICAgICAgbWF0NC5jcmVhdGUoKSxcbiAgICB1X2xpZ2h0Q29sb3I6ICAgICAgICAgICAgWzEsIDEsIDEsIDFdLFxuICAgIHVfYW1iaWVudDogICAgICAgICAgICAgICBbMC4xLCAwLjEsIDAuMSwgMC4xXSxcbiAgfTtcblxuICB2YXIgdW5pZm9ybXNUaGF0QXJlQ29tcHV0ZWRGb3JFYWNoT2JqZWN0ID0ge1xuICAgIHVfd29ybGRWaWV3UHJvamVjdGlvbjogICBtYXQ0LmNyZWF0ZSgpLFxuICAgIHVfd29ybGQ6ICAgICAgICAgICAgICAgICBtYXQ0LmNyZWF0ZSgpLFxuICAgIHVfd29ybGRJbnZlcnNlVHJhbnNwb3NlOiBtYXQ0LmNyZWF0ZSgpLFxuICB9O1xuXG5cbiAgLy8gdmFyIHRleHR1cmUgPSAuLi4uIGNyZWF0ZSBhIHRleHR1cmUgb2Ygc29tZSBmb3JtXG5cbiAgdmFyIGJhc2VDb2xvciA9IHJhbmQoMjQwKTtcbiAgdmFyIG9iamVjdFN0YXRlID0geyBcbiAgICAgIG1hdGVyaWFsVW5pZm9ybXM6IHtcbiAgICAgICAgdV9jb2xvck11bHQ6ICAgICAgICAgICAgIGNocm9tYS5oc3YocmFuZChiYXNlQ29sb3IsIGJhc2VDb2xvciArIDEyMCksIDAuNSwgMSkuZ2woKSxcbiAgICAgICAgdV9jb2xvck9mTGV0dGVyOiAgICAgICAgIGNocm9tYS5oc3YocmFuZChiYXNlQ29sb3IsIGJhc2VDb2xvciArIDEyMCksIDAuNSwgMSkuZ2woKSxcbiAgICAgICAgLy91X2RpZmZ1c2U6ICAgICAgICAgICAgICAgdGV4dHVyZSxcbiAgICAgICAgdV9zcGVjdWxhcjogICAgICAgICAgICAgIFsxLCAxLCAxLCAxXSxcbiAgICAgICAgdV9zaGluaW5lc3M6ICAgICAgICAgICAgIDQ1MCxcbiAgICAgICAgdV9zcGVjdWxhckZhY3RvcjogICAgICAgIDAuNzUsXG4gICAgICAgIHVfZGlzVG9DZW50ZXI6ICAgICAgICAgICAgICB1bmRlZmluZWQsXG4gICAgICAgIHVfdmVydGljYWxQb3M6ICAgICAgICAgICAgdW5kZWZpbmVkXG4gICAgICB9XG4gIH07XG5cbiAgLy8gc29tZSB2YXJpYWJsZXMgd2UnbGwgcmV1c2UgYmVsb3dcbiAgdmFyIHByb2plY3Rpb25NYXRyaXggPSBtYXQ0LmNyZWF0ZSgpO1xuICB2YXIgdmlld01hdHJpeCA9IG1hdDQuY3JlYXRlKCk7XG4gIHZhciByb3RhdGlvbk1hdHJpeCA9IG1hdDQuY3JlYXRlKCk7XG4gIHZhciBtYXRyaXggPSBtYXQ0LmNyZWF0ZSgpOyAgLy8gYSBzY3JhdGNoIG1hdHJpeFxuICB2YXIgaW52TWF0cml4ID0gbWF0NC5jcmVhdGUoKTtcbiAgdmFyIGF4aXNWZWN0b3IgPSB2ZWMzLmNyZWF0ZSgpO1xuXG5cbiAgdmFyIGNhcGFjaXR5ID0gMTQ7XG4gIHZhciBzcGFjaW5nID0gMDtcblxuICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZHJhd1NjZW5lKTtcblxuICAvLyBEcmF3IHRoZSBzY2VuZS5cbiAgZnVuY3Rpb24gZHJhd1NjZW5lKHRpbWU6IG51bWJlcikge1xuICAgIHRpbWUgKj0gMC4wMDE7XG4gICAgICBcbiAgIHZhciBwcm9ncmFtID0gY3JlYXRlUHJvZ3JhbUZyb21Tb3VyY2VzKGdsLCBbc2hhZGVyVGV4dFswXSwgc2hhZGVyVGV4dFsxXV0pO1xuICAgdmFyIGxpbmVQcm9ncmFtID0gY3JlYXRlUHJvZ3JhbUZyb21Tb3VyY2VzKGdsLCBbc2hhZGVyVGV4dFsyXSwgc2hhZGVyVGV4dFszXV0pO1xuICAgdmFyIHVuaWZvcm1TZXR0ZXJzID0gY3JlYXRlVW5pZm9ybVNldHRlcnMoZ2wsIHByb2dyYW0pO1xuICAgdmFyIGF0dHJpYlNldHRlcnMgID0gY3JlYXRlQXR0cmlidXRlU2V0dGVycyhnbCwgcHJvZ3JhbSk7XG5cbiAgICAvLyBtZWFzdXJlIHRpbWUgdGFrZW4gZm9yIHRoZSBsaXR0bGUgc3RhdHMgbWV0ZXJcblxuICAgIC8vIGlmIHRoZSB3aW5kb3cgY2hhbmdlZCBzaXplLCByZXNldCB0aGUgV2ViR0wgY2FudmFzIHNpemUgdG8gbWF0Y2guICBUaGUgZGlzcGxheWVkIHNpemUgb2YgdGhlIGNhbnZhc1xuICAgIC8vIChkZXRlcm1pbmVkIGJ5IHdpbmRvdyBzaXplLCBsYXlvdXQsIGFuZCB5b3VyIENTUykgaXMgc2VwYXJhdGUgZnJvbSB0aGUgc2l6ZSBvZiB0aGUgV2ViR0wgcmVuZGVyIGJ1ZmZlcnMsIFxuICAgIC8vIHdoaWNoIHlvdSBjYW4gY29udHJvbCBieSBzZXR0aW5nIGNhbnZhcy53aWR0aCBhbmQgY2FudmFzLmhlaWdodFxuICAgIHJlc2l6ZUNhbnZhc1RvRGlzcGxheVNpemUoY2FudmFzKTtcblxuICAgIC8vIFNldCB0aGUgdmlld3BvcnQgdG8gbWF0Y2ggdGhlIGNhbnZhc1xuICAgIGdsLnZpZXdwb3J0KDAsIDAsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCk7XG4gICAgLy8gQ2xlYXIgdGhlIGNhbnZhcyBBTkQgdGhlIGRlcHRoIGJ1ZmZlci5cbiAgICBnbC5jbGVhcihnbC5DT0xPUl9CVUZGRVJfQklUIHwgZ2wuREVQVEhfQlVGRkVSX0JJVCk7XG5cbiAgICAvLyBDb21wdXRlIHRoZSBwcm9qZWN0aW9uIG1hdHJpeFxuICAgIHZhciBhc3BlY3QgPSBjYW52YXMuY2xpZW50V2lkdGggLyBjYW52YXMuY2xpZW50SGVpZ2h0O1xuICAgIG1hdDQucGVyc3BlY3RpdmUocHJvamVjdGlvbk1hdHJpeCxmaWVsZE9mVmlld1JhZGlhbnMsIGFzcGVjdCwgMSwgMjAwMCk7XG5cbiAgICAvLyBDb21wdXRlIHRoZSBjYW1lcmEncyBtYXRyaXggdXNpbmcgbG9vayBhdC5cbiAgICB2YXIgY2FtZXJhUG9zaXRpb24gPSBbMCwgMCwgLTIwMF07XG4gICAgdmFyIHRhcmdldCA9IFswLCAwLCAwXTtcbiAgICB2YXIgdXAgPSBbMCwgMSwgMF07XG4gICAgdmFyIGNhbWVyYU1hdHJpeCA9IG1hdDQubG9va0F0KHVuaWZvcm1zVGhhdEFyZVRoZVNhbWVGb3JBbGxPYmplY3RzLnVfdmlld0ludmVyc2UsIGNhbWVyYVBvc2l0aW9uLCB0YXJnZXQsIHVwKTtcblxuICAgIC8vIE1ha2UgYSB2aWV3IG1hdHJpeCBmcm9tIHRoZSBjYW1lcmEgbWF0cml4LlxuICAgIG1hdDQuaW52ZXJ0KHZpZXdNYXRyaXgsIGNhbWVyYU1hdHJpeCk7XG4gICAgXG4gICAgLy8gdGVsbCBXZWJHTCB0byB1c2Ugb3VyIHNoYWRlciBwcm9ncmFtICh3aWxsIG5lZWQgdG8gY2hhbmdlIHRoaXMpXG4gICAgZ2wudXNlUHJvZ3JhbShwcm9ncmFtKTtcbiAgICBzZXRCdWZmZXJzQW5kQXR0cmlidXRlcyhnbCwgYXR0cmliU2V0dGVycywgYnVmZmVySW5mbyk7XG5cbiAgICAvLyBTZXQgdGhlIHVuaWZvcm1zIHRoYXQgYXJlIHRoZSBzYW1lIGZvciBhbGwgb2JqZWN0cy4gIFVubGlrZSB0aGUgYXR0cmlidXRlcywgZWFjaCB1bmlmb3JtIHNldHRlclxuICAgIC8vIGlzIGRpZmZlcmVudCwgZGVwZW5kaW5nIG9uIHRoZSB0eXBlIG9mIHRoZSB1bmlmb3JtIHZhcmlhYmxlLiAgTG9vayBpbiB3ZWJnbC11dGlsLmpzIGZvciB0aGVcbiAgICAvLyBpbXBsZW1lbnRhdGlvbiBvZiAgc2V0VW5pZm9ybXMgdG8gc2VlIHRoZSBkZXRhaWxzIGZvciBzcGVjaWZpYyB0eXBlcyAgICAgICBcbiAgICBzZXRVbmlmb3Jtcyh1bmlmb3JtU2V0dGVycywgdW5pZm9ybXNUaGF0QXJlVGhlU2FtZUZvckFsbE9iamVjdHMpO1xuICAgIC8vIENvbXB1dGUgdGhlIHZpZXcgbWF0cml4IGFuZCBjb3JyZXNwb25kaW5nIG90aGVyIG1hdHJpY2VzIGZvciByZW5kZXJpbmcuXG4gICAgXG4gICAgLy8gZmlyc3QgbWFrZSBhIGNvcHkgb2Ygb3VyIHJvdGF0aW9uTWF0cml4XG4gICAgbWF0NC5jb3B5KG1hdHJpeCwgcm90YXRpb25NYXRyaXgpO1xuICB2YXIgY3VyciA9IHtcbiAgICAgICAgbGV0dGVyOiB1bmRlZmluZWQsXG4gICAgICAgIHJvdGF0ZVogOiBtYXQ0LmNyZWF0ZSgpLFxuICAgICAgICByb3RhdGVYIDogbWF0NC5jcmVhdGUoKSxcbiAgICAgICAgaXNTcGlubmluZzogZmFsc2UsXG4gICAgICAgIHNwaW5uaW5nU3BlZWQ6IDAuMCxcbiAgICAgICAgaGVpZ2h0OiAwLjAsXG4gICAgICAgIHVfY29sb3JNdWx0OiBjaHJvbWEuaHN2KHJhbmQoYmFzZUNvbG9yIC0gMTAwLCBiYXNlQ29sb3IgKyAxMDApLCAwLjUsIDAuNSkuZ2woKSxcbiAgICAgICAgdGV4dHVyZTogdW5kZWZpbmVkLFxuICAgICAgICBhbmdsZTogMC4wLFxuICAgICAgICBwb3NpdGlvblg6IHVuZGVmaW5lZCxcbiAgICAgICAgdGltZTogMC4wLFxuICAgICAgICBzcGlubmluZ0FuZ2xlIDowLjBcbiAgICAgIH1cbiAgdmFyIHRleHR1cmU7XG4gICAgaWYgKHByZXNzRnJvbUtleWJvYXJkICE9IHVuZGVmaW5lZCkge1xuICAgICAgY3Vyci5sZXR0ZXIgPSBwcmVzc0Zyb21LZXlib2FyZDtcbiAgICAgIGN1cnIuaGVpZ2h0ID0gcmFuZCgtODAsIDApO1xuICAgICAgaWYgKHByZXNzRnJvbUtleWJvYXJkID09IDgpIHtcbiAgICAgICAgbGV0dGVycy5wb3AoKTtcbiAgICAgICAgcHJlc3NGcm9tS2V5Ym9hcmQgPSB1bmRlZmluZWQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAocHJlc3NGcm9tS2V5Ym9hcmQgPT0gMTMpIHtcbiAgICAgICAgICBsZXR0ZXJzID0gW107XG4gICAgICAgICAgcHJlc3NGcm9tS2V5Ym9hcmQgPSB1bmRlZmluZWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKHByZXNzRnJvbUtleWJvYXJkID49IDY1ICYmIHByZXNzRnJvbUtleWJvYXJkIDw9IDEyMikge1xuICAgICAgICAgICAgaWYgKHByZXNzRnJvbUtleWJvYXJkID49IDkxICYmIHByZXNzRnJvbUtleWJvYXJkIDw9IDEyMikge1xuICAgICAgICAgICAgICBwcmVzc0Zyb21LZXlib2FyZCA9IHByZXNzRnJvbUtleWJvYXJkIC0gMzI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjdXJyLmFuZ2xlID0gZGVnVG9SYWQocmFuZCgtMjAsIDIwKSk7XG4gICAgICAgICAgICB2YXIgYXhpcyA9IHZlYzMudHJhbnNmb3JtTWF0NChheGlzVmVjdG9yLCB2ZWMzLmZyb21WYWx1ZXMoMCwgMCwgMSksIG1hdDQuY3JlYXRlKCkpO1xuICAgICAgICAgICAgdmFyIGN1cnJIZWlnaHQgPSBjdXJyLmhlaWdodDtcbiAgICAgICAgICAgIG1hdDQucm90YXRlKGN1cnIucm90YXRlWiwgbWF0NC5jcmVhdGUoKSwgY3Vyci5hbmdsZSwgYXhpcyk7XG4gICAgICAgICAgICBjdXJyLnRleHR1cmUgPSB0ZXh0dXJlc1twcmVzc0Zyb21LZXlib2FyZCAtIDY1XTtcbiAgICAgICAgICB9XG4gICAgICBpZiAobGV0dGVycy5sZW5ndGggPiBjYXBhY2l0eSkge1xuICAgICAgICBsZXR0ZXJzLnNoaWZ0KCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGxldHRlcnMucHVzaChjdXJyKTtcbiAgICAgICAgICBwcmVzc0Zyb21LZXlib2FyZCA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICB2YXIgc2NhbGVGb3JMZXR0ZXJzID0gc2NhbGVGYWN0b3IgKiAwLjM7XG4gICAgXG4gICAgc3BhY2luZyA9IDE0MCAvIGNhcGFjaXR5ICogMC4yO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGV0dGVycy5sZW5ndGg7IGkrKykge1xuICAgIGlmIChsZXR0ZXJzW2ldLmxldHRlciAhPSAzMikge1xuICAgICAgbWF0NC5jb3B5KG1hdHJpeCwgcm90YXRpb25NYXRyaXgpO1xuICAgICAgbWF0cml4ID0gbWF0NC5jcmVhdGUoKTtcbiAgICAgIGlmIChsZXR0ZXJzW2ldLmlzU3Bpbm5pbmcpIHtcbiAgICAgICAgaWYgKGxldHRlcnNbaV0udGltZSA+PSAwICYmIGxldHRlcnNbaV0uc3Bpbm5pbmdTcGVlZCA+PSAxLjApIHtcbiAgICAgICAgICBpZiAoTWF0aC5hYnMobGV0dGVyc1tpXS5zcGlubmluZ0FuZ2xlKSA8IDM2MC4wKSB7XG4gICAgICAgICAgICB2YXIgcm90YXRlWSA9IHZlYzMudHJhbnNmb3JtTWF0NChheGlzVmVjdG9yLCB2ZWMzLmZyb21WYWx1ZXMoMCwgMSwgMCksIG1hdDQuY3JlYXRlKCkpO1xuICAgICAgICAgICAgbGV0dGVyc1tpXS5zcGlubmluZ0FuZ2xlID0gbGV0dGVyc1tpXS5zcGlubmluZ1NwZWVkICsgbGV0dGVyc1tpXS5zcGlubmluZ0FuZ2xlO1xuICAgICAgICAgICAgbWF0NC5yb3RhdGUobWF0cml4LCBtYXRyaXgsIGRlZ1RvUmFkKGxldHRlcnNbaV0uc3Bpbm5pbmdBbmdsZSksIHJvdGF0ZVkpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBsZXR0ZXJzW2ldLnNwaW5uaW5nU3BlZWQgPSBsZXR0ZXJzW2ldLnNwaW5uaW5nU3BlZWQgLyAyLjA7XG4gICAgICAgICAgICBsZXR0ZXJzW2ldLnRpbWUtLTtcbiAgICAgICAgICAgIGxldHRlcnNbaV0uc3Bpbm5pbmdBbmdsZSA9IDAuMDtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbGV0dGVyc1tpXS5pc1Nwbm5pbmcgPSBmYWxzZTtcbiAgICAgICAgICBsZXR0ZXJzW2ldLnRpbWUgPSAwLjA7XG4gICAgICAgICAgbGV0dGVyc1tpXS5zcGlubmluZ1NwZWVkID0gMC4wO1xuICAgICAgICAgIG1hdHJpeCA9IG1hdDQuY3JlYXRlKCk7XG4gICAgICAgICAgbGV0dGVyc1tpXS5zcGlubmluZ1NwZWVkID0gMC4wO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBtYXQ0LmNvcHkobGV0dGVyc1tpXS5yb3RhdGVYLCBtYXRyaXgpO1xuICAgICAgbWF0NC5tdWx0aXBseShtYXRyaXgsIGxldHRlcnNbaV0ucm90YXRlWCwgbGV0dGVyc1tpXS5yb3RhdGVaKTtcbiAgICAgIG1hdDQuc2NhbGUobWF0cml4LCBtYXRyaXgsIFtzY2FsZUZvckxldHRlcnMsIHNjYWxlRm9yTGV0dGVycywgc2NhbGVGb3JMZXR0ZXJzXSk7XG4gICAgICBtYXQ0LmNvcHkodW5pZm9ybXNUaGF0QXJlQ29tcHV0ZWRGb3JFYWNoT2JqZWN0LnVfd29ybGQsIG1hdHJpeCk7XG4gICAgICBtYXQ0Lm11bHRpcGx5KG1hdHJpeCwgdmlld01hdHJpeCwgdW5pZm9ybXNUaGF0QXJlQ29tcHV0ZWRGb3JFYWNoT2JqZWN0LnVfd29ybGQpO1xuICAgICAgbWF0NC5tdWx0aXBseSh1bmlmb3Jtc1RoYXRBcmVDb21wdXRlZEZvckVhY2hPYmplY3QudV93b3JsZFZpZXdQcm9qZWN0aW9uLCBwcm9qZWN0aW9uTWF0cml4LCBtYXRyaXgpO1xuICAgICAgbWF0NC50cmFuc3Bvc2UodW5pZm9ybXNUaGF0QXJlQ29tcHV0ZWRGb3JFYWNoT2JqZWN0LnVfd29ybGRJbnZlcnNlVHJhbnNwb3NlLCBtYXQ0LmludmVydChtYXRyaXgsIHVuaWZvcm1zVGhhdEFyZUNvbXB1dGVkRm9yRWFjaE9iamVjdC51X3dvcmxkKSk7XG4gICAgICBzZXRVbmlmb3Jtcyh1bmlmb3JtU2V0dGVycywgdW5pZm9ybXNUaGF0QXJlQ29tcHV0ZWRGb3JFYWNoT2JqZWN0KTtcbiAgICAgIG9iamVjdFN0YXRlLm1hdGVyaWFsVW5pZm9ybXMudV9jb2xvck11bHQgPSBsZXR0ZXJzW2ldLnVfY29sb3JNdWx0O1xub2JqZWN0U3RhdGUubWF0ZXJpYWxVbmlmb3Jtcy51X3ZlcnRpY2FsUG9zID0gdmVjNC5mcm9tVmFsdWVzKDAsIGxldHRlcnNbaV0uaGVpZ2h0LCAwLCAwKTtcbiAgICAgIGxldHRlcnNbaV0ucG9zaXRpb25YID0gc2NhbGVGYWN0b3IgKiAoaSAqIHNwYWNpbmcgLSBzcGFjaW5nICogMC41ICogKGxldHRlcnMubGVuZ3RoIC0gMSkpIC8gMjAwO1xuICAgICAgb2JqZWN0U3RhdGUubWF0ZXJpYWxVbmlmb3Jtcy51X2Rpc1RvQ2VudGVyID0gdmVjNC5mcm9tVmFsdWVzKHNjYWxlRmFjdG9yICogKGkgKiBzcGFjaW5nIC0gc3BhY2luZyAqIDAuNSAqIChsZXR0ZXJzLmxlbmd0aCAtIDEpKSwgMCwgMCwgMCk7XG4gICAgICBzZXRVbmlmb3Jtcyh1bmlmb3JtU2V0dGVycywgb2JqZWN0U3RhdGUubWF0ZXJpYWxVbmlmb3Jtcyk7XG4gICAgICB0ZXh0dXJlID0gZ2wuY3JlYXRlVGV4dHVyZSgpO1xuICAgICAgZ2wuYmluZFRleHR1cmUoZ2wuVEVYVFVSRV8yRCwgdGV4dHVyZSk7XG4gICAgICBnbC50ZXhQYXJhbWV0ZXJpKGdsLlRFWFRVUkVfMkQsIGdsLlRFWFRVUkVfV1JBUF9TLCBnbC5DTEFNUF9UT19FREdFKTtcbiAgICAgIGdsLnRleFBhcmFtZXRlcmkoZ2wuVEVYVFVSRV8yRCwgZ2wuVEVYVFVSRV9XUkFQX1QsIGdsLkNMQU1QX1RPX0VER0UpO1xuICAgICAgZ2wudGV4UGFyYW1ldGVyaShnbC5URVhUVVJFXzJELCBnbC5URVhUVVJFX01JTl9GSUxURVIsIGdsLk5FQVJFU1QpO1xuICAgICAgZ2wudGV4UGFyYW1ldGVyaShnbC5URVhUVVJFXzJELCBnbC5URVhUVVJFX01BR19GSUxURVIsIGdsLk5FQVJFU1QpO1xuICAgICAgZ2wudGV4SW1hZ2UyRChnbC5URVhUVVJFXzJELCAwLCBnbC5SR0JBLCBnbC5SR0JBLCBnbC5VTlNJR05FRF9CWVRFLCBsZXR0ZXJzW2ldLnRleHR1cmUpO1xuICAgICAgZ2wuZHJhd0VsZW1lbnRzKGdsLlRSSUFOR0xFUywgYnVmZmVySW5mby5udW1FbGVtZW50cywgZ2wuVU5TSUdORURfU0hPUlQsIDApO1xuICAgIH1cbiAgICB9XG4gICAgaWYgKG1vdXNlRG93biAhPSB1bmRlZmluZWQpIHtcbiAgICAgIGlmIChjYW52YXMgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmIChnbCAhPSB1bmRlZmluZWQpIHtcbiAgICAgIHZhciBtb3VzZVBvc2l0aW9uID0gMC4wO1xuICAgICAgICAgIHZhciBjdXJyRGlzdCA9IEluZmluaXR5O1xuICAgICAgICAgIHZhciBjdXJySUQgPSB1bmRlZmluZWQ7XG5cbiAgICAgICAgICBtb3VzZVBvc2l0aW9uID0gbW91c2VEb3duWzBdIC0gNzE3O1xuICAgICAgICAgIG1vdXNlUG9zaXRpb24gPSBtb3VzZVBvc2l0aW9uLzcxNztcbiAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxldHRlcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChNYXRoLmFicyhtb3VzZVBvc2l0aW9uIC0gbGV0dGVyc1tpXS5wb3NpdGlvblgpIDwgY3VyckRpc3Qpe1xuICAgICAgICAgICAgICBjdXJySUQgPSBpO1xuICAgICAgICAgICAgICBjdXJyRGlzdCA9IE1hdGguYWJzKG1vdXNlUG9zaXRpb24gLSBsZXR0ZXJzW2ldLnBvc2l0aW9uWCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChsZXR0ZXJzW2N1cnJJRF0uaXNTcGlubmluZyA9PSBmYWxzZSkge1xuICAgICAgICBsZXR0ZXJzW2N1cnJJRF0uaXNTcGlubmluZyA9IHRydWU7XG4gICAgICAgIGxldHRlcnNbY3VycklEXS50aW1lID0gY3VyckRpc3QgKiAzNjA7XG4gICAgICAgIGxldHRlcnNbY3VycklEXS5zcGlubmluZ1NwZWVkID0gbGV0dGVyc1tjdXJySURdLnRpbWUgKiAxMC4wO1xuICAgICAgICB2YXIgc291bmRFZmZlY3QgPSBuZXcgSG93bCh7XG4gICAgICAgICAgdXJsczogWydzb3VuZHMvc3Bpbi5tcDMnXVxuICAgICAgICB9KS5wbGF5KCk7XG4gICAgICAgICAgfSBcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgbW91c2VEb3duID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBnbC51c2VQcm9ncmFtKGxpbmVQcm9ncmFtKTtcbiAgICB1bmlmb3JtU2V0dGVycyA9IGNyZWF0ZVVuaWZvcm1TZXR0ZXJzKGdsLCBsaW5lUHJvZ3JhbSk7XG4gICAgYXR0cmliU2V0dGVycyA9IGNyZWF0ZUF0dHJpYnV0ZVNldHRlcnMoZ2wsIGxpbmVQcm9ncmFtKTtcbiAgICB2YXIgdW5pZm9ybXNPZkxpbmVzID0ge1xuICAgICAgdV93b3JsZFZpZXdQcm9qZWN0aW9uOiAgbWF0NC5jcmVhdGUoKSxcbiAgICAgIHVfY29sb3JNdWx0OiBbMCwgMCwgMCwgMV0sXG4gICAgICB1X2hvcml6b250YWxQb3M6IHZlYzQuY3JlYXRlKCksXG4gICAgICB1X2hlaWdodDogMC4wXG4gICAgfVxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGV0dGVycy5sZW5ndGg7IGkrKykge1xuICAgIGlmIChsZXR0ZXJzW2ldLmxldHRlciAhPSAzMikge1xuICAgICAgdmFyIGhvcml6b250YWxQb3MgPSBzY2FsZUZhY3RvciAqIChpICogc3BhY2luZyAtIHNwYWNpbmcgKiAwLjUgKiAobGV0dGVycy5sZW5ndGggLSAxKSkgLyAyMDA7XG4gICAgICB1bmlmb3Jtc09mTGluZXMudV9jb2xvck11bHQgPSBsZXR0ZXJzW2ldLnVfY29sb3JNdWx0O1xuICAgICAgdW5pZm9ybXNPZkxpbmVzLnVfaG9yaXpvbnRhbFBvcyA9IHZlYzQuZnJvbVZhbHVlcyhob3Jpem9udGFsUG9zLCAwLCAwLCAwKTtcbiAgICAgIHVuaWZvcm1zT2ZMaW5lcy51X2hlaWdodCA9IGxldHRlcnNbaV0uaGVpZ2h0IC8gMjAwO1xuICAgICAgc2V0QnVmZmVyc0FuZEF0dHJpYnV0ZXMoZ2wsIGF0dHJpYlNldHRlcnMsIGJ1ZmZlckluZm8wKTtcbiAgICAgIHNldFVuaWZvcm1zKHVuaWZvcm1TZXR0ZXJzLCB1bmlmb3Jtc09mTGluZXMpO1xuICAgICAgZ2wubGluZVdpZHRoKDIuMCk7XG4gICAgICBnbC5kcmF3RWxlbWVudHMoZ2wuTElORVMsIDIsIGdsLlVOU0lHTkVEX1NIT1JULCAwKTtcbiAgICB9XG4gICAgfVxuXG4gICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGRyYXdTY2VuZSk7XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiL3NvdXJjZS8ifQ==
