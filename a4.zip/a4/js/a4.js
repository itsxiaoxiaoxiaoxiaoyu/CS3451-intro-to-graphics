///<reference path='./typings/tsd.d.ts'/>
///<reference path="./localTypings/webglutils.d.ts"/>
//get start by stuff not in shaders
//
/*
 * Portions of this code are
 * Copyright 2015, Blair MacIntyre.
 *
 * Portions of this code taken from http://webglfundamentals.org, at https://github.com/greggman/webgl-fundamentals
 * and are subject to the following license.  In particular, from
 *    http://webglfundamentals.org/webgl/webgl-less-code-more-fun.html
 *    http://webglfundamentals.org/webgl/resources/primitives.js
 *
 * Those portions Copyright 2014, Gregg Tavares.
 * All rights reserved.
 */
define(["require", "exports", './loader'], function (require, exports, loader) {
    ////////////////////////////////////////////////////////////////////////////////////////////
    // stats module by mrdoob (https://github.com/mrdoob/stats.js) to show the performance 
    // of your graphics
    var stats = new Stats();
    stats.setMode(1); // 0: fps, 1: ms, 2: mb
    stats.domElement.style.position = 'absolute';
    stats.domElement.style.right = '0px';
    stats.domElement.style.top = '0px';
    document.body.appendChild(stats.domElement);
    ////////////////////////////////////////////////////////////////////////////////////////////
    // utilities
    var rand = function (min, max) {
        if (max === undefined) {
            max = min;
            min = 0;
        }
        return min + Math.random() * (max - min);
    };
    var randInt = function (range) {
        return Math.floor(Math.random() * range);
    };
    ////////////////////////////////////////////////////////////////////////////////////////////
    // get some of our canvas elements that we need
    var canvas = document.getElementById("webgl");
    var effectI;
    window["onEffect1"] = function () {
        console.log("install effect1!");
        effectI = 2;
        //////////////
        ///////// YOUR CODE HERE TO cause the program to use your first shader effect
        ///////// (you can probably just use some sort of global variable to indicate which effect)
        //////////////
    };
    window["onEffect2"] = function () {
        console.log("install effect2!");
        effectI = 4;
        //////////////
        ///////// YOUR CODE HERE TO cause the program to use your second shader effect
        ///////// (you can probably just use some sort of global variable to indicate which effect)
        //////////////
    };
    window["onEffect3"] = function () {
        console.log("install effect3!");
        effectI = 6;
        //////////////
        ///////// YOUR CODE HERE TO cause the program to use your third shader effect
        ///////// (you can probably just use some sort of global variable to indicate which effect)
        //////////////
    };
    window["onEffect4"] = function () {
        console.log("install effect4!");
        effectI = 8;
        //////////////
        ///////// YOUR CODE HERE TO cause the program to use your fourth shader effect
        ///////// (you can probably just use some sort of global variable to indicate which effect)
        //////////////
    };
    ////////////////////////////////////////////////////////////////////////////////////////////
    // some simple interaction using the mouse.
    // we are going to get small motion offsets of the mouse, and use these to rotate the object
    //
    // our offset() function from assignment 0, to give us a good mouse position in the canvas 
    function offset(e) {
        e = e || window.event;
        var target = e.target || e.srcElement, rect = target.getBoundingClientRect(), offsetX = e.clientX - rect.left, offsetY = e.clientY - rect.top;
        return vec2.fromValues(offsetX, offsetY);
    }
    var mouseStart = undefined; // previous mouse position
    var mouseDelta = undefined; // the amount the mouse has moved
    var mouseAngles = vec2.create(); // angle offset corresponding to mouse movement
    // start things off with a down press
    canvas.onmousedown = function (ev) {
        mouseStart = offset(ev);
        mouseDelta = vec2.create(); // initialize to 0,0
        vec2.set(mouseAngles, 0, 0);
    };
    // stop things with a mouse release
    canvas.onmouseup = function (ev) {
        if (mouseStart != undefined) {
            var clickEnd = offset(ev);
            vec2.sub(mouseDelta, clickEnd, mouseStart); // delta = end - start
            vec2.scale(mouseAngles, mouseDelta, 10 / canvas.height);
            // now toss the two values since the mouse is up
            mouseDelta = undefined;
            mouseStart = undefined;
        }
    };
    // if we're moving and the mouse is down        
    canvas.onmousemove = function (ev) {
        if (mouseStart != undefined) {
            var m = offset(ev);
            vec2.sub(mouseDelta, m, mouseStart); // delta = mouse - start 
            vec2.copy(mouseStart, m); // start becomes current position
            vec2.scale(mouseAngles, mouseDelta, 10 / canvas.height);
        }
    };
    // stop things if you move out of the window
    canvas.onmouseout = function (ev) {
        if (mouseStart != undefined) {
            vec2.set(mouseAngles, 0, 0);
            mouseDelta = undefined;
            mouseStart = undefined;
        }
    };
    ////////////////////////////////////////////////////////////////////////////////////////////
    // start things off by calling initWebGL
    initWebGL();
    function initWebGL() {
        // get the rendering context for webGL
        var gl = getWebGLContext(canvas);
        if (!gl) {
            return; // no webgl!  Bye bye
        }
        // turn on backface culling and zbuffering
        //gl.enable(gl.CULL_FACE);
        gl.enable(gl.DEPTH_TEST);
        // attempt to download and set up our GLSL shaders.  When they download, processed to the next step
        // of our program, the "main" routing
        // 
        // YOU SHOULD MODIFY THIS TO DOWNLOAD ALL YOUR SHADERS and set up all four SHADER PROGRAMS,
        // THEN PASS AN ARRAY OF PROGRAMS TO main().  You'll have to do other things in main to deal
        // with multiple shaders and switch between them
        loader.loadFiles(['shaders/a3-shader.vert', 'shaders/a3-shader.frag',
            'shaders/transparency.vert', 'shaders/transparency.frag',
            'shaders/Julia.vet', 'shaders/Julia.frag', 'shaders/image.vert', 'shaders/image.frag',
            'shaders/vertexshader.vert', 'shaders/vertexshader.frat'], function (shaderText) {
            // var program = createProgramFromSources(gl, [shaderText[0], shaderText[1]]);
            main(gl, shaderText);
        }, function (url) {
            alert('Shader failed to download "' + url + '"');
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////
    // webGL is set up, and our Shader program has been created.  Finish setting up our webGL application       
    function main(gl, shaderText) {
        var textures = [];
        function loadingimage(image) {
            var texture = gl.createTexture();
            gl.bindTexture(gl.TEXTURE_2D, texture);
            // Set the parameters so we can render any size image.
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
            // Upload the image into the texture.
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
            // add the texture to the array of textures.
            textures.push(texture);
        }
        // var images = [];
        var image1 = new Image();
        image1.src = "shaders/titan.jpg";
        image1.onload = function () { loadingimage(image1); };
        // images.push(image1);
        var image2 = new Image();
        image2.src = "shaders/levi.jpg";
        image2.onload = function () { loadingimage(image2); };
        // images.push(image2);
        // use the webgl-utils library to create setters for all the uniforms and attributes in our shaders.
        // It enumerates all of the uniforms and attributes in the program, and creates utility functions to 
        // allow "setUniforms" and "setAttributes" (below) to set the shader variables from a javascript object. 
        // The objects have a key for each uniform or attribute, and a value containing the parameters for the
        // setter function
        if (effectI == undefined) {
            effectI = 0;
        }
        // var program = createProgramFromSources(gl, [shaderText[effectI], shaderText[effectI + 1]]);
        // var uniformSetters = createUniformSetters(gl, program);
        // var attribSetters  = createAttributeSetters(gl, program);
        // an indexed quad
        var arrays = {
            position: { numComponents: 3, data: [0, 0, 0, 10, 0, 0, 0, 10, 0, 10, 10, 0], },
            texcoord: { numComponents: 2, data: [0, 1, 1, 1, 0, 0, 1, 0], },
            normal: { numComponents: 3, data: [0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1], },
            indices: { numComponents: 3, data: [0, 1, 2, 1, 3, 2], },
        };
        var center = [5, 5, 0];
        var scaleFactor = 20;
        var subArrays = {
            position: { numComponents: 3, data: [], },
            texcoord: { numComponents: 2, data: [], },
            normal: { numComponents: 3, data: [], },
            indices: { numComponents: 3, data: [], },
        };
        var newPosition = [];
        var normal = [];
        var indices = [];
        var textCoord = [];
        // console.log(newPosition);
        var n = 100;
        for (var ii = 0; ii < n; ii++) {
            for (var jj = 0; jj < n; jj++) {
                newPosition.push.apply(newPosition, [jj * (10 / (n - 1)), ii * (10 / (n - 1)), 0]);
                normal.push.apply(normal, [0, 0, -1]);
                textCoord.push(jj * 1 / (n - 1), ii * (1 / (n - 1)));
                if (ii != n - 1 && jj != n - 1) {
                    indices.push(jj + ii * n, jj + ii * n + 1, jj + (ii + 1) * n);
                    indices.push(jj + ii * n + 1, jj + (ii + 1) * n, jj + (ii + 1) * n + 1);
                }
            }
        }
        // for (var ii = 0; ii < 200; ii++) { // row
        //     for (var jj = 0; jj < 200; jj++){ // col
        //       if (ii != 199 && jj != 199) {
        //     var tri1 = [jj + ii * 200, jj + ii * 200 + 1, jj + (ii + 1) * 200];
        //     var tri2 = [jj + ii * 200 + 1, jj + (ii + 1) * 200, jj + (ii + 1) * 200 + 1];
        //       indices.push.apply(indices, tri1);
        //       indices.push.apply(indices, tri2);
        //     }
        //     }
        //   }
        for (var ii = 0; ii < textCoord.length / 2; ii++) {
            var tempt = textCoord[ii];
            textCoord[ii] = textCoord[textCoord.length - ii - 1];
            textCoord[textCoord.length - ii - 1] = tempt;
        }
        for (var ii = 0; ii < textCoord.length; ii += 2) {
            var tempt = textCoord[ii];
            textCoord[ii] = textCoord[ii + 1];
            textCoord[ii + 1] = tempt;
        }
        subArrays.position.data = newPosition;
        subArrays.indices.data = indices;
        subArrays.texcoord.data = textCoord;
        subArrays.normal.data = normal;
        var bufferInfo = createBufferInfoFromArrays(gl, arrays);
        function degToRad(d) {
            return d * Math.PI / 180;
        }
        var cameraAngleRadians = degToRad(0);
        var fieldOfViewRadians = degToRad(60);
        var cameraHeight = 50;
        var uniformsThatAreTheSameForAllObjects = {
            u_lightWorldPos: [50, 30, -100],
            u_viewInverse: mat4.create(),
            u_lightColor: [1, 1, 1, 1],
            u_ambient: [0.1, 0.1, 0.1, 0.1],
            u_time: 0
        };
        var uniformsThatAreComputedForEachObject = {
            u_worldViewProjection: mat4.create(),
            u_world: mat4.create(),
            u_worldInverseTranspose: mat4.create(),
            u_scale: scaleFactor,
            u_holes_x: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            u_holes_y: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        };
        // var texture = .... create a texture of some form
        var baseColor = rand(240);
        var objectState = {
            materialUniforms: {
                u_colorMult: chroma.hsv(rand(baseColor, baseColor + 120), 0.5, 1).gl(),
                //u_diffuse:               texture,
                u_specular: [1, 1, 1, 1],
                u_shininess: 450,
                u_specularFactor: 0.75,
            }
        };
        // some variables we'll reuse below
        var projectionMatrix = mat4.create();
        var viewMatrix = mat4.create();
        var rotationMatrix = mat4.create();
        var matrix = mat4.create(); // a scratch matrix
        var invMatrix = mat4.create();
        var axisVector = vec3.create();
        for (var i = 0; i < 24; i++) {
            uniformsThatAreComputedForEachObject.u_holes_x[i] = rand(-1, 1);
            uniformsThatAreComputedForEachObject.u_holes_y[i] = rand(-1, 1);
        }
        requestAnimationFrame(drawScene);
        // Draw the scene.
        function drawScene(time) {
            time *= 0.001;
            if (effectI == 8) {
                var bufferInfo2 = createBufferInfoFromArrays(gl, subArrays);
            }
            uniformsThatAreTheSameForAllObjects.u_time = uniformsThatAreTheSameForAllObjects.u_time + 0.01;
            var program = createProgramFromSources(gl, [shaderText[effectI], shaderText[effectI + 1]]);
            var uniformSetters = createUniformSetters(gl, program);
            var attribSetters = createAttributeSetters(gl, program);
            // measure time taken for the little stats meter
            stats.begin();
            // if the window changed size, reset the WebGL canvas size to match.  The displayed size of the canvas
            // (determined by window size, layout, and your CSS) is separate from the size of the WebGL render buffers, 
            // which you can control by setting canvas.width and canvas.height
            resizeCanvasToDisplaySize(canvas);
            // Set the viewport to match the canvas
            gl.viewport(0, 0, canvas.width, canvas.height);
            // Clear the canvas AND the depth buffer.
            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            // Compute the projection matrix
            var aspect = canvas.clientWidth / canvas.clientHeight;
            mat4.perspective(projectionMatrix, fieldOfViewRadians, aspect, 1, 2000);
            // Compute the camera's matrix using look at.
            var cameraPosition = [0, 0, -200];
            var target = [0, 0, 0];
            var up = [0, 1, 0];
            var cameraMatrix = mat4.lookAt(uniformsThatAreTheSameForAllObjects.u_viewInverse, cameraPosition, target, up);
            // Make a view matrix from the camera matrix.
            mat4.invert(viewMatrix, cameraMatrix);
            // tell WebGL to use our shader program (will need to change this)
            gl.useProgram(program);
            var u_image0Location = gl.getUniformLocation(program, "u_image0");
            var u_image1Location = gl.getUniformLocation(program, "u_image1");
            // Setup all the needed attributes and buffers.  
            if (effectI == 8) {
                setBuffersAndAttributes(gl, attribSetters, bufferInfo2);
            }
            else {
                setBuffersAndAttributes(gl, attribSetters, bufferInfo);
            }
            // Set the uniforms that are the same for all objects.  Unlike the attributes, each uniform setter
            // is different, depending on the type of the uniform variable.  Look in webgl-util.js for the
            // implementation of  setUniforms to see the details for specific types       
            setUniforms(uniformSetters, uniformsThatAreTheSameForAllObjects);
            gl.uniform1i(u_image0Location, 0);
            gl.uniform1i(u_image1Location, 1);
            gl.activeTexture(gl.TEXTURE0);
            gl.bindTexture(gl.TEXTURE_2D, textures[0]);
            gl.activeTexture(gl.TEXTURE1);
            gl.bindTexture(gl.TEXTURE_2D, textures[1]);
            ///////////////////////////////////////////////////////
            // Compute the view matrix and corresponding other matrices for rendering.
            // first make a copy of our rotationMatrix
            mat4.copy(matrix, rotationMatrix);
            // adjust the rotation based on mouse activity.  mouseAngles is set if user is dragging 
            if (mouseAngles[0] !== 0 || mouseAngles[1] !== 0) {
                /*
                 * only rotate around Y, use the second mouse value for scale.  Leaving the old code from A3
                 * here, commented out
                 *
                // need an inverse world transform so we can find out what the world X axis for our first rotation is
                mat4.invert(invMatrix, matrix);
                // get the world X axis
                var xAxis = vec3.transformMat4(axisVector, vec3.fromValues(1,0,0), invMatrix);
          
                // rotate about the world X axis (the X parallel to the screen!)
                mat4.rotate(matrix, matrix, -mouseAngles[1], xAxis);
                */
                // now get the inverse world transform so we can find the world Y axis
                mat4.invert(invMatrix, matrix);
                // get the world Y axis
                var yAxis = vec3.transformMat4(axisVector, vec3.fromValues(0, 1, 0), invMatrix);
                // rotate about teh world Y axis
                mat4.rotate(matrix, matrix, mouseAngles[0], yAxis);
                // save the resulting matrix back to the cumulative rotation matrix 
                mat4.copy(rotationMatrix, matrix);
                // use mouseAngles[1] to scale
                scaleFactor += mouseAngles[1];
                vec2.set(mouseAngles, 0, 0);
            }
            uniformsThatAreComputedForEachObject.u_scale = scaleFactor;
            // add a translate and scale to the object World xform, so we have:  R * T * S
            mat4.translate(matrix, rotationMatrix, [-center[0] * scaleFactor, -center[1] * scaleFactor,
                -center[2] * scaleFactor]);
            mat4.scale(matrix, matrix, [scaleFactor, scaleFactor, scaleFactor]);
            mat4.copy(uniformsThatAreComputedForEachObject.u_world, matrix);
            // get proj * view * world
            mat4.multiply(matrix, viewMatrix, uniformsThatAreComputedForEachObject.u_world);
            mat4.multiply(uniformsThatAreComputedForEachObject.u_worldViewProjection, projectionMatrix, matrix);
            // get worldInvTranspose.  For an explaination of why we need this, for fixing the normals, see
            // http://www.unknownroad.com/rtfm/graphics/rt_normals.html
            mat4.transpose(uniformsThatAreComputedForEachObject.u_worldInverseTranspose, mat4.invert(matrix, uniformsThatAreComputedForEachObject.u_world));
            // Set the uniforms we just computed
            setUniforms(uniformSetters, uniformsThatAreComputedForEachObject);
            // Set the uniforms that are specific to the this object.
            setUniforms(uniformSetters, objectState.materialUniforms);
            // Draw the geometry.   Everything is keyed to the ""
            if (effectI == 8) {
                gl.drawElements(gl.TRIANGLES, bufferInfo2.numElements, gl.UNSIGNED_SHORT, 0);
            }
            else {
                gl.drawElements(gl.TRIANGLES, bufferInfo.numElements, gl.UNSIGNED_SHORT, 0);
            }
            // stats meter
            stats.end();
            requestAnimationFrame(drawScene);
        }
    }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImE0LnRzIl0sIm5hbWVzIjpbIm9mZnNldCIsImluaXRXZWJHTCIsIm1haW4iLCJtYWluLmxvYWRpbmdpbWFnZSIsIm1haW4uZGVnVG9SYWQiLCJtYWluLmRyYXdTY2VuZSJdLCJtYXBwaW5ncyI6IkFBQUEseUNBQXlDO0FBQ3pDLHFEQUFxRDtBQUNyRCxtQ0FBbUM7QUFDbkMsRUFBRTtBQUNGOzs7Ozs7Ozs7OztHQVdHOztJQUlILDRGQUE0RjtJQUM1Rix1RkFBdUY7SUFDdkYsbUJBQW1CO0lBQ25CLElBQUksS0FBSyxHQUFHLElBQUksS0FBSyxFQUFFLENBQUM7SUFDeEIsS0FBSyxDQUFDLE9BQU8sQ0FBRSxDQUFDLENBQUUsQ0FBQyxDQUFDLHVCQUF1QjtJQUUzQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDO0lBQzdDLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7SUFDckMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQztJQUVuQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBRSxLQUFLLENBQUMsVUFBVSxDQUFFLENBQUM7SUFFOUMsNEZBQTRGO0lBQzVGLFlBQVk7SUFDWixJQUFJLElBQUksR0FBRyxVQUFTLEdBQVcsRUFBRSxHQUFZO1FBQzNDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO1lBQ3RCLEdBQUcsR0FBRyxHQUFHLENBQUM7WUFDVixHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ1YsQ0FBQztRQUNELE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQzNDLENBQUMsQ0FBQztJQUVGLElBQUksT0FBTyxHQUFHLFVBQVMsS0FBSztRQUMxQixNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQyxDQUFDO0lBRUYsNEZBQTRGO0lBQzVGLCtDQUErQztJQUMvQyxJQUFJLE1BQU0sR0FBc0IsUUFBUSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUVqRSxJQUFJLE9BQU8sQ0FBQztJQUNaLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRztRQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDaEMsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUNkLGNBQWM7UUFDZCw2RUFBNkU7UUFDN0UsMkZBQTJGO1FBQzNGLGNBQWM7SUFDaEIsQ0FBQyxDQUFBO0lBRUQsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHO1FBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUNoQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsY0FBYztRQUNkLDhFQUE4RTtRQUM5RSwyRkFBMkY7UUFDM0YsY0FBYztJQUNoQixDQUFDLENBQUE7SUFFRCxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUc7UUFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1FBQ2hDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDZCxjQUFjO1FBQ2QsNkVBQTZFO1FBQzdFLDJGQUEyRjtRQUMzRixjQUFjO0lBQ2hCLENBQUMsQ0FBQTtJQUVELE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRztRQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDaEMsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUNkLGNBQWM7UUFDZCw4RUFBOEU7UUFDOUUsMkZBQTJGO1FBQzNGLGNBQWM7SUFDaEIsQ0FBQyxDQUFBO0lBRUQsNEZBQTRGO0lBQzVGLDJDQUEyQztJQUMzQyw0RkFBNEY7SUFDNUYsRUFBRTtJQUNGLDJGQUEyRjtJQUMzRixnQkFBZ0IsQ0FBYTtRQUN6QkEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsSUFBaUJBLE1BQU1BLENBQUNBLEtBQUtBLENBQUNBO1FBRW5DQSxJQUFJQSxNQUFNQSxHQUFhQSxDQUFDQSxDQUFDQSxNQUFNQSxJQUFJQSxDQUFDQSxDQUFDQSxVQUFVQSxFQUMzQ0EsSUFBSUEsR0FBR0EsTUFBTUEsQ0FBQ0EscUJBQXFCQSxFQUFFQSxFQUNyQ0EsT0FBT0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsT0FBT0EsR0FBR0EsSUFBSUEsQ0FBQ0EsSUFBSUEsRUFDL0JBLE9BQU9BLEdBQUdBLENBQUNBLENBQUNBLE9BQU9BLEdBQUdBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBO1FBRW5DQSxNQUFNQSxDQUFDQSxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxFQUFFQSxPQUFPQSxDQUFDQSxDQUFDQTtJQUM3Q0EsQ0FBQ0E7SUFFRCxJQUFJLFVBQVUsR0FBRyxTQUFTLENBQUMsQ0FBRSwwQkFBMEI7SUFDdkQsSUFBSSxVQUFVLEdBQUcsU0FBUyxDQUFDLENBQUUsaUNBQWlDO0lBQzlELElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFFLCtDQUErQztJQUVqRixxQ0FBcUM7SUFDckMsTUFBTSxDQUFDLFdBQVcsR0FBRyxVQUFDLEVBQWM7UUFDaEMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN4QixVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUUsb0JBQW9CO1FBQ2pELElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNoQyxDQUFDLENBQUE7SUFFRCxtQ0FBbUM7SUFDbkMsTUFBTSxDQUFDLFNBQVMsR0FBRyxVQUFDLEVBQWM7UUFDOUIsRUFBRSxDQUFDLENBQUMsVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDMUIsSUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQzVCLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFRLHNCQUFzQjtZQUN6RSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxVQUFVLEVBQUUsRUFBRSxHQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV0RCxnREFBZ0Q7WUFDaEQsVUFBVSxHQUFHLFNBQVMsQ0FBQztZQUN2QixVQUFVLEdBQUcsU0FBUyxDQUFDO1FBQzNCLENBQUM7SUFDTCxDQUFDLENBQUE7SUFFRCxnREFBZ0Q7SUFDaEQsTUFBTSxDQUFDLFdBQVcsR0FBRyxVQUFDLEVBQWM7UUFDaEMsRUFBRSxDQUFDLENBQUMsVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDNUIsSUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFJLHlCQUF5QjtZQUNqRSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFlLGlDQUFpQztZQUN6RSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxVQUFVLEVBQUUsRUFBRSxHQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUt6RCxDQUFDO0lBQ0osQ0FBQyxDQUFBO0lBRUQsNENBQTRDO0lBQzVDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsVUFBQyxFQUFjO1FBQy9CLEVBQUUsQ0FBQyxDQUFDLFVBQVUsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO1lBQzVCLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM1QixVQUFVLEdBQUcsU0FBUyxDQUFDO1lBQ3ZCLFVBQVUsR0FBRyxTQUFTLENBQUM7UUFDekIsQ0FBQztJQUNMLENBQUMsQ0FBQTtJQUVELDRGQUE0RjtJQUM1Rix3Q0FBd0M7SUFDeEMsU0FBUyxFQUFFLENBQUM7SUFFWjtRQUNFQyxzQ0FBc0NBO1FBQ3RDQSxJQUFJQSxFQUFFQSxHQUEwQkEsZUFBZUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7UUFDeERBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQ1JBLE1BQU1BLENBQUNBLENBQUVBLHFCQUFxQkE7UUFDaENBLENBQUNBO1FBRURBLDBDQUEwQ0E7UUFDMUNBLDBCQUEwQkE7UUFDMUJBLEVBQUVBLENBQUNBLE1BQU1BLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBLENBQUNBO1FBRXpCQSxtR0FBbUdBO1FBQ25HQSxxQ0FBcUNBO1FBQ3JDQSxHQUFHQTtRQUNIQSwyRkFBMkZBO1FBQzNGQSw0RkFBNEZBO1FBQzVGQSxnREFBZ0RBO1FBQ2hEQSxNQUFNQSxDQUFDQSxTQUFTQSxDQUFDQSxDQUFDQSx3QkFBd0JBLEVBQUVBLHdCQUF3QkE7WUFDbEVBLDJCQUEyQkEsRUFBRUEsMkJBQTJCQTtZQUN4REEsbUJBQW1CQSxFQUFFQSxvQkFBb0JBLEVBQUNBLG9CQUFvQkEsRUFBRUEsb0JBQW9CQTtZQUNwRkEsMkJBQTJCQSxFQUFDQSwyQkFBMkJBLENBQUNBLEVBQUVBLFVBQVVBLFVBQVVBO1lBQzlFLDhFQUE4RTtZQUM5RSxJQUFJLENBQUMsRUFBRSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ3ZCLENBQUMsRUFBRUEsVUFBVUEsR0FBR0E7WUFDWixLQUFLLENBQUMsNkJBQTZCLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ3JELENBQUMsQ0FBQ0EsQ0FBQ0E7SUFDTEEsQ0FBQ0E7SUFFRCw0RkFBNEY7SUFDNUYsNEdBQTRHO0lBQzVHLGNBQWMsRUFBeUIsRUFBRSxVQUFVO1FBQ2pEQyxJQUFJQSxRQUFRQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUNsQkEsc0JBQXNCQSxLQUFLQTtZQUN6QkMsSUFBSUEsT0FBT0EsR0FBR0EsRUFBRUEsQ0FBQ0EsYUFBYUEsRUFBRUEsQ0FBQ0E7WUFDakNBLEVBQUVBLENBQUNBLFdBQVdBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLEVBQUVBLE9BQU9BLENBQUNBLENBQUNBO1lBQ3JDQSxzREFBc0RBO1lBQ3hEQSxFQUFFQSxDQUFDQSxhQUFhQSxDQUFDQSxFQUFFQSxDQUFDQSxVQUFVQSxFQUFFQSxFQUFFQSxDQUFDQSxjQUFjQSxFQUFFQSxFQUFFQSxDQUFDQSxhQUFhQSxDQUFDQSxDQUFDQTtZQUNyRUEsRUFBRUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsVUFBVUEsRUFBRUEsRUFBRUEsQ0FBQ0EsY0FBY0EsRUFBRUEsRUFBRUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsQ0FBQ0E7WUFDckVBLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLEVBQUVBLEVBQUVBLENBQUNBLGtCQUFrQkEsRUFBRUEsRUFBRUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7WUFDbkVBLEVBQUVBLENBQUNBLGFBQWFBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLEVBQUVBLEVBQUVBLENBQUNBLGtCQUFrQkEsRUFBRUEsRUFBRUEsQ0FBQ0EsT0FBT0EsQ0FBQ0EsQ0FBQ0E7WUFDakVBLHFDQUFxQ0E7WUFDdkNBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLENBQUNBLElBQUlBLEVBQUVBLEVBQUVBLENBQUNBLElBQUlBLEVBQUVBLEVBQUVBLENBQUNBLGFBQWFBLEVBQUVBLEtBQUtBLENBQUNBLENBQUNBO1lBRTNFQSw0Q0FBNENBO1lBQzVDQSxRQUFRQSxDQUFDQSxJQUFJQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtRQUN6QkEsQ0FBQ0E7UUFDREQsbUJBQW1CQTtRQUNuQkEsSUFBSUEsTUFBTUEsR0FBR0EsSUFBSUEsS0FBS0EsRUFBRUEsQ0FBQ0E7UUFDekJBLE1BQU1BLENBQUNBLEdBQUdBLEdBQUdBLG1CQUFtQkEsQ0FBQ0E7UUFDakNBLE1BQU1BLENBQUNBLE1BQU1BLEdBQUdBLGNBQVksWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUEsQ0FBQyxDQUFDQTtRQUNsREEsdUJBQXVCQTtRQUN2QkEsSUFBSUEsTUFBTUEsR0FBR0EsSUFBSUEsS0FBS0EsRUFBRUEsQ0FBQ0E7UUFDekJBLE1BQU1BLENBQUNBLEdBQUdBLEdBQUdBLGtCQUFrQkEsQ0FBQ0E7UUFDaENBLE1BQU1BLENBQUNBLE1BQU1BLEdBQUdBLGNBQWEsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUMsQ0FBQyxDQUFDQTtRQUVwREEsdUJBQXVCQTtRQUN2QkEsb0dBQW9HQTtRQUNwR0EscUdBQXFHQTtRQUNyR0EseUdBQXlHQTtRQUN6R0Esc0dBQXNHQTtRQUN0R0Esa0JBQWtCQTtRQUNsQkEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsSUFBSUEsU0FBU0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDekJBLE9BQU9BLEdBQUdBLENBQUNBLENBQUNBO1FBQ2RBLENBQUNBO1FBQ0RBLDhGQUE4RkE7UUFDOUZBLDBEQUEwREE7UUFDMURBLDREQUE0REE7UUFFNURBLGtCQUFrQkE7UUFDbEJBLElBQUlBLE1BQU1BLEdBQUdBO1lBQ1ZBLFFBQVFBLEVBQUVBLEVBQUVBLGFBQWFBLEVBQUVBLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBLENBQUNBLEdBQUdBO1lBQy9FQSxRQUFRQSxFQUFFQSxFQUFFQSxhQUFhQSxFQUFFQSxDQUFDQSxFQUFFQSxJQUFJQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxHQUFtQkE7WUFDL0VBLE1BQU1BLEVBQUlBLEVBQUVBLGFBQWFBLEVBQUVBLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBO1lBQy9FQSxPQUFPQSxFQUFHQSxFQUFFQSxhQUFhQSxFQUFFQSxDQUFDQSxFQUFFQSxJQUFJQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxHQUF5QkE7U0FDakZBLENBQUNBO1FBQ0ZBLElBQUlBLE1BQU1BLEdBQUdBLENBQUNBLENBQUNBLEVBQUNBLENBQUNBLEVBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ3JCQSxJQUFJQSxXQUFXQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUNyQkEsSUFBSUEsU0FBU0EsR0FBR0E7WUFDYkEsUUFBUUEsRUFBRUEsRUFBRUEsYUFBYUEsRUFBRUEsQ0FBQ0EsRUFBRUEsSUFBSUEsRUFBRUEsRUFBRUEsR0FBR0E7WUFDekNBLFFBQVFBLEVBQUVBLEVBQUVBLGFBQWFBLEVBQUVBLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLEVBQUVBLEdBQW1CQTtZQUN6REEsTUFBTUEsRUFBSUEsRUFBRUEsYUFBYUEsRUFBRUEsQ0FBQ0EsRUFBRUEsSUFBSUEsRUFBRUEsRUFBRUEsR0FBR0E7WUFDekNBLE9BQU9BLEVBQUdBLEVBQUVBLGFBQWFBLEVBQUVBLENBQUNBLEVBQUVBLElBQUlBLEVBQUVBLEVBQUVBLEdBQXlCQTtTQUNqRUEsQ0FBQUE7UUFDREEsSUFBSUEsV0FBV0EsR0FBR0EsRUFBRUEsQ0FBQ0E7UUFDckJBLElBQUlBLE1BQU1BLEdBQUdBLEVBQUVBLENBQUNBO1FBQ2hCQSxJQUFJQSxPQUFPQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUNqQkEsSUFBSUEsU0FBU0EsR0FBR0EsRUFBRUEsQ0FBQ0E7UUFDbkJBLDRCQUE0QkE7UUFDNUJBLElBQUlBLENBQUNBLEdBQUdBLEdBQUdBLENBQUNBO1FBQ1pBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEVBQUVBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEdBQUdBLENBQUNBLEVBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBO1lBQ3pCQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxFQUFFQSxFQUFFQSxDQUFDQTtnQkFDOUJBLFdBQVdBLENBQUNBLElBQUlBLENBQUNBLEtBQUtBLENBQUNBLFdBQVdBLEVBQUVBLENBQUNBLEVBQUVBLEdBQUdBLENBQUNBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLEVBQUVBLEdBQUdBLENBQUNBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO2dCQUNuRkEsTUFBTUEsQ0FBQ0EsSUFBSUEsQ0FBQ0EsS0FBS0EsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3RDQSxTQUFTQSxDQUFDQSxJQUFJQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDcERBLEVBQUVBLENBQUNBLENBQUVBLEVBQUVBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLElBQUlBLEVBQUVBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO29CQUNwQ0EsT0FBT0EsQ0FBQ0EsSUFBSUEsQ0FBQ0EsRUFBRUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsR0FBR0EsRUFBRUEsR0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsRUFBRUEsRUFBRUEsR0FBR0EsQ0FBQ0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7b0JBQzVEQSxPQUFPQSxDQUFDQSxJQUFJQSxDQUFDQSxFQUFFQSxHQUFHQSxFQUFFQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDdEVBLENBQUNBO1lBQ1BBLENBQUNBO1FBQ0hBLENBQUNBO1FBQ0RBLDRDQUE0Q0E7UUFDNUNBLCtDQUErQ0E7UUFDL0NBLHNDQUFzQ0E7UUFDdENBLDBFQUEwRUE7UUFDMUVBLG9GQUFvRkE7UUFDcEZBLDJDQUEyQ0E7UUFDM0NBLDJDQUEyQ0E7UUFDM0NBLFFBQVFBO1FBQ1JBLFFBQVFBO1FBQ1JBLE1BQU1BO1FBRU5BLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEVBQUVBLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEdBQUdBLFNBQVNBLENBQUNBLE1BQU1BLEdBQUdBLENBQUNBLEVBQUVBLEVBQUVBLEVBQUVBLEVBQUVBLENBQUNBO1lBQ2pEQSxJQUFJQSxLQUFLQSxHQUFHQSxTQUFTQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtZQUMxQkEsU0FBU0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsR0FBR0EsU0FBU0EsQ0FBQ0EsU0FBU0EsQ0FBQ0EsTUFBTUEsR0FBR0EsRUFBRUEsR0FBR0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDckRBLFNBQVNBLENBQUNBLFNBQVNBLENBQUNBLE1BQU1BLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLEtBQUtBLENBQUNBO1FBQy9DQSxDQUFDQTtRQUNEQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxFQUFFQSxFQUFFQSxHQUFHQSxTQUFTQSxDQUFDQSxNQUFNQSxFQUFFQSxFQUFFQSxJQUFFQSxDQUFDQSxFQUFFQSxDQUFDQTtZQUM5Q0EsSUFBSUEsS0FBS0EsR0FBR0EsU0FBU0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsQ0FBQ0E7WUFDNUJBLFNBQVNBLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLFNBQVNBLENBQUNBLEVBQUVBLEdBQUdBLENBQUNBLENBQUNBLENBQUNBO1lBQ2xDQSxTQUFTQSxDQUFDQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxHQUFHQSxLQUFLQSxDQUFDQTtRQUMxQkEsQ0FBQ0E7UUFDREEsU0FBU0EsQ0FBQ0EsUUFBUUEsQ0FBQ0EsSUFBSUEsR0FBR0EsV0FBV0EsQ0FBQ0E7UUFDcENBLFNBQVNBLENBQUNBLE9BQU9BLENBQUNBLElBQUlBLEdBQUdBLE9BQU9BLENBQUNBO1FBQ2pDQSxTQUFTQSxDQUFDQSxRQUFRQSxDQUFDQSxJQUFJQSxHQUFHQSxTQUFTQSxDQUFDQTtRQUNwQ0EsU0FBU0EsQ0FBQ0EsTUFBTUEsQ0FBQ0EsSUFBSUEsR0FBR0EsTUFBTUEsQ0FBQ0E7UUFDakNBLElBQUlBLFVBQVVBLEdBQUdBLDBCQUEwQkEsQ0FBQ0EsRUFBRUEsRUFBRUEsTUFBTUEsQ0FBQ0EsQ0FBQ0E7UUFDeERBLGtCQUFrQkEsQ0FBQ0E7WUFDakJFLE1BQU1BLENBQUNBLENBQUNBLEdBQUdBLElBQUlBLENBQUNBLEVBQUVBLEdBQUdBLEdBQUdBLENBQUNBO1FBQzNCQSxDQUFDQTtRQUVERixJQUFJQSxrQkFBa0JBLEdBQUdBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1FBQ3JDQSxJQUFJQSxrQkFBa0JBLEdBQUdBLFFBQVFBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO1FBQ3RDQSxJQUFJQSxZQUFZQSxHQUFHQSxFQUFFQSxDQUFDQTtRQUV0QkEsSUFBSUEsbUNBQW1DQSxHQUFHQTtZQUN4Q0EsZUFBZUEsRUFBVUEsQ0FBQ0EsRUFBRUEsRUFBRUEsRUFBRUEsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0E7WUFDdkNBLGFBQWFBLEVBQVlBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBO1lBQ3RDQSxZQUFZQSxFQUFhQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtZQUNyQ0EsU0FBU0EsRUFBZ0JBLENBQUNBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLEVBQUVBLEdBQUdBLENBQUNBO1lBQzdDQSxNQUFNQSxFQUFtQkEsQ0FBQ0E7U0FDM0JBLENBQUNBO1FBRUZBLElBQUlBLG9DQUFvQ0EsR0FBR0E7WUFDekNBLHFCQUFxQkEsRUFBSUEsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUE7WUFDdENBLE9BQU9BLEVBQWtCQSxJQUFJQSxDQUFDQSxNQUFNQSxFQUFFQTtZQUN0Q0EsdUJBQXVCQSxFQUFFQSxJQUFJQSxDQUFDQSxNQUFNQSxFQUFFQTtZQUN0Q0EsT0FBT0EsRUFBQ0EsV0FBV0E7WUFDbkJBLFNBQVNBLEVBQUVBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBO1lBQ25GQSxTQUFTQSxFQUFFQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtTQUNwRkEsQ0FBQ0E7UUFFRkEsbURBQW1EQTtRQUVuREEsSUFBSUEsU0FBU0EsR0FBR0EsSUFBSUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7UUFDMUJBLElBQUlBLFdBQVdBLEdBQUdBO1lBQ2RBLGdCQUFnQkEsRUFBRUE7Z0JBQ2hCQSxXQUFXQSxFQUFjQSxNQUFNQSxDQUFDQSxHQUFHQSxDQUFDQSxJQUFJQSxDQUFDQSxTQUFTQSxFQUFFQSxTQUFTQSxHQUFHQSxHQUFHQSxDQUFDQSxFQUFFQSxHQUFHQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxFQUFFQTtnQkFDbEZBLG1DQUFtQ0E7Z0JBQ25DQSxVQUFVQSxFQUFlQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQTtnQkFDckNBLFdBQVdBLEVBQWNBLEdBQUdBO2dCQUM1QkEsZ0JBQWdCQSxFQUFTQSxJQUFJQTthQUM5QkE7U0FDSkEsQ0FBQ0E7UUFFRkEsbUNBQW1DQTtRQUNuQ0EsSUFBSUEsZ0JBQWdCQSxHQUFHQSxJQUFJQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQTtRQUNyQ0EsSUFBSUEsVUFBVUEsR0FBR0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0E7UUFDL0JBLElBQUlBLGNBQWNBLEdBQUdBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBLENBQUNBO1FBQ25DQSxJQUFJQSxNQUFNQSxHQUFHQSxJQUFJQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQSxDQUFFQSxtQkFBbUJBO1FBQ2hEQSxJQUFJQSxTQUFTQSxHQUFHQSxJQUFJQSxDQUFDQSxNQUFNQSxFQUFFQSxDQUFDQTtRQUM5QkEsSUFBSUEsVUFBVUEsR0FBR0EsSUFBSUEsQ0FBQ0EsTUFBTUEsRUFBRUEsQ0FBQ0E7UUFDL0JBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLENBQUNBLEdBQUdBLENBQUNBLEVBQUVBLENBQUNBLEdBQUdBLEVBQUVBLEVBQUVBLENBQUNBLEVBQUVBLEVBQUVBLENBQUNBO1lBQzVCQSxvQ0FBb0NBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQ2hFQSxvQ0FBb0NBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBLENBQUNBLEdBQUdBLElBQUlBLENBQUNBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1FBQ2xFQSxDQUFDQTtRQUVEQSxxQkFBcUJBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO1FBRWpDQSxrQkFBa0JBO1FBQ2xCQSxtQkFBbUJBLElBQVlBO1lBQzdCRyxJQUFJQSxJQUFJQSxLQUFLQSxDQUFDQTtZQUNkQSxFQUFFQSxDQUFBQSxDQUFDQSxPQUFPQSxJQUFJQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDbEJBLElBQUlBLFdBQVdBLEdBQUdBLDBCQUEwQkEsQ0FBQ0EsRUFBRUEsRUFBRUEsU0FBU0EsQ0FBQ0EsQ0FBQ0E7WUFFNURBLENBQUNBO1lBQ0RBLG1DQUFtQ0EsQ0FBQ0EsTUFBTUEsR0FBR0EsbUNBQW1DQSxDQUFDQSxNQUFNQSxHQUFHQSxJQUFJQSxDQUFDQTtZQUU5RkEsSUFBSUEsT0FBT0EsR0FBR0Esd0JBQXdCQSxDQUFDQSxFQUFFQSxFQUFFQSxDQUFDQSxVQUFVQSxDQUFDQSxPQUFPQSxDQUFDQSxFQUFFQSxVQUFVQSxDQUFDQSxPQUFPQSxHQUFHQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUM1RkEsSUFBSUEsY0FBY0EsR0FBR0Esb0JBQW9CQSxDQUFDQSxFQUFFQSxFQUFFQSxPQUFPQSxDQUFDQSxDQUFDQTtZQUN2REEsSUFBSUEsYUFBYUEsR0FBSUEsc0JBQXNCQSxDQUFDQSxFQUFFQSxFQUFFQSxPQUFPQSxDQUFDQSxDQUFDQTtZQUV6REEsZ0RBQWdEQTtZQUNoREEsS0FBS0EsQ0FBQ0EsS0FBS0EsRUFBRUEsQ0FBQ0E7WUFFZEEsc0dBQXNHQTtZQUN0R0EsNEdBQTRHQTtZQUM1R0Esa0VBQWtFQTtZQUNsRUEseUJBQXlCQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQTtZQUVsQ0EsdUNBQXVDQTtZQUN2Q0EsRUFBRUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsTUFBTUEsQ0FBQ0EsS0FBS0EsRUFBRUEsTUFBTUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsQ0FBQ0E7WUFDL0NBLHlDQUF5Q0E7WUFDekNBLEVBQUVBLENBQUNBLEtBQUtBLENBQUNBLEVBQUVBLENBQUNBLGdCQUFnQkEsR0FBR0EsRUFBRUEsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQTtZQUVwREEsZ0NBQWdDQTtZQUNoQ0EsSUFBSUEsTUFBTUEsR0FBR0EsTUFBTUEsQ0FBQ0EsV0FBV0EsR0FBR0EsTUFBTUEsQ0FBQ0EsWUFBWUEsQ0FBQ0E7WUFDdERBLElBQUlBLENBQUNBLFdBQVdBLENBQUNBLGdCQUFnQkEsRUFBQ0Esa0JBQWtCQSxFQUFFQSxNQUFNQSxFQUFFQSxDQUFDQSxFQUFFQSxJQUFJQSxDQUFDQSxDQUFDQTtZQUV2RUEsNkNBQTZDQTtZQUM3Q0EsSUFBSUEsY0FBY0EsR0FBR0EsQ0FBQ0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsR0FBR0EsQ0FBQ0EsQ0FBQ0E7WUFDbENBLElBQUlBLE1BQU1BLEdBQUdBLENBQUNBLENBQUNBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQ3ZCQSxJQUFJQSxFQUFFQSxHQUFHQSxDQUFDQSxDQUFDQSxFQUFFQSxDQUFDQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNuQkEsSUFBSUEsWUFBWUEsR0FBR0EsSUFBSUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsbUNBQW1DQSxDQUFDQSxhQUFhQSxFQUFFQSxjQUFjQSxFQUFFQSxNQUFNQSxFQUFFQSxFQUFFQSxDQUFDQSxDQUFDQTtZQUU5R0EsNkNBQTZDQTtZQUM3Q0EsSUFBSUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsVUFBVUEsRUFBRUEsWUFBWUEsQ0FBQ0EsQ0FBQ0E7WUFFdENBLGtFQUFrRUE7WUFDbEVBLEVBQUVBLENBQUNBLFVBQVVBLENBQUNBLE9BQU9BLENBQUNBLENBQUNBO1lBQ3ZCQSxJQUFJQSxnQkFBZ0JBLEdBQUdBLEVBQUVBLENBQUNBLGtCQUFrQkEsQ0FBQ0EsT0FBT0EsRUFBRUEsVUFBVUEsQ0FBQ0EsQ0FBQ0E7WUFDbEVBLElBQUlBLGdCQUFnQkEsR0FBR0EsRUFBRUEsQ0FBQ0Esa0JBQWtCQSxDQUFDQSxPQUFPQSxFQUFFQSxVQUFVQSxDQUFDQSxDQUFDQTtZQUdsRUEsaURBQWlEQTtZQUNqREEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ3ZCQSx1QkFBdUJBLENBQUNBLEVBQUVBLEVBQUVBLGFBQWFBLEVBQUVBLFdBQVdBLENBQUNBLENBQUNBO1lBQ3BEQSxDQUFDQTtZQUFDQSxJQUFJQSxDQUFDQSxDQUFDQTtnQkFDUkEsdUJBQXVCQSxDQUFDQSxFQUFFQSxFQUFFQSxhQUFhQSxFQUFFQSxVQUFVQSxDQUFDQSxDQUFDQTtZQUN6REEsQ0FBQ0E7WUFFQ0Esa0dBQWtHQTtZQUNsR0EsOEZBQThGQTtZQUM5RkEsOEVBQThFQTtZQUM5RUEsV0FBV0EsQ0FBQ0EsY0FBY0EsRUFBRUEsbUNBQW1DQSxDQUFDQSxDQUFDQTtZQUVqRUEsRUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsZ0JBQWdCQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNsQ0EsRUFBRUEsQ0FBQ0EsU0FBU0EsQ0FBQ0EsZ0JBQWdCQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNsQ0EsRUFBRUEsQ0FBQ0EsYUFBYUEsQ0FBQ0EsRUFBRUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsQ0FBQ0E7WUFDOUJBLEVBQUVBLENBQUNBLFdBQVdBLENBQUNBLEVBQUVBLENBQUNBLFVBQVVBLEVBQUVBLFFBQVFBLENBQUNBLENBQUNBLENBQUNBLENBQUNBLENBQUNBO1lBQzNDQSxFQUFFQSxDQUFDQSxhQUFhQSxDQUFDQSxFQUFFQSxDQUFDQSxRQUFRQSxDQUFDQSxDQUFDQTtZQUM5QkEsRUFBRUEsQ0FBQ0EsV0FBV0EsQ0FBQ0EsRUFBRUEsQ0FBQ0EsVUFBVUEsRUFBRUEsUUFBUUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7WUFDM0NBLHVEQUF1REE7WUFDdkRBLDBFQUEwRUE7WUFFMUVBLDBDQUEwQ0E7WUFDMUNBLElBQUlBLENBQUNBLElBQUlBLENBQUNBLE1BQU1BLEVBQUVBLGNBQWNBLENBQUNBLENBQUNBO1lBRWxDQSx3RkFBd0ZBO1lBQ3hGQSxFQUFFQSxDQUFDQSxDQUFDQSxXQUFXQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxJQUFJQSxXQUFXQSxDQUFDQSxDQUFDQSxDQUFDQSxLQUFLQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFDakRBOzs7Ozs7Ozs7OztrQkFXRUE7Z0JBRUZBLHNFQUFzRUE7Z0JBQ3RFQSxJQUFJQSxDQUFDQSxNQUFNQSxDQUFDQSxTQUFTQSxFQUFFQSxNQUFNQSxDQUFDQSxDQUFDQTtnQkFDL0JBLHVCQUF1QkE7Z0JBQ3ZCQSxJQUFJQSxLQUFLQSxHQUFHQSxJQUFJQSxDQUFDQSxhQUFhQSxDQUFDQSxVQUFVQSxFQUFFQSxJQUFJQSxDQUFDQSxVQUFVQSxDQUFDQSxDQUFDQSxFQUFDQSxDQUFDQSxFQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxTQUFTQSxDQUFDQSxDQUFDQTtnQkFFOUVBLGdDQUFnQ0E7Z0JBQ2hDQSxJQUFJQSxDQUFDQSxNQUFNQSxDQUFDQSxNQUFNQSxFQUFFQSxNQUFNQSxFQUFFQSxXQUFXQSxDQUFDQSxDQUFDQSxDQUFDQSxFQUFFQSxLQUFLQSxDQUFDQSxDQUFDQTtnQkFFbkRBLG9FQUFvRUE7Z0JBQ3BFQSxJQUFJQSxDQUFDQSxJQUFJQSxDQUFDQSxjQUFjQSxFQUFFQSxNQUFNQSxDQUFDQSxDQUFDQTtnQkFFbENBLDhCQUE4QkE7Z0JBQzlCQSxXQUFXQSxJQUFJQSxXQUFXQSxDQUFDQSxDQUFDQSxDQUFDQSxDQUFDQTtnQkFFOUJBLElBQUlBLENBQUNBLEdBQUdBLENBQUNBLFdBQVdBLEVBQUVBLENBQUNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQzlCQSxDQUFDQTtZQUNEQSxvQ0FBb0NBLENBQUNBLE9BQU9BLEdBQUdBLFdBQVdBLENBQUNBO1lBQzNEQSw4RUFBOEVBO1lBQzlFQSxJQUFJQSxDQUFDQSxTQUFTQSxDQUFDQSxNQUFNQSxFQUFFQSxjQUFjQSxFQUFFQSxDQUFDQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFDQSxXQUFXQSxFQUFFQSxDQUFDQSxNQUFNQSxDQUFDQSxDQUFDQSxDQUFDQSxHQUFDQSxXQUFXQTtnQkFDOUNBLENBQUNBLE1BQU1BLENBQUNBLENBQUNBLENBQUNBLEdBQUNBLFdBQVdBLENBQUNBLENBQUNBLENBQUNBO1lBQ2pFQSxJQUFJQSxDQUFDQSxLQUFLQSxDQUFDQSxNQUFNQSxFQUFFQSxNQUFNQSxFQUFFQSxDQUFDQSxXQUFXQSxFQUFFQSxXQUFXQSxFQUFFQSxXQUFXQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUNwRUEsSUFBSUEsQ0FBQ0EsSUFBSUEsQ0FBQ0Esb0NBQW9DQSxDQUFDQSxPQUFPQSxFQUFFQSxNQUFNQSxDQUFDQSxDQUFDQTtZQUVoRUEsMEJBQTBCQTtZQUMxQkEsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0EsTUFBTUEsRUFBRUEsVUFBVUEsRUFBRUEsb0NBQW9DQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQTtZQUNoRkEsSUFBSUEsQ0FBQ0EsUUFBUUEsQ0FBQ0Esb0NBQW9DQSxDQUFDQSxxQkFBcUJBLEVBQUVBLGdCQUFnQkEsRUFBRUEsTUFBTUEsQ0FBQ0EsQ0FBQ0E7WUFFcEdBLCtGQUErRkE7WUFDL0ZBLDJEQUEyREE7WUFDM0RBLElBQUlBLENBQUNBLFNBQVNBLENBQUNBLG9DQUFvQ0EsQ0FBQ0EsdUJBQXVCQSxFQUM1REEsSUFBSUEsQ0FBQ0EsTUFBTUEsQ0FBQ0EsTUFBTUEsRUFBRUEsb0NBQW9DQSxDQUFDQSxPQUFPQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUVsRkEsb0NBQW9DQTtZQUNwQ0EsV0FBV0EsQ0FBQ0EsY0FBY0EsRUFBRUEsb0NBQW9DQSxDQUFDQSxDQUFDQTtZQUVsRUEseURBQXlEQTtZQUN6REEsV0FBV0EsQ0FBQ0EsY0FBY0EsRUFBRUEsV0FBV0EsQ0FBQ0EsZ0JBQWdCQSxDQUFDQSxDQUFDQTtZQUUxREEscURBQXFEQTtZQUNyREEsRUFBRUEsQ0FBQ0EsQ0FBQ0EsT0FBT0EsSUFBSUEsQ0FBQ0EsQ0FBQ0EsQ0FBQ0EsQ0FBQ0E7Z0JBQ25CQSxFQUFFQSxDQUFDQSxZQUFZQSxDQUFDQSxFQUFFQSxDQUFDQSxTQUFTQSxFQUFFQSxXQUFXQSxDQUFDQSxXQUFXQSxFQUFFQSxFQUFFQSxDQUFDQSxjQUFjQSxFQUFFQSxDQUFDQSxDQUFDQSxDQUFDQTtZQUM3RUEsQ0FBQ0E7WUFBQ0EsSUFBSUEsQ0FBQ0EsQ0FBQ0E7Z0JBQ1JBLEVBQUVBLENBQUNBLFlBQVlBLENBQUNBLEVBQUVBLENBQUNBLFNBQVNBLEVBQUVBLFVBQVVBLENBQUNBLFdBQVdBLEVBQUVBLEVBQUVBLENBQUNBLGNBQWNBLEVBQUVBLENBQUNBLENBQUNBLENBQUNBO1lBQzlFQSxDQUFDQTtZQUVDQSxjQUFjQTtZQUNkQSxLQUFLQSxDQUFDQSxHQUFHQSxFQUFFQSxDQUFDQTtZQUVaQSxxQkFBcUJBLENBQUNBLFNBQVNBLENBQUNBLENBQUNBO1FBQ25DQSxDQUFDQTtJQUNISCxDQUFDQSIsImZpbGUiOiJhNC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vLzxyZWZlcmVuY2UgcGF0aD0nLi90eXBpbmdzL3RzZC5kLnRzJy8+XG4vLy88cmVmZXJlbmNlIHBhdGg9XCIuL2xvY2FsVHlwaW5ncy93ZWJnbHV0aWxzLmQudHNcIi8+XG4vL2dldCBzdGFydCBieSBzdHVmZiBub3QgaW4gc2hhZGVyc1xuLy9cbi8qXG4gKiBQb3J0aW9ucyBvZiB0aGlzIGNvZGUgYXJlXG4gKiBDb3B5cmlnaHQgMjAxNSwgQmxhaXIgTWFjSW50eXJlLlxuICogXG4gKiBQb3J0aW9ucyBvZiB0aGlzIGNvZGUgdGFrZW4gZnJvbSBodHRwOi8vd2ViZ2xmdW5kYW1lbnRhbHMub3JnLCBhdCBodHRwczovL2dpdGh1Yi5jb20vZ3JlZ2dtYW4vd2ViZ2wtZnVuZGFtZW50YWxzXG4gKiBhbmQgYXJlIHN1YmplY3QgdG8gdGhlIGZvbGxvd2luZyBsaWNlbnNlLiAgSW4gcGFydGljdWxhciwgZnJvbSBcbiAqICAgIGh0dHA6Ly93ZWJnbGZ1bmRhbWVudGFscy5vcmcvd2ViZ2wvd2ViZ2wtbGVzcy1jb2RlLW1vcmUtZnVuLmh0bWxcbiAqICAgIGh0dHA6Ly93ZWJnbGZ1bmRhbWVudGFscy5vcmcvd2ViZ2wvcmVzb3VyY2VzL3ByaW1pdGl2ZXMuanNcbiAqIFxuICogVGhvc2UgcG9ydGlvbnMgQ29weXJpZ2h0IDIwMTQsIEdyZWdnIFRhdmFyZXMuXG4gKiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICovXG5cbmltcG9ydCBsb2FkZXIgPSByZXF1aXJlKCcuL2xvYWRlcicpO1xuXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gc3RhdHMgbW9kdWxlIGJ5IG1yZG9vYiAoaHR0cHM6Ly9naXRodWIuY29tL21yZG9vYi9zdGF0cy5qcykgdG8gc2hvdyB0aGUgcGVyZm9ybWFuY2UgXG4vLyBvZiB5b3VyIGdyYXBoaWNzXG52YXIgc3RhdHMgPSBuZXcgU3RhdHMoKTtcbnN0YXRzLnNldE1vZGUoIDEgKTsgLy8gMDogZnBzLCAxOiBtcywgMjogbWJcblxuc3RhdHMuZG9tRWxlbWVudC5zdHlsZS5wb3NpdGlvbiA9ICdhYnNvbHV0ZSc7XG5zdGF0cy5kb21FbGVtZW50LnN0eWxlLnJpZ2h0ID0gJzBweCc7XG5zdGF0cy5kb21FbGVtZW50LnN0eWxlLnRvcCA9ICcwcHgnO1xuXG5kb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKCBzdGF0cy5kb21FbGVtZW50ICk7XG5cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyB1dGlsaXRpZXNcbnZhciByYW5kID0gZnVuY3Rpb24obWluOiBudW1iZXIsIG1heD86IG51bWJlcikge1xuICBpZiAobWF4ID09PSB1bmRlZmluZWQpIHtcbiAgICBtYXggPSBtaW47XG4gICAgbWluID0gMDtcbiAgfVxuICByZXR1cm4gbWluICsgTWF0aC5yYW5kb20oKSAqIChtYXggLSBtaW4pO1xufTtcblxudmFyIHJhbmRJbnQgPSBmdW5jdGlvbihyYW5nZSkge1xuICByZXR1cm4gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogcmFuZ2UpO1xufTtcblxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIGdldCBzb21lIG9mIG91ciBjYW52YXMgZWxlbWVudHMgdGhhdCB3ZSBuZWVkXG52YXIgY2FudmFzID0gPEhUTUxDYW52YXNFbGVtZW50PmRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwid2ViZ2xcIik7ICBcblxudmFyIGVmZmVjdEk7XG53aW5kb3dbXCJvbkVmZmVjdDFcIl0gPSAoKSA9PiB7XG4gICAgY29uc29sZS5sb2coXCJpbnN0YWxsIGVmZmVjdDEhXCIpO1xuICAgIGVmZmVjdEkgPSAyO1xuICAvLy8vLy8vLy8vLy8vL1xuICAvLy8vLy8vLy8gWU9VUiBDT0RFIEhFUkUgVE8gY2F1c2UgdGhlIHByb2dyYW0gdG8gdXNlIHlvdXIgZmlyc3Qgc2hhZGVyIGVmZmVjdFxuICAvLy8vLy8vLy8gKHlvdSBjYW4gcHJvYmFibHkganVzdCB1c2Ugc29tZSBzb3J0IG9mIGdsb2JhbCB2YXJpYWJsZSB0byBpbmRpY2F0ZSB3aGljaCBlZmZlY3QpXG4gIC8vLy8vLy8vLy8vLy8vXG59IFxuXG53aW5kb3dbXCJvbkVmZmVjdDJcIl0gPSAoKSA9PiB7XG4gICAgY29uc29sZS5sb2coXCJpbnN0YWxsIGVmZmVjdDIhXCIpO1xuICAgIGVmZmVjdEkgPSA0O1xuICAvLy8vLy8vLy8vLy8vL1xuICAvLy8vLy8vLy8gWU9VUiBDT0RFIEhFUkUgVE8gY2F1c2UgdGhlIHByb2dyYW0gdG8gdXNlIHlvdXIgc2Vjb25kIHNoYWRlciBlZmZlY3RcbiAgLy8vLy8vLy8vICh5b3UgY2FuIHByb2JhYmx5IGp1c3QgdXNlIHNvbWUgc29ydCBvZiBnbG9iYWwgdmFyaWFibGUgdG8gaW5kaWNhdGUgd2hpY2ggZWZmZWN0KVxuICAvLy8vLy8vLy8vLy8vL1xufSBcblxud2luZG93W1wib25FZmZlY3QzXCJdID0gKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwiaW5zdGFsbCBlZmZlY3QzIVwiKTtcbiAgICBlZmZlY3RJID0gNjtcbiAgLy8vLy8vLy8vLy8vLy9cbiAgLy8vLy8vLy8vIFlPVVIgQ09ERSBIRVJFIFRPIGNhdXNlIHRoZSBwcm9ncmFtIHRvIHVzZSB5b3VyIHRoaXJkIHNoYWRlciBlZmZlY3RcbiAgLy8vLy8vLy8vICh5b3UgY2FuIHByb2JhYmx5IGp1c3QgdXNlIHNvbWUgc29ydCBvZiBnbG9iYWwgdmFyaWFibGUgdG8gaW5kaWNhdGUgd2hpY2ggZWZmZWN0KVxuICAvLy8vLy8vLy8vLy8vL1xufSBcblxud2luZG93W1wib25FZmZlY3Q0XCJdID0gKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwiaW5zdGFsbCBlZmZlY3Q0IVwiKTtcbiAgICBlZmZlY3RJID0gODtcbiAgLy8vLy8vLy8vLy8vLy9cbiAgLy8vLy8vLy8vIFlPVVIgQ09ERSBIRVJFIFRPIGNhdXNlIHRoZSBwcm9ncmFtIHRvIHVzZSB5b3VyIGZvdXJ0aCBzaGFkZXIgZWZmZWN0XG4gIC8vLy8vLy8vLyAoeW91IGNhbiBwcm9iYWJseSBqdXN0IHVzZSBzb21lIHNvcnQgb2YgZ2xvYmFsIHZhcmlhYmxlIHRvIGluZGljYXRlIHdoaWNoIGVmZmVjdClcbiAgLy8vLy8vLy8vLy8vLy9cbn0gXG5cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBzb21lIHNpbXBsZSBpbnRlcmFjdGlvbiB1c2luZyB0aGUgbW91c2UuXG4vLyB3ZSBhcmUgZ29pbmcgdG8gZ2V0IHNtYWxsIG1vdGlvbiBvZmZzZXRzIG9mIHRoZSBtb3VzZSwgYW5kIHVzZSB0aGVzZSB0byByb3RhdGUgdGhlIG9iamVjdFxuLy9cbi8vIG91ciBvZmZzZXQoKSBmdW5jdGlvbiBmcm9tIGFzc2lnbm1lbnQgMCwgdG8gZ2l2ZSB1cyBhIGdvb2QgbW91c2UgcG9zaXRpb24gaW4gdGhlIGNhbnZhcyBcbmZ1bmN0aW9uIG9mZnNldChlOiBNb3VzZUV2ZW50KTogR0xNLklBcnJheSB7XG4gICAgZSA9IGUgfHwgPE1vdXNlRXZlbnQ+IHdpbmRvdy5ldmVudDtcblxuICAgIHZhciB0YXJnZXQgPSA8RWxlbWVudD4gZS50YXJnZXQgfHwgZS5zcmNFbGVtZW50LFxuICAgICAgICByZWN0ID0gdGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgICBvZmZzZXRYID0gZS5jbGllbnRYIC0gcmVjdC5sZWZ0LFxuICAgICAgICBvZmZzZXRZID0gZS5jbGllbnRZIC0gcmVjdC50b3A7XG5cbiAgICByZXR1cm4gdmVjMi5mcm9tVmFsdWVzKG9mZnNldFgsIG9mZnNldFkpO1xufVxuXG52YXIgbW91c2VTdGFydCA9IHVuZGVmaW5lZDsgIC8vIHByZXZpb3VzIG1vdXNlIHBvc2l0aW9uXG52YXIgbW91c2VEZWx0YSA9IHVuZGVmaW5lZDsgIC8vIHRoZSBhbW91bnQgdGhlIG1vdXNlIGhhcyBtb3ZlZFxudmFyIG1vdXNlQW5nbGVzID0gdmVjMi5jcmVhdGUoKTsgIC8vIGFuZ2xlIG9mZnNldCBjb3JyZXNwb25kaW5nIHRvIG1vdXNlIG1vdmVtZW50XG5cbi8vIHN0YXJ0IHRoaW5ncyBvZmYgd2l0aCBhIGRvd24gcHJlc3NcbmNhbnZhcy5vbm1vdXNlZG93biA9IChldjogTW91c2VFdmVudCkgPT4ge1xuICAgIG1vdXNlU3RhcnQgPSBvZmZzZXQoZXYpOyAgICAgICAgXG4gICAgbW91c2VEZWx0YSA9IHZlYzIuY3JlYXRlKCk7ICAvLyBpbml0aWFsaXplIHRvIDAsMFxuICAgIHZlYzIuc2V0KG1vdXNlQW5nbGVzLCAwLCAwKTtcbn1cblxuLy8gc3RvcCB0aGluZ3Mgd2l0aCBhIG1vdXNlIHJlbGVhc2VcbmNhbnZhcy5vbm1vdXNldXAgPSAoZXY6IE1vdXNlRXZlbnQpID0+IHtcbiAgICBpZiAobW91c2VTdGFydCAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgY29uc3QgY2xpY2tFbmQgPSBvZmZzZXQoZXYpO1xuICAgICAgICB2ZWMyLnN1Yihtb3VzZURlbHRhLCBjbGlja0VuZCwgbW91c2VTdGFydCk7ICAgICAgICAvLyBkZWx0YSA9IGVuZCAtIHN0YXJ0XG4gICAgICAgIHZlYzIuc2NhbGUobW91c2VBbmdsZXMsIG1vdXNlRGVsdGEsIDEwL2NhbnZhcy5oZWlnaHQpOyAgXG5cbiAgICAgICAgLy8gbm93IHRvc3MgdGhlIHR3byB2YWx1ZXMgc2luY2UgdGhlIG1vdXNlIGlzIHVwXG4gICAgICAgIG1vdXNlRGVsdGEgPSB1bmRlZmluZWQ7XG4gICAgICAgIG1vdXNlU3RhcnQgPSB1bmRlZmluZWQ7IFxuICAgIH1cbn1cblxuLy8gaWYgd2UncmUgbW92aW5nIGFuZCB0aGUgbW91c2UgaXMgZG93biAgICAgICAgXG5jYW52YXMub25tb3VzZW1vdmUgPSAoZXY6IE1vdXNlRXZlbnQpID0+IHtcbiAgICBpZiAobW91c2VTdGFydCAhPSB1bmRlZmluZWQpIHtcbiAgICAgIGNvbnN0IG0gPSBvZmZzZXQoZXYpO1xuICAgICAgdmVjMi5zdWIobW91c2VEZWx0YSwgbSwgbW91c2VTdGFydCk7ICAgIC8vIGRlbHRhID0gbW91c2UgLSBzdGFydCBcbiAgICAgIHZlYzIuY29weShtb3VzZVN0YXJ0LCBtKTsgICAgICAgICAgICAgICAvLyBzdGFydCBiZWNvbWVzIGN1cnJlbnQgcG9zaXRpb25cbiAgICAgIHZlYzIuc2NhbGUobW91c2VBbmdsZXMsIG1vdXNlRGVsdGEsIDEwL2NhbnZhcy5oZWlnaHQpO1xuXG4gICAgICAvLyBjb25zb2xlLmxvZyhcIm1vdXNlbW92ZSBtb3VzZUFuZ2xlczogXCIgKyBtb3VzZUFuZ2xlc1swXSArIFwiLCBcIiArIG1vdXNlQW5nbGVzWzFdKTtcbiAgICAgIC8vIGNvbnNvbGUubG9nKFwibW91c2Vtb3ZlIG1vdXNlRGVsdGE6IFwiICsgbW91c2VEZWx0YVswXSArIFwiLCBcIiArIG1vdXNlRGVsdGFbMV0pO1xuICAgICAgLy8gY29uc29sZS5sb2coXCJtb3VzZW1vdmUgbW91c2VTdGFydDogXCIgKyBtb3VzZVN0YXJ0WzBdICsgXCIsIFwiICsgbW91c2VTdGFydFsxXSk7XG4gICB9XG59XG5cbi8vIHN0b3AgdGhpbmdzIGlmIHlvdSBtb3ZlIG91dCBvZiB0aGUgd2luZG93XG5jYW52YXMub25tb3VzZW91dCA9IChldjogTW91c2VFdmVudCkgPT4ge1xuICAgIGlmIChtb3VzZVN0YXJ0ICE9IHVuZGVmaW5lZCkge1xuICAgICAgdmVjMi5zZXQobW91c2VBbmdsZXMsIDAsIDApO1xuICAgICAgbW91c2VEZWx0YSA9IHVuZGVmaW5lZDtcbiAgICAgIG1vdXNlU3RhcnQgPSB1bmRlZmluZWQ7XG4gICAgfVxufVxuXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLy8gc3RhcnQgdGhpbmdzIG9mZiBieSBjYWxsaW5nIGluaXRXZWJHTFxuaW5pdFdlYkdMKCk7XG5cbmZ1bmN0aW9uIGluaXRXZWJHTCgpIHtcbiAgLy8gZ2V0IHRoZSByZW5kZXJpbmcgY29udGV4dCBmb3Igd2ViR0xcbiAgdmFyIGdsOiBXZWJHTFJlbmRlcmluZ0NvbnRleHQgPSBnZXRXZWJHTENvbnRleHQoY2FudmFzKTtcbiAgaWYgKCFnbCkge1xuICAgIHJldHVybjsgIC8vIG5vIHdlYmdsISAgQnllIGJ5ZVxuICB9XG5cbiAgLy8gdHVybiBvbiBiYWNrZmFjZSBjdWxsaW5nIGFuZCB6YnVmZmVyaW5nXG4gIC8vZ2wuZW5hYmxlKGdsLkNVTExfRkFDRSk7XG4gIGdsLmVuYWJsZShnbC5ERVBUSF9URVNUKTtcblxuICAvLyBhdHRlbXB0IHRvIGRvd25sb2FkIGFuZCBzZXQgdXAgb3VyIEdMU0wgc2hhZGVycy4gIFdoZW4gdGhleSBkb3dubG9hZCwgcHJvY2Vzc2VkIHRvIHRoZSBuZXh0IHN0ZXBcbiAgLy8gb2Ygb3VyIHByb2dyYW0sIHRoZSBcIm1haW5cIiByb3V0aW5nXG4gIC8vIFxuICAvLyBZT1UgU0hPVUxEIE1PRElGWSBUSElTIFRPIERPV05MT0FEIEFMTCBZT1VSIFNIQURFUlMgYW5kIHNldCB1cCBhbGwgZm91ciBTSEFERVIgUFJPR1JBTVMsXG4gIC8vIFRIRU4gUEFTUyBBTiBBUlJBWSBPRiBQUk9HUkFNUyBUTyBtYWluKCkuICBZb3UnbGwgaGF2ZSB0byBkbyBvdGhlciB0aGluZ3MgaW4gbWFpbiB0byBkZWFsXG4gIC8vIHdpdGggbXVsdGlwbGUgc2hhZGVycyBhbmQgc3dpdGNoIGJldHdlZW4gdGhlbVxuICBsb2FkZXIubG9hZEZpbGVzKFsnc2hhZGVycy9hMy1zaGFkZXIudmVydCcsICdzaGFkZXJzL2EzLXNoYWRlci5mcmFnJyxcbiAgICAnc2hhZGVycy90cmFuc3BhcmVuY3kudmVydCcsICdzaGFkZXJzL3RyYW5zcGFyZW5jeS5mcmFnJyxcbiAgICAnc2hhZGVycy9KdWxpYS52ZXQnLCAnc2hhZGVycy9KdWxpYS5mcmFnJywnc2hhZGVycy9pbWFnZS52ZXJ0JywgJ3NoYWRlcnMvaW1hZ2UuZnJhZycsXG4gICAgJ3NoYWRlcnMvdmVydGV4c2hhZGVyLnZlcnQnLCdzaGFkZXJzL3ZlcnRleHNoYWRlci5mcmF0J10sIGZ1bmN0aW9uIChzaGFkZXJUZXh0KSB7XG4gICAgLy8gdmFyIHByb2dyYW0gPSBjcmVhdGVQcm9ncmFtRnJvbVNvdXJjZXMoZ2wsIFtzaGFkZXJUZXh0WzBdLCBzaGFkZXJUZXh0WzFdXSk7XG4gICAgbWFpbihnbCwgc2hhZGVyVGV4dCk7XG4gIH0sIGZ1bmN0aW9uICh1cmwpIHtcbiAgICAgIGFsZXJ0KCdTaGFkZXIgZmFpbGVkIHRvIGRvd25sb2FkIFwiJyArIHVybCArICdcIicpO1xuICB9KTtcbn1cblxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIHdlYkdMIGlzIHNldCB1cCwgYW5kIG91ciBTaGFkZXIgcHJvZ3JhbSBoYXMgYmVlbiBjcmVhdGVkLiAgRmluaXNoIHNldHRpbmcgdXAgb3VyIHdlYkdMIGFwcGxpY2F0aW9uICAgICAgIFxuZnVuY3Rpb24gbWFpbihnbDogV2ViR0xSZW5kZXJpbmdDb250ZXh0LCBzaGFkZXJUZXh0KSB7XG4gIHZhciB0ZXh0dXJlcyA9IFtdO1xuICBmdW5jdGlvbiBsb2FkaW5naW1hZ2UoaW1hZ2UpIHtcbiAgICB2YXIgdGV4dHVyZSA9IGdsLmNyZWF0ZVRleHR1cmUoKTtcbiAgICBnbC5iaW5kVGV4dHVyZShnbC5URVhUVVJFXzJELCB0ZXh0dXJlKTtcbiAgICAgIC8vIFNldCB0aGUgcGFyYW1ldGVycyBzbyB3ZSBjYW4gcmVuZGVyIGFueSBzaXplIGltYWdlLlxuICAgIGdsLnRleFBhcmFtZXRlcmkoZ2wuVEVYVFVSRV8yRCwgZ2wuVEVYVFVSRV9XUkFQX1MsIGdsLkNMQU1QX1RPX0VER0UpO1xuICAgIGdsLnRleFBhcmFtZXRlcmkoZ2wuVEVYVFVSRV8yRCwgZ2wuVEVYVFVSRV9XUkFQX1QsIGdsLkNMQU1QX1RPX0VER0UpO1xuICAgIGdsLnRleFBhcmFtZXRlcmkoZ2wuVEVYVFVSRV8yRCwgZ2wuVEVYVFVSRV9NSU5fRklMVEVSLCBnbC5ORUFSRVNUKTtcbiAgICBnbC50ZXhQYXJhbWV0ZXJpKGdsLlRFWFRVUkVfMkQsIGdsLlRFWFRVUkVfTUFHX0ZJTFRFUiwgZ2wuTkVBUkVTVCk7XG4gICAgICAvLyBVcGxvYWQgdGhlIGltYWdlIGludG8gdGhlIHRleHR1cmUuXG4gICAgZ2wudGV4SW1hZ2UyRChnbC5URVhUVVJFXzJELCAwLCBnbC5SR0JBLCBnbC5SR0JBLCBnbC5VTlNJR05FRF9CWVRFLCBpbWFnZSk7XG4gXG4gICAgLy8gYWRkIHRoZSB0ZXh0dXJlIHRvIHRoZSBhcnJheSBvZiB0ZXh0dXJlcy5cbiAgICB0ZXh0dXJlcy5wdXNoKHRleHR1cmUpO1xuICB9XG4gIC8vIHZhciBpbWFnZXMgPSBbXTtcbiAgdmFyIGltYWdlMSA9IG5ldyBJbWFnZSgpO1xuICBpbWFnZTEuc3JjID0gXCJzaGFkZXJzL3RpdGFuLmpwZ1wiO1xuICBpbWFnZTEub25sb2FkID0gZnVuY3Rpb24oKSB7bG9hZGluZ2ltYWdlKGltYWdlMSl9O1xuICAvLyBpbWFnZXMucHVzaChpbWFnZTEpO1xuICB2YXIgaW1hZ2UyID0gbmV3IEltYWdlKCk7XG4gIGltYWdlMi5zcmMgPSBcInNoYWRlcnMvbGV2aS5qcGdcIjtcbiAgaW1hZ2UyLm9ubG9hZCA9IGZ1bmN0aW9uKCkgeyBsb2FkaW5naW1hZ2UoaW1hZ2UyKSB9O1xuXG4gIC8vIGltYWdlcy5wdXNoKGltYWdlMik7XG4gIC8vIHVzZSB0aGUgd2ViZ2wtdXRpbHMgbGlicmFyeSB0byBjcmVhdGUgc2V0dGVycyBmb3IgYWxsIHRoZSB1bmlmb3JtcyBhbmQgYXR0cmlidXRlcyBpbiBvdXIgc2hhZGVycy5cbiAgLy8gSXQgZW51bWVyYXRlcyBhbGwgb2YgdGhlIHVuaWZvcm1zIGFuZCBhdHRyaWJ1dGVzIGluIHRoZSBwcm9ncmFtLCBhbmQgY3JlYXRlcyB1dGlsaXR5IGZ1bmN0aW9ucyB0byBcbiAgLy8gYWxsb3cgXCJzZXRVbmlmb3Jtc1wiIGFuZCBcInNldEF0dHJpYnV0ZXNcIiAoYmVsb3cpIHRvIHNldCB0aGUgc2hhZGVyIHZhcmlhYmxlcyBmcm9tIGEgamF2YXNjcmlwdCBvYmplY3QuIFxuICAvLyBUaGUgb2JqZWN0cyBoYXZlIGEga2V5IGZvciBlYWNoIHVuaWZvcm0gb3IgYXR0cmlidXRlLCBhbmQgYSB2YWx1ZSBjb250YWluaW5nIHRoZSBwYXJhbWV0ZXJzIGZvciB0aGVcbiAgLy8gc2V0dGVyIGZ1bmN0aW9uXG4gIGlmIChlZmZlY3RJID09IHVuZGVmaW5lZCkge1xuICAgIGVmZmVjdEkgPSAwO1xuICB9XG4gIC8vIHZhciBwcm9ncmFtID0gY3JlYXRlUHJvZ3JhbUZyb21Tb3VyY2VzKGdsLCBbc2hhZGVyVGV4dFtlZmZlY3RJXSwgc2hhZGVyVGV4dFtlZmZlY3RJICsgMV1dKTtcbiAgLy8gdmFyIHVuaWZvcm1TZXR0ZXJzID0gY3JlYXRlVW5pZm9ybVNldHRlcnMoZ2wsIHByb2dyYW0pO1xuICAvLyB2YXIgYXR0cmliU2V0dGVycyAgPSBjcmVhdGVBdHRyaWJ1dGVTZXR0ZXJzKGdsLCBwcm9ncmFtKTtcblxuICAvLyBhbiBpbmRleGVkIHF1YWRcbiAgdmFyIGFycmF5cyA9IHtcbiAgICAgcG9zaXRpb246IHsgbnVtQ29tcG9uZW50czogMywgZGF0YTogWzAsIDAsIDAsIDEwLCAwLCAwLCAwLCAxMCwgMCwgMTAsIDEwLCAwXSwgfSxcbiAgICAgdGV4Y29vcmQ6IHsgbnVtQ29tcG9uZW50czogMiwgZGF0YTogWzAsIDEsIDEsIDEsIDAsIDAsIDEsIDBdLCAgICAgICAgICAgICAgICAgfSxcbiAgICAgbm9ybWFsOiAgIHsgbnVtQ29tcG9uZW50czogMywgZGF0YTogWzAsIDAsIC0xLCAwLCAwLCAtMSwgMCwgMCwgLTEsIDAsIDAsIC0xXSwgfSxcbiAgICAgaW5kaWNlczogIHsgbnVtQ29tcG9uZW50czogMywgZGF0YTogWzAsIDEsIDIsIDEsIDMsIDJdLCAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgfTtcbiAgdmFyIGNlbnRlciA9IFs1LDUsMF07XG4gIHZhciBzY2FsZUZhY3RvciA9IDIwO1xuICB2YXIgc3ViQXJyYXlzID0ge1xuICAgICBwb3NpdGlvbjogeyBudW1Db21wb25lbnRzOiAzLCBkYXRhOiBbXSwgfSwvL3JpZ2h0X2JvdCwgbGVmdF9ib3QsIHJpZ2h0X3VwLCBsZWZ0X3VwXG4gICAgIHRleGNvb3JkOiB7IG51bUNvbXBvbmVudHM6IDIsIGRhdGE6IFtdLCAgICAgICAgICAgICAgICAgfSxcbiAgICAgbm9ybWFsOiAgIHsgbnVtQ29tcG9uZW50czogMywgZGF0YTogW10sIH0sXG4gICAgIGluZGljZXM6ICB7IG51bUNvbXBvbmVudHM6IDMsIGRhdGE6IFtdLCAgICAgICAgICAgICAgICAgICAgICAgfSwgICAgXG4gIH1cbiAgdmFyIG5ld1Bvc2l0aW9uID0gW107XG4gIHZhciBub3JtYWwgPSBbXTtcbiAgdmFyIGluZGljZXMgPSBbXTtcbiAgdmFyIHRleHRDb29yZCA9IFtdO1xuICAvLyBjb25zb2xlLmxvZyhuZXdQb3NpdGlvbik7XG4gIHZhciBuID0gMTAwO1xuICBmb3IgKHZhciBpaSA9IDA7IGlpIDwgbjtpaSsrKSB7XG4gICAgICAgIGZvciAodmFyIGpqID0gMDsgamogPCBuOyBqaisrKSB7XG4gICAgICAgICAgbmV3UG9zaXRpb24ucHVzaC5hcHBseShuZXdQb3NpdGlvbiwgW2pqICogKDEwIC8gKG4gLSAxKSksIGlpICogKDEwIC8gKG4gLSAxKSksIDBdKTtcbiAgICAgICAgICBub3JtYWwucHVzaC5hcHBseShub3JtYWwsIFswLCAwLCAtMV0pO1xuICAgICAgICAgIHRleHRDb29yZC5wdXNoKGpqICogMSAvIChuIC0xKSwgaWkgKiAoMSAvIChuIC0gMSkpKTtcbiAgICAgICAgICBpZiAoIGlpICE9IG4gLSAxICYmIGpqICE9IG4gLSAxKSB7XG4gICAgICAgIGluZGljZXMucHVzaChqaiArIGlpICogbiwgamogKyBpaSpuICsgMSwgamogKyAoaWkgKyAxKSAqIG4pO1xuICAgICAgICBpbmRpY2VzLnB1c2goamogKyBpaSAqIG4gKyAxLCBqaiArIChpaSArIDEpICogbiwgamogKyAoaWkgKyAxKSAqIG4gKyAxKTtcbiAgICAgICAgICB9IFxuICAgIH1cbiAgfVxuICAvLyBmb3IgKHZhciBpaSA9IDA7IGlpIDwgMjAwOyBpaSsrKSB7IC8vIHJvd1xuICAvLyAgICAgZm9yICh2YXIgamogPSAwOyBqaiA8IDIwMDsgamorKyl7IC8vIGNvbFxuICAvLyAgICAgICBpZiAoaWkgIT0gMTk5ICYmIGpqICE9IDE5OSkge1xuICAvLyAgICAgdmFyIHRyaTEgPSBbamogKyBpaSAqIDIwMCwgamogKyBpaSAqIDIwMCArIDEsIGpqICsgKGlpICsgMSkgKiAyMDBdO1xuICAvLyAgICAgdmFyIHRyaTIgPSBbamogKyBpaSAqIDIwMCArIDEsIGpqICsgKGlpICsgMSkgKiAyMDAsIGpqICsgKGlpICsgMSkgKiAyMDAgKyAxXTtcbiAgLy8gICAgICAgaW5kaWNlcy5wdXNoLmFwcGx5KGluZGljZXMsIHRyaTEpO1xuICAvLyAgICAgICBpbmRpY2VzLnB1c2guYXBwbHkoaW5kaWNlcywgdHJpMik7XG4gIC8vICAgICB9XG4gIC8vICAgICB9XG4gIC8vICAgfVxuXG4gIGZvciAodmFyIGlpID0gMDsgaWkgPCB0ZXh0Q29vcmQubGVuZ3RoIC8gMjsgaWkrKykge1xuICAgIHZhciB0ZW1wdCA9IHRleHRDb29yZFtpaV07XG4gICAgdGV4dENvb3JkW2lpXSA9IHRleHRDb29yZFt0ZXh0Q29vcmQubGVuZ3RoIC0gaWkgLSAxXTtcbiAgICB0ZXh0Q29vcmRbdGV4dENvb3JkLmxlbmd0aCAtIGlpIC0gMV0gPSB0ZW1wdDtcbiAgfVxuICBmb3IgKHZhciBpaSA9IDA7IGlpIDwgdGV4dENvb3JkLmxlbmd0aDsgaWkrPTIpIHtcbiAgICB2YXIgdGVtcHQgPSB0ZXh0Q29vcmRbaWldO1xuICB0ZXh0Q29vcmRbaWldID0gdGV4dENvb3JkW2lpICsgMV07XG4gIHRleHRDb29yZFtpaSArIDFdID0gdGVtcHQ7XG4gIH1cbiAgc3ViQXJyYXlzLnBvc2l0aW9uLmRhdGEgPSBuZXdQb3NpdGlvbjtcbiAgICBzdWJBcnJheXMuaW5kaWNlcy5kYXRhID0gaW5kaWNlcztcbiAgICBzdWJBcnJheXMudGV4Y29vcmQuZGF0YSA9IHRleHRDb29yZDtcbiAgICBzdWJBcnJheXMubm9ybWFsLmRhdGEgPSBub3JtYWw7XG4gIHZhciBidWZmZXJJbmZvID0gY3JlYXRlQnVmZmVySW5mb0Zyb21BcnJheXMoZ2wsIGFycmF5cyk7XG4gIGZ1bmN0aW9uIGRlZ1RvUmFkKGQpIHtcbiAgICByZXR1cm4gZCAqIE1hdGguUEkgLyAxODA7XG4gIH1cblxuICB2YXIgY2FtZXJhQW5nbGVSYWRpYW5zID0gZGVnVG9SYWQoMCk7XG4gIHZhciBmaWVsZE9mVmlld1JhZGlhbnMgPSBkZWdUb1JhZCg2MCk7XG4gIHZhciBjYW1lcmFIZWlnaHQgPSA1MDtcblxuICB2YXIgdW5pZm9ybXNUaGF0QXJlVGhlU2FtZUZvckFsbE9iamVjdHMgPSB7XG4gICAgdV9saWdodFdvcmxkUG9zOiAgICAgICAgIFs1MCwgMzAsIC0xMDBdLFxuICAgIHVfdmlld0ludmVyc2U6ICAgICAgICAgICBtYXQ0LmNyZWF0ZSgpLFxuICAgIHVfbGlnaHRDb2xvcjogICAgICAgICAgICBbMSwgMSwgMSwgMV0sXG4gICAgdV9hbWJpZW50OiAgICAgICAgICAgICAgIFswLjEsIDAuMSwgMC4xLCAwLjFdLFxuICAgIHVfdGltZTogICAgICAgICAgICAgICAgICAwXG4gIH07XG5cbiAgdmFyIHVuaWZvcm1zVGhhdEFyZUNvbXB1dGVkRm9yRWFjaE9iamVjdCA9IHtcbiAgICB1X3dvcmxkVmlld1Byb2plY3Rpb246ICAgbWF0NC5jcmVhdGUoKSxcbiAgICB1X3dvcmxkOiAgICAgICAgICAgICAgICAgbWF0NC5jcmVhdGUoKSxcbiAgICB1X3dvcmxkSW52ZXJzZVRyYW5zcG9zZTogbWF0NC5jcmVhdGUoKSxcbiAgICB1X3NjYWxlOnNjYWxlRmFjdG9yLFxuICAgIHVfaG9sZXNfeDogWzAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDBdLFxuICAgIHVfaG9sZXNfeTogWzAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDAsIDBdLFxuICB9O1xuXG4gIC8vIHZhciB0ZXh0dXJlID0gLi4uLiBjcmVhdGUgYSB0ZXh0dXJlIG9mIHNvbWUgZm9ybVxuXG4gIHZhciBiYXNlQ29sb3IgPSByYW5kKDI0MCk7XG4gIHZhciBvYmplY3RTdGF0ZSA9IHsgXG4gICAgICBtYXRlcmlhbFVuaWZvcm1zOiB7XG4gICAgICAgIHVfY29sb3JNdWx0OiAgICAgICAgICAgICBjaHJvbWEuaHN2KHJhbmQoYmFzZUNvbG9yLCBiYXNlQ29sb3IgKyAxMjApLCAwLjUsIDEpLmdsKCksXG4gICAgICAgIC8vdV9kaWZmdXNlOiAgICAgICAgICAgICAgIHRleHR1cmUsXG4gICAgICAgIHVfc3BlY3VsYXI6ICAgICAgICAgICAgICBbMSwgMSwgMSwgMV0sXG4gICAgICAgIHVfc2hpbmluZXNzOiAgICAgICAgICAgICA0NTAsXG4gICAgICAgIHVfc3BlY3VsYXJGYWN0b3I6ICAgICAgICAwLjc1LFxuICAgICAgfVxuICB9O1xuXG4gIC8vIHNvbWUgdmFyaWFibGVzIHdlJ2xsIHJldXNlIGJlbG93XG4gIHZhciBwcm9qZWN0aW9uTWF0cml4ID0gbWF0NC5jcmVhdGUoKTtcbiAgdmFyIHZpZXdNYXRyaXggPSBtYXQ0LmNyZWF0ZSgpO1xuICB2YXIgcm90YXRpb25NYXRyaXggPSBtYXQ0LmNyZWF0ZSgpO1xuICB2YXIgbWF0cml4ID0gbWF0NC5jcmVhdGUoKTsgIC8vIGEgc2NyYXRjaCBtYXRyaXhcbiAgdmFyIGludk1hdHJpeCA9IG1hdDQuY3JlYXRlKCk7XG4gIHZhciBheGlzVmVjdG9yID0gdmVjMy5jcmVhdGUoKTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCAyNDsgaSsrKSB7XG4gICAgdW5pZm9ybXNUaGF0QXJlQ29tcHV0ZWRGb3JFYWNoT2JqZWN0LnVfaG9sZXNfeFtpXSA9IHJhbmQoLTEsIDEpO1xuICAgIHVuaWZvcm1zVGhhdEFyZUNvbXB1dGVkRm9yRWFjaE9iamVjdC51X2hvbGVzX3lbaV0gPSByYW5kKC0xLCAxKTtcbiAgfVxuXG4gIHJlcXVlc3RBbmltYXRpb25GcmFtZShkcmF3U2NlbmUpO1xuXG4gIC8vIERyYXcgdGhlIHNjZW5lLlxuICBmdW5jdGlvbiBkcmF3U2NlbmUodGltZTogbnVtYmVyKSB7XG4gICAgdGltZSAqPSAwLjAwMTtcbiAgICBpZihlZmZlY3RJID09IDgpIHtcbiAgICB2YXIgYnVmZmVySW5mbzIgPSBjcmVhdGVCdWZmZXJJbmZvRnJvbUFycmF5cyhnbCwgc3ViQXJyYXlzKTtcbiAgICAvLyBjb25zb2xlLmxvZyhcImhpXCIpO1xuICAgIH1cbiAgICB1bmlmb3Jtc1RoYXRBcmVUaGVTYW1lRm9yQWxsT2JqZWN0cy51X3RpbWUgPSB1bmlmb3Jtc1RoYXRBcmVUaGVTYW1lRm9yQWxsT2JqZWN0cy51X3RpbWUgKyAwLjAxO1xuICAgICAgXG4gICAgIHZhciBwcm9ncmFtID0gY3JlYXRlUHJvZ3JhbUZyb21Tb3VyY2VzKGdsLCBbc2hhZGVyVGV4dFtlZmZlY3RJXSwgc2hhZGVyVGV4dFtlZmZlY3RJICsgMV1dKTtcbiAgICB2YXIgdW5pZm9ybVNldHRlcnMgPSBjcmVhdGVVbmlmb3JtU2V0dGVycyhnbCwgcHJvZ3JhbSk7XG4gICAgdmFyIGF0dHJpYlNldHRlcnMgID0gY3JlYXRlQXR0cmlidXRlU2V0dGVycyhnbCwgcHJvZ3JhbSk7XG5cbiAgICAvLyBtZWFzdXJlIHRpbWUgdGFrZW4gZm9yIHRoZSBsaXR0bGUgc3RhdHMgbWV0ZXJcbiAgICBzdGF0cy5iZWdpbigpO1xuXG4gICAgLy8gaWYgdGhlIHdpbmRvdyBjaGFuZ2VkIHNpemUsIHJlc2V0IHRoZSBXZWJHTCBjYW52YXMgc2l6ZSB0byBtYXRjaC4gIFRoZSBkaXNwbGF5ZWQgc2l6ZSBvZiB0aGUgY2FudmFzXG4gICAgLy8gKGRldGVybWluZWQgYnkgd2luZG93IHNpemUsIGxheW91dCwgYW5kIHlvdXIgQ1NTKSBpcyBzZXBhcmF0ZSBmcm9tIHRoZSBzaXplIG9mIHRoZSBXZWJHTCByZW5kZXIgYnVmZmVycywgXG4gICAgLy8gd2hpY2ggeW91IGNhbiBjb250cm9sIGJ5IHNldHRpbmcgY2FudmFzLndpZHRoIGFuZCBjYW52YXMuaGVpZ2h0XG4gICAgcmVzaXplQ2FudmFzVG9EaXNwbGF5U2l6ZShjYW52YXMpO1xuXG4gICAgLy8gU2V0IHRoZSB2aWV3cG9ydCB0byBtYXRjaCB0aGUgY2FudmFzXG4gICAgZ2wudmlld3BvcnQoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcbiAgICAvLyBDbGVhciB0aGUgY2FudmFzIEFORCB0aGUgZGVwdGggYnVmZmVyLlxuICAgIGdsLmNsZWFyKGdsLkNPTE9SX0JVRkZFUl9CSVQgfCBnbC5ERVBUSF9CVUZGRVJfQklUKTtcblxuICAgIC8vIENvbXB1dGUgdGhlIHByb2plY3Rpb24gbWF0cml4XG4gICAgdmFyIGFzcGVjdCA9IGNhbnZhcy5jbGllbnRXaWR0aCAvIGNhbnZhcy5jbGllbnRIZWlnaHQ7XG4gICAgbWF0NC5wZXJzcGVjdGl2ZShwcm9qZWN0aW9uTWF0cml4LGZpZWxkT2ZWaWV3UmFkaWFucywgYXNwZWN0LCAxLCAyMDAwKTtcblxuICAgIC8vIENvbXB1dGUgdGhlIGNhbWVyYSdzIG1hdHJpeCB1c2luZyBsb29rIGF0LlxuICAgIHZhciBjYW1lcmFQb3NpdGlvbiA9IFswLCAwLCAtMjAwXTtcbiAgICB2YXIgdGFyZ2V0ID0gWzAsIDAsIDBdO1xuICAgIHZhciB1cCA9IFswLCAxLCAwXTtcbiAgICB2YXIgY2FtZXJhTWF0cml4ID0gbWF0NC5sb29rQXQodW5pZm9ybXNUaGF0QXJlVGhlU2FtZUZvckFsbE9iamVjdHMudV92aWV3SW52ZXJzZSwgY2FtZXJhUG9zaXRpb24sIHRhcmdldCwgdXApO1xuXG4gICAgLy8gTWFrZSBhIHZpZXcgbWF0cml4IGZyb20gdGhlIGNhbWVyYSBtYXRyaXguXG4gICAgbWF0NC5pbnZlcnQodmlld01hdHJpeCwgY2FtZXJhTWF0cml4KTtcbiAgICBcbiAgICAvLyB0ZWxsIFdlYkdMIHRvIHVzZSBvdXIgc2hhZGVyIHByb2dyYW0gKHdpbGwgbmVlZCB0byBjaGFuZ2UgdGhpcylcbiAgICBnbC51c2VQcm9ncmFtKHByb2dyYW0pO1xuICAgIHZhciB1X2ltYWdlMExvY2F0aW9uID0gZ2wuZ2V0VW5pZm9ybUxvY2F0aW9uKHByb2dyYW0sIFwidV9pbWFnZTBcIik7XG4gICAgdmFyIHVfaW1hZ2UxTG9jYXRpb24gPSBnbC5nZXRVbmlmb3JtTG9jYXRpb24ocHJvZ3JhbSwgXCJ1X2ltYWdlMVwiKTsgICBcblxuXG4gICAgLy8gU2V0dXAgYWxsIHRoZSBuZWVkZWQgYXR0cmlidXRlcyBhbmQgYnVmZmVycy4gIFxuICAgIGlmIChlZmZlY3RJID09IDgpIHtcbnNldEJ1ZmZlcnNBbmRBdHRyaWJ1dGVzKGdsLCBhdHRyaWJTZXR0ZXJzLCBidWZmZXJJbmZvMik7XG4gICAgfSBlbHNlIHtcbiAgICBzZXRCdWZmZXJzQW5kQXR0cmlidXRlcyhnbCwgYXR0cmliU2V0dGVycywgYnVmZmVySW5mbyk7XG4gIH1cblxuICAgIC8vIFNldCB0aGUgdW5pZm9ybXMgdGhhdCBhcmUgdGhlIHNhbWUgZm9yIGFsbCBvYmplY3RzLiAgVW5saWtlIHRoZSBhdHRyaWJ1dGVzLCBlYWNoIHVuaWZvcm0gc2V0dGVyXG4gICAgLy8gaXMgZGlmZmVyZW50LCBkZXBlbmRpbmcgb24gdGhlIHR5cGUgb2YgdGhlIHVuaWZvcm0gdmFyaWFibGUuICBMb29rIGluIHdlYmdsLXV0aWwuanMgZm9yIHRoZVxuICAgIC8vIGltcGxlbWVudGF0aW9uIG9mICBzZXRVbmlmb3JtcyB0byBzZWUgdGhlIGRldGFpbHMgZm9yIHNwZWNpZmljIHR5cGVzICAgICAgIFxuICAgIHNldFVuaWZvcm1zKHVuaWZvcm1TZXR0ZXJzLCB1bmlmb3Jtc1RoYXRBcmVUaGVTYW1lRm9yQWxsT2JqZWN0cyk7XG4gICBcbiAgICBnbC51bmlmb3JtMWkodV9pbWFnZTBMb2NhdGlvbiwgMCk7XG4gICAgZ2wudW5pZm9ybTFpKHVfaW1hZ2UxTG9jYXRpb24sIDEpO1xuICAgIGdsLmFjdGl2ZVRleHR1cmUoZ2wuVEVYVFVSRTApO1xuICAgIGdsLmJpbmRUZXh0dXJlKGdsLlRFWFRVUkVfMkQsIHRleHR1cmVzWzBdKTtcbiAgICBnbC5hY3RpdmVUZXh0dXJlKGdsLlRFWFRVUkUxKTtcbiAgICBnbC5iaW5kVGV4dHVyZShnbC5URVhUVVJFXzJELCB0ZXh0dXJlc1sxXSk7XG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAgIC8vIENvbXB1dGUgdGhlIHZpZXcgbWF0cml4IGFuZCBjb3JyZXNwb25kaW5nIG90aGVyIG1hdHJpY2VzIGZvciByZW5kZXJpbmcuXG4gICAgXG4gICAgLy8gZmlyc3QgbWFrZSBhIGNvcHkgb2Ygb3VyIHJvdGF0aW9uTWF0cml4XG4gICAgbWF0NC5jb3B5KG1hdHJpeCwgcm90YXRpb25NYXRyaXgpO1xuICAgIFxuICAgIC8vIGFkanVzdCB0aGUgcm90YXRpb24gYmFzZWQgb24gbW91c2UgYWN0aXZpdHkuICBtb3VzZUFuZ2xlcyBpcyBzZXQgaWYgdXNlciBpcyBkcmFnZ2luZyBcbiAgICBpZiAobW91c2VBbmdsZXNbMF0gIT09IDAgfHwgbW91c2VBbmdsZXNbMV0gIT09IDApIHtcbiAgICAgIC8qXG4gICAgICAgKiBvbmx5IHJvdGF0ZSBhcm91bmQgWSwgdXNlIHRoZSBzZWNvbmQgbW91c2UgdmFsdWUgZm9yIHNjYWxlLiAgTGVhdmluZyB0aGUgb2xkIGNvZGUgZnJvbSBBMyBcbiAgICAgICAqIGhlcmUsIGNvbW1lbnRlZCBvdXRcbiAgICAgICAqIFxuICAgICAgLy8gbmVlZCBhbiBpbnZlcnNlIHdvcmxkIHRyYW5zZm9ybSBzbyB3ZSBjYW4gZmluZCBvdXQgd2hhdCB0aGUgd29ybGQgWCBheGlzIGZvciBvdXIgZmlyc3Qgcm90YXRpb24gaXNcbiAgICAgIG1hdDQuaW52ZXJ0KGludk1hdHJpeCwgbWF0cml4KTtcbiAgICAgIC8vIGdldCB0aGUgd29ybGQgWCBheGlzXG4gICAgICB2YXIgeEF4aXMgPSB2ZWMzLnRyYW5zZm9ybU1hdDQoYXhpc1ZlY3RvciwgdmVjMy5mcm9tVmFsdWVzKDEsMCwwKSwgaW52TWF0cml4KTtcblxuICAgICAgLy8gcm90YXRlIGFib3V0IHRoZSB3b3JsZCBYIGF4aXMgKHRoZSBYIHBhcmFsbGVsIHRvIHRoZSBzY3JlZW4hKVxuICAgICAgbWF0NC5yb3RhdGUobWF0cml4LCBtYXRyaXgsIC1tb3VzZUFuZ2xlc1sxXSwgeEF4aXMpO1xuICAgICAgKi9cbiAgICAgICAgICAgIFxuICAgICAgLy8gbm93IGdldCB0aGUgaW52ZXJzZSB3b3JsZCB0cmFuc2Zvcm0gc28gd2UgY2FuIGZpbmQgdGhlIHdvcmxkIFkgYXhpc1xuICAgICAgbWF0NC5pbnZlcnQoaW52TWF0cml4LCBtYXRyaXgpO1xuICAgICAgLy8gZ2V0IHRoZSB3b3JsZCBZIGF4aXNcbiAgICAgIHZhciB5QXhpcyA9IHZlYzMudHJhbnNmb3JtTWF0NChheGlzVmVjdG9yLCB2ZWMzLmZyb21WYWx1ZXMoMCwxLDApLCBpbnZNYXRyaXgpO1xuXG4gICAgICAvLyByb3RhdGUgYWJvdXQgdGVoIHdvcmxkIFkgYXhpc1xuICAgICAgbWF0NC5yb3RhdGUobWF0cml4LCBtYXRyaXgsIG1vdXNlQW5nbGVzWzBdLCB5QXhpcyk7XG4gICAgICBcbiAgICAgIC8vIHNhdmUgdGhlIHJlc3VsdGluZyBtYXRyaXggYmFjayB0byB0aGUgY3VtdWxhdGl2ZSByb3RhdGlvbiBtYXRyaXggXG4gICAgICBtYXQ0LmNvcHkocm90YXRpb25NYXRyaXgsIG1hdHJpeCk7XG4gICAgICBcbiAgICAgIC8vIHVzZSBtb3VzZUFuZ2xlc1sxXSB0byBzY2FsZVxuICAgICAgc2NhbGVGYWN0b3IgKz0gbW91c2VBbmdsZXNbMV07XG4gICAgICBcbiAgICAgIHZlYzIuc2V0KG1vdXNlQW5nbGVzLCAwLCAwKTsgICAgICAgIFxuICAgIH0gICBcbiAgICB1bmlmb3Jtc1RoYXRBcmVDb21wdXRlZEZvckVhY2hPYmplY3QudV9zY2FsZSA9IHNjYWxlRmFjdG9yO1xuICAgIC8vIGFkZCBhIHRyYW5zbGF0ZSBhbmQgc2NhbGUgdG8gdGhlIG9iamVjdCBXb3JsZCB4Zm9ybSwgc28gd2UgaGF2ZTogIFIgKiBUICogU1xuICAgIG1hdDQudHJhbnNsYXRlKG1hdHJpeCwgcm90YXRpb25NYXRyaXgsIFstY2VudGVyWzBdKnNjYWxlRmFjdG9yLCAtY2VudGVyWzFdKnNjYWxlRmFjdG9yLCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLWNlbnRlclsyXSpzY2FsZUZhY3Rvcl0pO1xuICAgIG1hdDQuc2NhbGUobWF0cml4LCBtYXRyaXgsIFtzY2FsZUZhY3Rvciwgc2NhbGVGYWN0b3IsIHNjYWxlRmFjdG9yXSk7XG4gICAgbWF0NC5jb3B5KHVuaWZvcm1zVGhhdEFyZUNvbXB1dGVkRm9yRWFjaE9iamVjdC51X3dvcmxkLCBtYXRyaXgpO1xuICAgIFxuICAgIC8vIGdldCBwcm9qICogdmlldyAqIHdvcmxkXG4gICAgbWF0NC5tdWx0aXBseShtYXRyaXgsIHZpZXdNYXRyaXgsIHVuaWZvcm1zVGhhdEFyZUNvbXB1dGVkRm9yRWFjaE9iamVjdC51X3dvcmxkKTtcbiAgICBtYXQ0Lm11bHRpcGx5KHVuaWZvcm1zVGhhdEFyZUNvbXB1dGVkRm9yRWFjaE9iamVjdC51X3dvcmxkVmlld1Byb2plY3Rpb24sIHByb2plY3Rpb25NYXRyaXgsIG1hdHJpeCk7XG5cbiAgICAvLyBnZXQgd29ybGRJbnZUcmFuc3Bvc2UuICBGb3IgYW4gZXhwbGFpbmF0aW9uIG9mIHdoeSB3ZSBuZWVkIHRoaXMsIGZvciBmaXhpbmcgdGhlIG5vcm1hbHMsIHNlZVxuICAgIC8vIGh0dHA6Ly93d3cudW5rbm93bnJvYWQuY29tL3J0Zm0vZ3JhcGhpY3MvcnRfbm9ybWFscy5odG1sXG4gICAgbWF0NC50cmFuc3Bvc2UodW5pZm9ybXNUaGF0QXJlQ29tcHV0ZWRGb3JFYWNoT2JqZWN0LnVfd29ybGRJbnZlcnNlVHJhbnNwb3NlLCBcbiAgICAgICAgICAgICAgICAgICBtYXQ0LmludmVydChtYXRyaXgsIHVuaWZvcm1zVGhhdEFyZUNvbXB1dGVkRm9yRWFjaE9iamVjdC51X3dvcmxkKSk7XG5cbiAgICAvLyBTZXQgdGhlIHVuaWZvcm1zIHdlIGp1c3QgY29tcHV0ZWRcbiAgICBzZXRVbmlmb3Jtcyh1bmlmb3JtU2V0dGVycywgdW5pZm9ybXNUaGF0QXJlQ29tcHV0ZWRGb3JFYWNoT2JqZWN0KTtcblxuICAgIC8vIFNldCB0aGUgdW5pZm9ybXMgdGhhdCBhcmUgc3BlY2lmaWMgdG8gdGhlIHRoaXMgb2JqZWN0LlxuICAgIHNldFVuaWZvcm1zKHVuaWZvcm1TZXR0ZXJzLCBvYmplY3RTdGF0ZS5tYXRlcmlhbFVuaWZvcm1zKTtcblxuICAgIC8vIERyYXcgdGhlIGdlb21ldHJ5LiAgIEV2ZXJ5dGhpbmcgaXMga2V5ZWQgdG8gdGhlIFwiXCJcbiAgICBpZiAoZWZmZWN0SSA9PSA4KSB7XG4gICAgZ2wuZHJhd0VsZW1lbnRzKGdsLlRSSUFOR0xFUywgYnVmZmVySW5mbzIubnVtRWxlbWVudHMsIGdsLlVOU0lHTkVEX1NIT1JULCAwKTtcbiAgICB9IGVsc2Uge1xuICAgIGdsLmRyYXdFbGVtZW50cyhnbC5UUklBTkdMRVMsIGJ1ZmZlckluZm8ubnVtRWxlbWVudHMsIGdsLlVOU0lHTkVEX1NIT1JULCAwKTtcbiAgfVxuXG4gICAgLy8gc3RhdHMgbWV0ZXJcbiAgICBzdGF0cy5lbmQoKTtcblxuICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZShkcmF3U2NlbmUpO1xuICB9XG59XG5cbiJdLCJzb3VyY2VSb290IjoiL3NvdXJjZS8ifQ==
