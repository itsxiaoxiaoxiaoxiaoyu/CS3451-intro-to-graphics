define(["require", "exports", './SG'], function (require, exports, sg) {
    // find the div's we want to use as our 3D Scene containers
    var scene = new sg.Scene(document.getElementById("cutiePanther"));
    ///////////////////////////////////
    // Scene 1.
    // the camera is 25 degrees;  should result in a focal length of ~450 or so, based on a 200 pixel 
    // square container.  We'll move it off center, to test
    var camera = new sg.Camera(25);
    camera.position = new sg.Vector(-100, 50, 200);
    scene.world.add(camera);
    // create a greenish light and put it up, behind and to the left of the camera
    var light = new sg.Light(new sg.Color(0.87, 0.44, 0.5));
    light.position = new sg.Vector(-100, 400, 1000);
    var aLight = new sg.Light(new sg.Color(0.67, 0.13, 0.68));
    aLight.position = new sg.Vector(-200, -500, 250);
    var bLight = new sg.Light(new sg.Color(0.88, 0.25, 0.1));
    bLight.position = new sg.Vector(200, 500, 250);
    aLight.add(bLight);
    scene.world.add(light);
    var color = 0;
    var r = 300;
    var angle = 0;
    // create a div for our cotent
    for (var i = 0; i < 10; i++) {
        var p = document.createElement("div");
        p.className = "panel";
        switch (i) {
            case 0:
                p.style.background = "url('images/luna.jpg')";
                //p.innerText = "I am one \n(⊙ˍ⊙)";
                break;
            case 1:
                p.style.background = "url('images/xiaolu.jpg')";
                // p.innerText = "I am two \n(*￣∇￣*)";
                break;
            case 2:
                p.style.background = "url('images/ta.jpg')";
                // p.innerText = "I am three \nヾ(o◕∀◕)ﾉ";
                break;
            case 3:
                p.style.background = "url('images/axe.png')";
                // p.innerText = "I am four \n✪ω✪";
                break;
            case 4:
                p.style.background = "url('images/zeus.png')";
                // p.innerText = "I am five \n(●'◡'●)ﾉ♥";
                break;
            case 5:
                p.style.background = "url('images/water.png')";
                // p.innerText = "I am six \no(￣ヘ￣*o)";
                break;
            case 6:
                p.style.background = "url('images/meepo.jpg')";
                // p.innerText = "I am seven \n(ΦωΦ) ";
                break;
            case 7:
                p.style.background = "url('images/io.jpg')";
                // p.innerText = "I am eigth \n(o^∇^o)ﾉ ";
                break;
            case 8:
                p.style.background = "url('images/sven.jpg')";
                // p.innerText = "I am nine \n(≖ ‿ ≖)✧";
                break;
            case 9:
                p.style.background = "url('images/am.jpg')";
                // p.innerText = "I am ten \n(→_→)";
                break;
        }
        // put the div in the scene graph, pushed out a bit further down the z axis
        var n = new sg.HTMLDivThing(p);
        angle = ((i / 10 * 360) / 180) * Math.PI;
        n.position = new sg.Vector(50, 200 + r * Math.sin(angle), -r + r * Math.cos(angle));
        //z is near or far, x is left or right, y is height
        scene.world.add(n);
    }
    var angle = (5 / 180) * Math.PI;
    var scaled;
    var sceneRenderFunc = function () {
        var func = function (obj) {
            if (obj instanceof sg.HTMLDivThing && scaled == undefined) {
                if (obj.position.y >= 200 && obj.position.y <= 200 + r + 3) {
                    if (obj.position.z >= -2 * r - 3 && obj.position.z <= -r) {
                        obj.position.y = obj.position.y + 3;
                        obj.position.z = obj.position.z + 3;
                    }
                    else if (obj.position.z > -r && obj.position.z <= 0 + 3) {
                        obj.position.y = obj.position.y - 3;
                        obj.position.z = obj.position.z + 3;
                    }
                }
                else if (obj.position.y >= 200 - r - 3 && obj.position.y < 200) {
                    if (obj.position.z >= -2 * r - 3 && obj.position.z <= -r) {
                        obj.position.y = obj.position.y + 3;
                        obj.position.z = obj.position.z - 3;
                    }
                    else if (obj.position.z > -r && obj.position.z <= 0 + 3) {
                        obj.position.y = obj.position.y - 3;
                        obj.position.z = obj.position.z - 3;
                    }
                }
                if (obj.position.y > 200 + r + 3) {
                    obj.position.y = obj.position.y - 3;
                }
                if (obj.position.y < 200 - r - 3) {
                    obj.position.y = obj.position.y + 3;
                }
                if (obj.position.z < -2 * r - 3) {
                    obj.position.z = obj.position.z + 3;
                }
                if (obj.position.z > 0 + 3) {
                    obj.position.z = obj.position.z - 3;
                }
                obj.position.x = 50;
            }
        };
        var flag = true;
        var mouse = function (obj) {
            if (obj instanceof sg.HTMLDivThing && flag == true) {
                if (obj.position.y >= 200 && obj.position.y <= 250) {
                    if (obj.position.z >= -r + 50) {
                        flag = false;
                        if (scaled != undefined) {
                            scaled.scale = new sg.Vector(1, 1, 1);
                            scaled = undefined;
                        }
                        else {
                            obj.scale = new sg.Vector(2, 2, 2);
                            scaled = obj;
                        }
                    }
                }
            }
        };
        document.body.onclick = function (e) {
            scene.world.traverse(mouse);
        };
        scene.world.traverse(func);
        // console.log(cx);
        scene.render();
        requestAnimationFrame(sceneRenderFunc);
    };
    sceneRenderFunc();
});
//# sourceMappingURL=a2.js.map